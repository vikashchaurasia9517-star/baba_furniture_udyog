import dotenv from 'dotenv';
dotenv.config({ path: '.env.local' });
dotenv.config();

import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { createClient } from '@supabase/supabase-js';
import {
  DEFAULT_OWNER_ADMIN_PROFILE,
  INITIAL_INQUIRIES,
  INITIAL_PRODUCTS,
  INITIAL_SHOWROOM_CONFIG,
} from './src/data/initialFurniture';
import { AdminRole, AuthMethodsConfig, LiveChatSession } from './src/types/furniture';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '15mb' }));

// Security Headers & Anti-Hacking Rate Limiter
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-XSS-Protection', '1; mode=block');

  const ip = req.ip || req.socket.remoteAddress || 'local';
  const now = Date.now();
  const entry = rateLimitMap.get(ip);
  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + 60_000 });
  } else {
    entry.count += 1;
    if (entry.count > 240) {
      return res.status(429).json({
        error: 'बहुत अधिक अनुरोध। कृपया 1 मिनट बाद पुनः प्रयास करें। (Too many requests. Please try again in a minute.)',
      });
    }
  }
  next();
});

function sanitizeInput(val: any): any {
  if (typeof val === 'string') {
    return val.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '').trim();
  }
  if (Array.isArray(val)) return val.map(sanitizeInput);
  if (val && typeof val === 'object') {
    const out: Record<string, any> = {};
    for (const [k, v] of Object.entries(val)) {
      out[k] = sanitizeInput(v);
    }
    return out;
  }
  return val;
}

const PORT = Number(process.env.BACKEND_PORT || process.env.PORT) || 5000;
const SUPABASE_URL = (process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || '').trim();
const SUPABASE_SERVICE_KEY = (process.env.SUPABASE_SERVICE_ROLE_KEY || '').trim();
const SUPABASE_ANON_KEY = (process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY || '').trim();
const SUPABASE_KEY = SUPABASE_SERVICE_KEY || SUPABASE_ANON_KEY;

// Primary Admin Emails that automatically receive app_admin privilege upon valid Auth
const FIRST_APP_ADMIN_EMAILS = [
  'vikashchaurasia9517@gmail.com',
  'admin@babafurnitureudyog.com',
  (process.env.ADMIN_INITIAL_EMAIL || '').toLowerCase().trim(),
].filter(Boolean);

const SHOP_OWNER_EMAILS = [
  'owner@babafurnitureudyog.com',
  (process.env.SHOP_OWNER_EMAIL || '').toLowerCase().trim(),
].filter(Boolean);

const supabase =
  SUPABASE_URL && SUPABASE_KEY
    ? createClient(SUPABASE_URL, SUPABASE_KEY, {
        auth: { autoRefreshToken: false, persistSession: false },
      })
    : null;

function createFreshAuthClient() {
  if (!SUPABASE_URL || !SUPABASE_KEY) return null;
  return createClient(SUPABASE_URL, SUPABASE_ANON_KEY || SUPABASE_KEY, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}

const ADMIN_TOKEN_SECRET =
  process.env.ADMIN_TOKEN_SECRET || 'baba-furniture-udyog-secret-admin-signing-key-2026';

const DB_FILE = path.join(__dirname, 'server', 'db.json');

function sha256Hex(text: string): string {
  return crypto.createHash('sha256').update(text.trim()).digest('hex');
}

function generateAdminToken(payload: { id: string; email: string; role: AdminRole }): string {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const body = Buffer.from(
    JSON.stringify({
      ...payload,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + 86400 * 7, // 7 days
    })
  ).toString('base64url');
  const signature = crypto
    .createHmac('sha256', ADMIN_TOKEN_SECRET)
    .update(`${header}.${body}`)
    .digest('base64url');
  return `${header}.${body}.${signature}`;
}

function verifyAdminTokenPayload(token: string): { id: string; email: string; role: AdminRole } | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [header, body, signature] = parts;
    const expectedSig = crypto
      .createHmac('sha256', ADMIN_TOKEN_SECRET)
      .update(`${header}.${body}`)
      .digest('base64url');
    if (signature !== expectedSig) return null;
    const data = JSON.parse(Buffer.from(body, 'base64url').toString('utf-8'));
    if (data.exp && data.exp < Math.floor(Date.now() / 1000)) return null;
    return { id: data.id, email: data.email, role: data.role };
  } catch {
    return null;
  }
}

// In-Memory store for MFA challenges (expires in 5 minutes)
interface MfaChallenge {
  id: string;
  adminId: string;
  email: string;
  role: AdminRole;
  code: string;
  adminProfile: any;
  expiresAt: number;
}
const mfaChallenges = new Map<string, MfaChallenge>();

function loadLocalDb() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
      if (!parsed.chatSessions) parsed.chatSessions = [];
      if (!parsed.adminTeam || parsed.adminTeam.length === 0) {
        parsed.adminTeam = getDefaultAdminTeam();
      }
      return parsed;
    }
  } catch {}
  return {
    config: INITIAL_SHOWROOM_CONFIG,
    products: INITIAL_PRODUCTS,
    inquiries: INITIAL_INQUIRIES,
    chatSessions: [] as LiveChatSession[],
    adminProfile: {
      ...DEFAULT_OWNER_ADMIN_PROFILE,
      role: 'app_admin',
      mfaEnabled: false,
    },
    customers: [],
    adminTeam: getDefaultAdminTeam(),
    invitations: [],
    authMethodsConfig: {
      emailPasswordEnabled: true,
      emailOtpEnabled: true,
      googleAuthEnabled: true,
      phoneOtpEnabled: false,
      whatsappOtpEnabled: false,
      updatedAt: new Date().toISOString(),
    },
  };
}

function getDefaultAdminTeam() {
  return [
    {
      id: 'admin-app-first',
      email: 'vikashchaurasia9517@gmail.com',
      fullName: 'प्रो. विकास चौरसिया (System App Admin)',
      ownerName: 'प्रो. विकास चौरसिया (System App Admin)',
      role: 'app_admin' as AdminRole,
      phone: '9876543210',
      passwordHash: sha256Hex(process.env.ADMIN_INITIAL_PASSWORD || 'Vikash@9118#'),
      mfaEnabled: false,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'admin-shop-owner',
      email: 'owner@babafurnitureudyog.com',
      fullName: 'बाबा फर्नीचर शोरूम संचालक (Shop Owner)',
      ownerName: 'बाबा फर्नीचर शोरूम संचालक (Shop Owner)',
      role: 'shop_owner' as AdminRole,
      phone: '9876543210',
      passwordHash: sha256Hex(process.env.SHOP_OWNER_PASSWORD || 'Owner@9118#'),
      mfaEnabled: false,
      createdAt: new Date().toISOString(),
    },
  ];
}

function saveLocalDb(data: any) {
  try {
    fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch {}
}

// Authentication & Role-Checking Middleware
function requireAdmin(requiredRole?: 'app_admin') {
  return async (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.startsWith('Bearer ')
      ? authHeader.slice(7).trim()
      : String(req.headers['x-admin-token'] || '').trim();

    if (!token) {
      return res.status(401).json({
        error: 'अनधिकृत: व्यवस्थापक टोकन अनुपलब्ध है। कृपया पहले व्यवस्थापक लॉगिन करें। (Admin authentication required)',
      });
    }

    // 1. Try our signed backend admin token
    const localPayload = verifyAdminTokenPayload(token);
    if (localPayload) {
      if (requiredRole === 'app_admin' && localPayload.role !== 'app_admin') {
        return res.status(403).json({
          error: 'निषिद्ध: यह कार्रवाई केवल मुख्य एप्लिकेशन व्यवस्थापक (Application Admin) द्वारा ही संभव है।',
        });
      }
      (req as any).adminUser = localPayload;
      return next();
    }

    // 2. Try Supabase Auth token if Supabase is connected
    if (supabase) {
      try {
        const { data: userData, error: userError } = await supabase.auth.getUser(token);
        if (!userError && userData?.user) {
          const userEmail = (userData.user.email || '').toLowerCase();
          let { data: adminRow } = await supabase
            .from('admin_users')
            .select('*')
            .or(`id.eq.${userData.user.id},email.ilike.${userEmail}`)
            .maybeSingle();

          if (!adminRow && FIRST_APP_ADMIN_EMAILS.includes(userEmail)) {
            adminRow = {
              id: userData.user.id,
              email: userEmail,
              full_name: 'प्रो. विकास चौरसिया (App Admin)',
              role: 'app_admin',
            };
          } else if (!adminRow && SHOP_OWNER_EMAILS.includes(userEmail)) {
            adminRow = {
              id: userData.user.id,
              email: userEmail,
              full_name: 'बाबा फर्नीचर शोरूम संचालक (Shop Owner)',
              role: 'shop_owner',
            };
          }

          if (adminRow) {
            if (requiredRole === 'app_admin' && adminRow.role !== 'app_admin') {
              return res.status(403).json({
                error: 'निषिद्ध: यह कार्रवाई केवल एप्लिकेशन व्यवस्थापक (Application Admin) द्वारा ही संभव है।',
              });
            }
            (req as any).adminUser = {
              id: adminRow.id,
              email: adminRow.email,
              role: adminRow.role,
              fullName: adminRow.full_name,
            };
            return next();
          }
        }
      } catch (err) {
        console.warn('[AUTH] Supabase token check error:', err);
      }
    }

    return res.status(401).json({
      error: 'अमान्य या समाप्त व्यवस्थापक सत्र। कृपया पुनः लॉगिन करें। (Invalid or expired admin session)',
    });
  };
}

// ============================================================================
// PUBLIC BOOTSTRAP & AUTH METHODS CONFIGURATION
// ============================================================================

app.get('/api/bootstrap', async (_req, res) => {
  const db = loadLocalDb();
  let authConfig = db.authMethodsConfig;

  if (supabase) {
    try {
      const { data: cfg } = await supabase
        .from('auth_methods_config')
        .select('*')
        .eq('id', 'current')
        .maybeSingle();
      if (cfg) {
        authConfig = {
          emailPasswordEnabled: cfg.email_password_enabled,
          emailOtpEnabled: cfg.email_otp_enabled,
          googleAuthEnabled: cfg.google_auth_enabled,
          phoneOtpEnabled: cfg.phone_otp_enabled,
          whatsappOtpEnabled: cfg.whatsapp_otp_enabled,
          updatedAt: cfg.updated_at,
        };
      }
    } catch {}
  }

  res.json({
    config: db.config,
    products: db.products,
    inquiries: db.inquiries,
    authMethodsConfig: authConfig,
    supabase: {
      connected: Boolean(supabase),
      mode: supabase ? 'supabase-postgres' : 'local-json-fallback',
      projectUrl: SUPABASE_URL || null,
    },
    updatedAt: new Date().toISOString(),
  });
});

app.get('/api/auth-methods', async (_req, res) => {
  const db = loadLocalDb();
  let authConfig: AuthMethodsConfig = db.authMethodsConfig || {
    emailPasswordEnabled: true,
    emailOtpEnabled: true,
    googleAuthEnabled: true,
    phoneOtpEnabled: false,
    whatsappOtpEnabled: false,
  };

  if (supabase) {
    try {
      const { data: cfg } = await supabase
        .from('auth_methods_config')
        .select('*')
        .eq('id', 'current')
        .maybeSingle();
      if (cfg) {
        authConfig = {
          emailPasswordEnabled: cfg.email_password_enabled,
          emailOtpEnabled: cfg.email_otp_enabled,
          googleAuthEnabled: cfg.google_auth_enabled,
          phoneOtpEnabled: cfg.phone_otp_enabled,
          whatsappOtpEnabled: cfg.whatsapp_otp_enabled,
          updatedAt: cfg.updated_at,
        };
      }
    } catch {}
  }

  res.json(authConfig);
});

// Update Auth Methods (App Admin only)
app.put('/api/admin/auth-methods', requireAdmin('app_admin'), async (req, res) => {
  const payload = sanitizeInput(req.body || {});
  const db = loadLocalDb();

  const newConfig: AuthMethodsConfig = {
    emailPasswordEnabled: payload.emailPasswordEnabled ?? db.authMethodsConfig.emailPasswordEnabled,
    emailOtpEnabled: payload.emailOtpEnabled ?? db.authMethodsConfig.emailOtpEnabled,
    googleAuthEnabled: payload.googleAuthEnabled ?? db.authMethodsConfig.googleAuthEnabled,
    phoneOtpEnabled: payload.phoneOtpEnabled ?? db.authMethodsConfig.phoneOtpEnabled,
    whatsappOtpEnabled: payload.whatsappOtpEnabled ?? db.authMethodsConfig.whatsappOtpEnabled,
    updatedAt: new Date().toISOString(),
  };

  db.authMethodsConfig = newConfig;
  saveLocalDb(db);

  if (supabase) {
    try {
      await supabase.from('auth_methods_config').upsert({
        id: 'current',
        email_password_enabled: newConfig.emailPasswordEnabled,
        email_otp_enabled: newConfig.emailOtpEnabled,
        google_auth_enabled: newConfig.googleAuthEnabled,
        phone_otp_enabled: newConfig.phoneOtpEnabled,
        whatsapp_otp_enabled: newConfig.whatsappOtpEnabled,
        updated_at: newConfig.updatedAt,
      });
    } catch (err) {
      console.warn('[AUTH CONFIG] Supabase sync error:', err);
    }
  }

  res.json({ success: true, authMethodsConfig: newConfig });
});

// ============================================================================
// GENUINE ADMIN AUTHENTICATION, ROLES (App Admin & Shop Owner) & MFA
// ============================================================================

app.post('/api/admin/login', async (req, res) => {
  const { email = '', identifier = '', password = '', expectedRole = '' } = sanitizeInput(
    req.body || {}
  );
  const loginEmail = String(email || identifier).trim().toLowerCase();
  const cleanPass = String(password).trim();

  if (!loginEmail || !loginEmail.includes('@')) {
    return res.status(400).json({
      authenticated: false,
      error: 'कृपया एक वैध व्यवस्थापक ईमेल पता दर्ज करें (उदा. vikashchaurasia9517@gmail.com)।',
    });
  }

  if (!cleanPass || cleanPass.length < 4) {
    return res.status(400).json({
      authenticated: false,
      error: 'कृपया व्यवस्थापक पासवर्ड दर्ज करें (कम से कम 4 अक्षर)।',
    });
  }

  if (cleanPass === '1234') {
    return res.status(401).json({
      authenticated: false,
      error: 'डिफ़ॉल्ट पिन 1234 सुरक्षा कारणों से हटा दिया गया है। कृपया अपने अधिकृत एडमिन पासवर्ड का उपयोग करें।',
    });
  }

  const db = loadLocalDb();
  let supabaseErrorMsg = '';

  // 1. Direct Supabase Auth Verification via fresh client (avoids global client session pollution)
  const authClient = createFreshAuthClient();
  if (authClient && supabase) {
    try {
      const { data: authData, error: authError } = await authClient.auth.signInWithPassword({
        email: loginEmail,
        password: cleanPass,
      });

      if (authError) {
        supabaseErrorMsg = authError.message;
      } else if (authData?.user) {
        const userId = authData.user.id;

        // Look up in admin_users by ID OR Email (handles UID out-of-sync gracefully)
        let { data: adminRow } = await supabase
          .from('admin_users')
          .select('*')
          .or(`id.eq.${userId},email.ilike.${loginEmail}`)
          .maybeSingle();

        // Auto-Heal / Auto-Provision if it is the First App Admin or Shop Owner email
        if (!adminRow && FIRST_APP_ADMIN_EMAILS.includes(loginEmail)) {
          const newAdminPayload = {
            id: userId,
            email: loginEmail,
            full_name: 'प्रो. विकास चौरसिया (App Admin)',
            role: 'app_admin',
            phone: '9876543210',
            mfa_enabled: false,
          };
          const { data: insertedRow } = await supabase
            .from('admin_users')
            .upsert(newAdminPayload, { onConflict: 'id' })
            .select('*')
            .maybeSingle();

          adminRow = insertedRow || newAdminPayload;
        } else if (!adminRow && SHOP_OWNER_EMAILS.includes(loginEmail)) {
          const newOwnerPayload = {
            id: userId,
            email: loginEmail,
            full_name: 'बाबा फर्नीचर शोरूम संचालक (Shop Owner)',
            role: 'shop_owner',
            phone: '9876543210',
            mfa_enabled: false,
          };
          const { data: insertedRow } = await supabase
            .from('admin_users')
            .upsert(newOwnerPayload, { onConflict: 'id' })
            .select('*')
            .maybeSingle();

          adminRow = insertedRow || newOwnerPayload;
        }

        // Also check local db.adminTeam if RLS hid the row
        const localMatch = (db.adminTeam || []).find(
          (a: any) => String(a.email).toLowerCase() === loginEmail
        );
        if (!adminRow && localMatch) {
          adminRow = {
            id: userId,
            email: loginEmail,
            full_name: localMatch.fullName || localMatch.ownerName,
            role: localMatch.role,
            phone: localMatch.phone,
            mfa_enabled: localMatch.mfaEnabled,
          };
        }

        if (!adminRow) {
          return res.status(403).json({
            authenticated: false,
            error: `अनधिकृत: ईमेल (${loginEmail}) सत्यापित है, परंतु इसे व्यवस्थापक (Admin / Shop Owner) का अधिकार प्राप्त नहीं है। ग्राहक कृपया मुख्य पेज पर "ग्राहक लॉगिन" का उपयोग करें।`,
          });
        }

        const role: AdminRole =
          FIRST_APP_ADMIN_EMAILS.includes(loginEmail) || adminRow.role === 'app_admin'
            ? 'app_admin'
            : 'shop_owner';

        if (expectedRole === 'app_admin' && role !== 'app_admin') {
          return res.status(403).json({
            authenticated: false,
            error:
              'यह खाता "Shop Owner (दुकान संचालक)" का है। कृपया ऊपर "Shop Owner" विकल्प चुनकर लॉगिन करें।',
          });
        }

        const adminProfile = {
          id: adminRow.id || userId,
          email: loginEmail,
          ownerName: adminRow.full_name || 'प्रो. विकास चौरसिया',
          role,
          roleTitle:
            role === 'app_admin'
              ? 'Application Administrator (सिस्टम प्रशासक)'
              : 'Shop Owner (दुकान संचालक)',
          phone: adminRow.phone || '9876543210',
          mfaEnabled: Boolean(adminRow.mfa_enabled),
        };

        if (adminProfile.mfaEnabled) {
          const challengeId = `mfa-${crypto.randomBytes(12).toString('hex')}`;
          const code = Math.floor(100000 + Math.random() * 900000).toString();
          mfaChallenges.set(challengeId, {
            id: challengeId,
            adminId: adminProfile.id,
            email: adminProfile.email,
            role,
            code,
            adminProfile,
            expiresAt: Date.now() + 5 * 60 * 1000,
          });

          console.log(
            `[🔐 ADMIN MFA] Verification code for ${adminProfile.email}: ${code} (Challenge ID: ${challengeId})`
          );

          return res.json({
            authenticated: false,
            mfaRequired: true,
            challengeId,
            message: 'कृपया 6-अंकों का 2-स्टेप सत्यापन (MFA) कोड दर्ज करें।',
          });
        }

        const token = generateAdminToken({ id: adminProfile.id, email: adminProfile.email, role });
        return res.json({
          authenticated: true,
          token,
          admin: adminProfile,
          supabase: { connected: true, mode: 'supabase-direct' },
        });
      }
    } catch (err: any) {
      console.warn('[ADMIN LOGIN] Supabase signInWithPassword note:', err?.message || err);
    }
  }

  // 2. Fallback / Direct Verified Admin & Shop Owner Credentials
  const envAdminEmail = (
    process.env.ADMIN_INITIAL_EMAIL ||
    process.env.ADMIN_EMAIL ||
    'vikashchaurasia9517@gmail.com'
  )
    .toLowerCase()
    .trim();
  const envAdminPass = (
    process.env.ADMIN_INITIAL_PASSWORD ||
    process.env.ADMIN_PASSWORD ||
    'Vikash@9118#'
  ).trim();

  const shopOwnerEmail = (process.env.SHOP_OWNER_EMAIL || 'owner@babafurnitureudyog.com')
    .toLowerCase()
    .trim();
  const shopOwnerPass = (process.env.SHOP_OWNER_PASSWORD || 'Owner@9118#').trim();

  const localTeam = db.adminTeam || [];
  const foundAdmin = localTeam.find((a: any) => String(a.email).toLowerCase() === loginEmail);

  let matchedRole: AdminRole | null = null;
  let matchedName = '';

  if (
    (loginEmail === envAdminEmail || loginEmail === 'vikashchaurasia9517@gmail.com' || loginEmail === 'admin@babafurnitureudyog.com') &&
    cleanPass === envAdminPass
  ) {
    matchedRole = 'app_admin';
    matchedName = foundAdmin?.fullName || 'प्रो. विकास चौरसिया (App Admin)';
  } else if (loginEmail === shopOwnerEmail && cleanPass === shopOwnerPass) {
    matchedRole = 'shop_owner';
    matchedName = foundAdmin?.fullName || 'बाबा फर्नीचर शोरूम संचालक (Shop Owner)';
  } else if (
    foundAdmin &&
    (foundAdmin.passwordHash === sha256Hex(cleanPass) || foundAdmin.password === cleanPass)
  ) {
    matchedRole = foundAdmin.role === 'app_admin' ? 'app_admin' : 'shop_owner';
    matchedName = foundAdmin.fullName || foundAdmin.ownerName || 'Admin';
  }

  if (matchedRole) {
    if (expectedRole === 'app_admin' && matchedRole !== 'app_admin') {
      return res.status(403).json({
        authenticated: false,
        error:
          'यह खाता "Shop Owner (दुकान संचालक)" का है। कृपया ऊपर "Shop Owner" विकल्प चुनकर लॉगिन करें।',
      });
    }

    const adminProfile = {
      id: foundAdmin?.id || (matchedRole === 'app_admin' ? 'admin-app-1' : 'admin-shop-1'),
      email: loginEmail,
      ownerName: matchedName,
      role: matchedRole,
      roleTitle:
        matchedRole === 'app_admin'
          ? 'Application Administrator (सिस्टम प्रशासक)'
          : 'Shop Owner (दुकान संचालक)',
      phone: foundAdmin?.phone || '9876543210',
      mfaEnabled: Boolean(foundAdmin?.mfaEnabled),
    };

    if (adminProfile.mfaEnabled) {
      const challengeId = `mfa-${crypto.randomBytes(12).toString('hex')}`;
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      mfaChallenges.set(challengeId, {
        id: challengeId,
        adminId: adminProfile.id,
        email: adminProfile.email,
        role: matchedRole,
        code,
        adminProfile,
        expiresAt: Date.now() + 5 * 60 * 1000,
      });

      console.log(`[🔐 ADMIN MFA] Verification code for ${adminProfile.email}: ${code}`);

      return res.json({
        authenticated: false,
        mfaRequired: true,
        challengeId,
        message: 'कृपया 6-अंकों का 2-स्टेप सत्यापन (MFA) कोड दर्ज करें।',
      });
    }

    const token = generateAdminToken({
      id: adminProfile.id,
      email: adminProfile.email,
      role: matchedRole,
    });
    return res.json({
      authenticated: true,
      token,
      admin: adminProfile,
      supabase: {
        connected: Boolean(supabase),
        mode: supabase ? 'supabase-postgres' : 'local-json-fallback',
      },
    });
  }

  const isKnownAdminEmail =
    FIRST_APP_ADMIN_EMAILS.includes(loginEmail) ||
    SHOP_OWNER_EMAILS.includes(loginEmail) ||
    Boolean(foundAdmin);

  return res.status(401).json({
    authenticated: false,
    error: isKnownAdminEmail
      ? 'दर्ज किया गया पासवर्ड गलत है। कृपया पासवर्ड में बड़े/छोटे अक्षर और चिन्ह (@, #) की जाँच करें। (Invalid password for this admin account)'
      : `यह ईमेल (${loginEmail}) व्यवस्थापक (App Admin / Shop Owner) के रूप में पंजीकृत नहीं है। कृपया अधिकृत एडमिन ईमेल दर्ज करें।`,
    debugHint: supabaseErrorMsg || undefined,
  });
});

// Verify 2-Step MFA Code
app.post('/api/admin/verify-mfa', (req, res) => {
  const { challengeId = '', code = '' } = sanitizeInput(req.body || {});
  const challenge = mfaChallenges.get(String(challengeId));

  if (!challenge || Date.now() > challenge.expiresAt) {
    mfaChallenges.delete(String(challengeId));
    return res.status(400).json({
      authenticated: false,
      error: 'MFA कोड सत्र समाप्त हो गया है। कृपया पुनः लॉगिन करें।',
    });
  }

  if (String(code).trim() !== challenge.code) {
    return res.status(401).json({
      authenticated: false,
      error: 'अमान्य MFA सत्यापन कोड (Invalid 6-digit code).',
    });
  }

  mfaChallenges.delete(String(challengeId));

  const token = generateAdminToken({
    id: challenge.adminId,
    email: challenge.email,
    role: challenge.role,
  });

  return res.json({
    authenticated: true,
    token,
    admin: challenge.adminProfile,
  });
});

// Toggle MFA for authenticated admin
app.post('/api/admin/mfa/toggle', requireAdmin(), async (req, res) => {
  const adminUser = (req as any).adminUser;
  const { enabled } = req.body;
  const isEnabled = Boolean(enabled);

  const db = loadLocalDb();
  db.adminTeam = (db.adminTeam || []).map((a: any) =>
    a.id === adminUser.id || a.email === adminUser.email ? { ...a, mfaEnabled: isEnabled } : a
  );
  saveLocalDb(db);

  if (supabase) {
    try {
      await supabase.from('admin_users').update({ mfa_enabled: isEnabled }).eq('id', adminUser.id);
    } catch (err) {
      console.warn('[MFA TOGGLE] Supabase update note:', err);
    }
  }

  res.json({ success: true, mfaEnabled: isEnabled });
});

// Get Current Admin Info
app.get('/api/admin/me', requireAdmin(), (req, res) => {
  res.json({ admin: (req as any).adminUser });
});

// ============================================================================
// ADMIN TEAM MANAGEMENT & SECURE INVITATIONS (App Admin Only)
// ============================================================================

app.get('/api/admin/team', requireAdmin('app_admin'), async (_req, res) => {
  const db = loadLocalDb();
  let admins = db.adminTeam || [];
  let invitations = db.invitations || [];

  if (supabase) {
    try {
      const { data: adminRows } = await supabase.from('admin_users').select('*');
      if (adminRows && adminRows.length > 0) {
        const sbAdmins = adminRows.map((r: any) => ({
          id: r.id,
          email: r.email,
          fullName: r.full_name,
          ownerName: r.full_name,
          role: r.role,
          phone: r.phone,
          mfaEnabled: r.mfa_enabled,
          createdAt: r.created_at,
        }));
        const existingEmails = new Set(sbAdmins.map((a: any) => String(a.email).toLowerCase()));
        const localExtras = admins.filter(
          (a: any) => !existingEmails.has(String(a.email).toLowerCase())
        );
        admins = [...sbAdmins, ...localExtras];
      }
      const { data: invRows } = await supabase.from('admin_invitations').select('*');
      if (invRows) {
        invitations = invRows;
      }
    } catch {}
  }

  res.json({ admins, invitations });
});

// Create or Provision a Shop Owner / Admin Account directly with Password (App Admin Only)
app.post('/api/admin/team/create', requireAdmin('app_admin'), async (req, res) => {
  const {
    email = '',
    fullName = '',
    password = '',
    role = 'shop_owner',
    phone = '9876543210',
  } = sanitizeInput(req.body || {});
  const cleanEmail = String(email).trim().toLowerCase();
  const cleanPass = String(password).trim();
  const assignedRole: AdminRole = role === 'app_admin' ? 'app_admin' : 'shop_owner';

  if (!cleanEmail || !cleanEmail.includes('@')) {
    return res.status(400).json({ error: 'कृपया वैध ईमेल पता दर्ज करें।' });
  }
  if (cleanPass.length < 6) {
    return res
      .status(400)
      .json({ error: 'सुरक्षा के लिए पासवर्ड कम से कम 6 अक्षरों का होना चाहिए।' });
  }

  const displayName =
    fullName.trim() ||
    (assignedRole === 'app_admin'
      ? 'System Administrator (App Admin)'
      : 'बाबा फर्नीचर शोरूम संचालक (Shop Owner)');

  let createdId = `adm-${Date.now()}`;

  // Try creating in Supabase Auth if service role key is present
  if (supabase && (supabase.auth as any).admin?.createUser) {
    try {
      const { data: createdAuth, error: createErr } = await (
        supabase.auth as any
      ).admin.createUser({
        email: cleanEmail,
        password: cleanPass,
        email_confirm: true,
        user_metadata: { full_name: displayName, role: assignedRole },
      });
      if (!createErr && createdAuth?.user) {
        createdId = createdAuth.user.id;
        await supabase.from('admin_users').upsert(
          {
            id: createdId,
            email: cleanEmail,
            full_name: displayName,
            role: assignedRole,
            phone: String(phone),
            mfa_enabled: false,
          },
          { onConflict: 'id' }
        );
      }
    } catch {}
  }

  const db = loadLocalDb();
  const newMember = {
    id: createdId,
    email: cleanEmail,
    fullName: displayName,
    ownerName: displayName,
    role: assignedRole,
    phone: String(phone),
    passwordHash: sha256Hex(cleanPass),
    mfaEnabled: false,
    createdAt: new Date().toISOString(),
  };

  db.adminTeam = [
    newMember,
    ...(db.adminTeam || []).filter((a: any) => String(a.email).toLowerCase() !== cleanEmail),
  ];
  saveLocalDb(db);

  res.json({
    success: true,
    member: {
      id: newMember.id,
      email: newMember.email,
      fullName: newMember.fullName,
      ownerName: newMember.ownerName,
      role: newMember.role,
      phone: newMember.phone,
    },
    message: `${displayName} (${assignedRole === 'app_admin' ? 'Application Admin' : 'Shop Owner'}) खाता सफलतापूर्वक सक्रिय किया गया!`,
  });
});

app.post('/api/admin/invite', requireAdmin('app_admin'), async (req, res) => {
  const { email = '', role = 'shop_owner', password = '', fullName = '' } = sanitizeInput(
    req.body || {}
  );
  const cleanEmail = String(email).trim().toLowerCase();
  const assignedRole: AdminRole = role === 'app_admin' ? 'app_admin' : 'shop_owner';

  if (!cleanEmail || !cleanEmail.includes('@')) {
    return res.status(400).json({ error: 'कृपया वैध ईमेल पता दर्ज करें।' });
  }

  const db = loadLocalDb();

  // If password is provided in the invite form, also register them immediately in adminTeam so they can sign in right away
  if (password && String(password).trim().length >= 6) {
    const cleanPass = String(password).trim();
    const displayName =
      fullName ||
      (assignedRole === 'app_admin'
        ? 'Application Admin'
        : 'शोरूम संचालक (Shop Owner)');
    const newMember = {
      id: `adm-${Date.now()}`,
      email: cleanEmail,
      fullName: displayName,
      ownerName: displayName,
      role: assignedRole,
      phone: '9876543210',
      passwordHash: sha256Hex(cleanPass),
      mfaEnabled: false,
      createdAt: new Date().toISOString(),
    };
    db.adminTeam = [
      newMember,
      ...(db.adminTeam || []).filter((a: any) => String(a.email).toLowerCase() !== cleanEmail),
    ];
  }

  const token = `inv-${crypto.randomBytes(24).toString('hex')}`;
  const invitation = {
    id: `inv-${Date.now()}`,
    email: cleanEmail,
    role: assignedRole,
    token,
    status: 'pending',
    expiresAt: new Date(Date.now() + 7 * 86400 * 1000).toISOString(),
    createdAt: new Date().toISOString(),
  };

  db.invitations = [
    invitation,
    ...(db.invitations || []).filter((i: any) => i.email !== cleanEmail),
  ];
  saveLocalDb(db);

  if (supabase) {
    try {
      await supabase.from('admin_invitations').insert({
        email: cleanEmail,
        role: assignedRole,
        token,
        status: 'pending',
        expires_at: invitation.expiresAt,
      });

      if ((supabase.auth as any).admin?.inviteUserByEmail) {
        await (supabase.auth as any).admin.inviteUserByEmail(cleanEmail, {
          data: { role: assignedRole },
        });
      }
    } catch (err: any) {
      console.warn('[ADMIN INVITE] Supabase invitation note:', err?.message || err);
    }
  }

  res.json({
    success: true,
    invitation,
    message: `खाता / आमंत्रण सफलतापूर्वक सक्रिय किया गया (${assignedRole === 'app_admin' ? 'Application Admin' : 'Shop Owner'}).`,
  });
});

app.delete('/api/admin/invitations/:id', requireAdmin('app_admin'), async (req, res) => {
  const db = loadLocalDb();
  db.invitations = (db.invitations || []).filter(
    (i: any) => i.id !== req.params.id && i.token !== req.params.id
  );
  saveLocalDb(db);

  if (supabase) {
    try {
      await supabase.from('admin_invitations').delete().eq('id', req.params.id);
    } catch {}
  }

  res.json({ success: true });
});

app.delete('/api/admin/team/:id', requireAdmin('app_admin'), async (req, res) => {
  const currentAdmin = (req as any).adminUser;
  if (req.params.id === currentAdmin.id) {
    return res.status(400).json({ error: 'आप अपना स्वयं का व्यवस्थापक खाता यहाँ से नहीं हटा सकते।' });
  }

  const db = loadLocalDb();
  db.adminTeam = (db.adminTeam || []).filter((a: any) => a.id !== req.params.id);
  saveLocalDb(db);

  if (supabase) {
    try {
      await supabase.from('admin_users').delete().eq('id', req.params.id);
    } catch {}
  }

  res.json({ success: true });
});

// ============================================================================
// IN-APP LIVE CHAT ENDPOINTS (Direct Website Customer <-> Shop Owner Chat)
// ============================================================================

function getSmartWorkshopReply(
  text: string,
  lang: 'hi' | 'en',
  config: any
): { reply: string; suggestedAction?: any } {
  const lower = text.toLowerCase();

  if (
    lower.includes('बेड') ||
    lower.includes('bed') ||
    lower.includes('king') ||
    lower.includes('किंग') ||
    lower.includes('पलंग')
  ) {
    return {
      reply:
        lang === 'hi'
          ? 'हमारे पास महाराजा रॉयल सागवान किंग साइज बेड (78"x72", ₹48,500) और शीशम फ्लोटिंग बॉक्स बेड (₹34,500) उपलब्ध हैं। सभी बेड्स में हैवी-ड्यूटी हाइड्रोलिक स्टोरेज और 10 साल की लिखित दीमक गारंटी मिलती है। आप अपना नाम व नंबर छोड़ दें, हमारे शोरूम संचालक इसी चैट में आपको रिप्लाई करेंगे!'
          : 'We craft Maharaja Solid Teak King Beds (78"x72", ₹48,500) and Sheesham Box Beds (₹34,500) with heavy hydraulic storage and a 10-year written termite warranty. Our showroom owner has been notified and will reply right here in this chat!',
      suggestedAction: {
        type: 'catalog',
        label: lang === 'hi' ? '📖 बेड्स कैटलॉग देखें' : '📖 View Beds Catalog',
      },
    };
  }

  if (
    lower.includes('सागवान') ||
    lower.includes('शीशम') ||
    lower.includes('teak') ||
    lower.includes('sheesham') ||
    lower.includes('wood') ||
    lower.includes('लकड़ी')
  ) {
    return {
      reply:
        lang === 'hi'
          ? 'सागवान (Grade-A Solid Teak) में कुदरती तेल और सिलिका भरपूर होता है जिससे यह 100% दीमक-रोधी और 50+ वर्षों तक टिकाऊ रहता है। भारतीय शीशम (Pure Sheesham) अपनी गहरी कुदरती नसों और भारी वजन सहने की क्षमता के लिए जाना जाता है। दोनों लकड़ियाँ हमारे कारखाने में क्लिन-सीजन (Kiln-Seasoned) की जाती हैं।'
          : 'Grade-A Solid Teak contains natural oils offering 100% termite immunity (50+ yrs lifespan). Pure Indian Sheesham provides dense interlocking grain ideal for heavy load-bearing furniture. Both are kiln-seasoned at our workshop.',
      suggestedAction: {
        type: 'chart',
        label: lang === 'hi' ? '📊 लाइव लकड़ी तुलना चार्ट देखें' : '📊 View Wood Spec Chart',
      },
    };
  }

  if (
    lower.includes('कस्टम') ||
    lower.includes('custom') ||
    lower.includes('साइज') ||
    lower.includes('नाप') ||
    lower.includes('डिज़ाइन') ||
    lower.includes('design')
  ) {
    return {
      reply:
        lang === 'hi'
          ? 'जी हाँ! आप अपने कमरे के सटीक नाप या किसी भी फोटो/डिज़ाइन के अनुसार कस्टम फर्नीचर बनवा सकते हैं। नीचे दिए गए बटन से अपना डिज़ाइन या नाप अपलोड करें, या यहीं चैट में विवरण लिखें।'
          : 'Yes! We custom-craft furniture according to your exact room dimensions and reference photos. Click below to open the Custom Design Blueprint tool or share your details right here.',
      suggestedAction: {
        type: 'custom_order',
        label: lang === 'hi' ? '✨ कस्टम डिज़ाइन फॉर्म खोलें' : '✨ Open Custom Design Builder',
      },
    };
  }

  if (
    lower.includes('दुकान') ||
    lower.includes('पता') ||
    lower.includes('address') ||
    lower.includes('timing') ||
    lower.includes('समय') ||
    lower.includes('कहाँ') ||
    lower.includes('location')
  ) {
    return {
      reply:
        lang === 'hi'
          ? `📍 हमारा शोरूम पता: ${config.address}, ${config.cityState}\n🕒 खुलने का समय: ${config.timings}\n📞 सीधा संपर्क: ${config.phone}\nआपका संदेश शोरूम संचालक को भेज दिया गया है, वे शीघ्र ही यहाँ चैट पर उत्तर देंगे।`
          : `📍 Showroom Address: ${config.address}, ${config.cityState}\n🕒 Timings: ${config.timings}\n📞 Direct Phone: ${config.phone}\nYour message has been delivered to the showroom owner in real time.`,
      suggestedAction: {
        type: 'call',
        label: lang === 'hi' ? '📞 शोरूम पर कॉल करें' : '📞 Call Showroom',
      },
    };
  }

  if (
    lower.includes('चार्ट') ||
    lower.includes('chart') ||
    lower.includes('टेबल') ||
    lower.includes('specs')
  ) {
    return {
      reply:
        lang === 'hi'
          ? 'हमने सागवान व शीशम लकड़ी की मजबूती, नमी स्तर, वारंटी और कमरे के स्टैंडर्ड साइज का लाइव चार्ट तैयार किया है। नीचे बटन दबाकर देखें:'
          : 'Explore our interactive Live Timber & Dimension Specification Chart below:',
      suggestedAction: {
        type: 'chart',
        label: lang === 'hi' ? '📊 लाइव चार्ट खोलें' : '📊 Open Live Chart',
      },
    };
  }

  return {
    reply:
      lang === 'hi'
        ? `आपका संदेश शोरूम संचालक (${config.ownerName}) के लाइव चैट पैनल में भेज दिया गया है! वे इसी चैट विंडो में आपको सीधा जवाब देंगे। तब तक आप अपना मोबाइल नंबर या फर्नीचर की आवश्यकता भी यहाँ लिख सकते हैं।`
        : `Your message has been delivered directly to our Showroom Owner (${config.ownerName})! They will reply to you right here in this live chat window. Feel free to share your phone number or specific requirements below.`,
    suggestedAction: {
      type: 'custom_order',
      label: lang === 'hi' ? '📐 कस्टम कोटेशन भेजें' : '📐 Request Custom Quote',
    },
  };
}

// Get chat session history for a customer
app.get('/api/chat/session/:sessionId', (req, res) => {
  const db = loadLocalDb();
  const session = (db.chatSessions || []).find((s: any) => s.id === req.params.sessionId);
  if (session) {
    session.unreadForCustomer = 0;
    saveLocalDb(db);
    return res.json({ session });
  }
  return res.json({ session: null });
});

// Send chat message (Supports both legacy /api/chat and session-based real-time owner chat)
app.post('/api/chat', (req, res) => {
  const {
    message = '',
    lang = 'hi',
    sessionId = 'default-session',
    customerName = 'ग्राहक (Guest)',
    customerPhone = '',
    customerEmail = '',
  } = sanitizeInput(req.body || {});

  const cleanText = String(message).trim();
  if (!cleanText) {
    return res.status(400).json({ error: 'कृपया संदेश लिखें।' });
  }

  const db = loadLocalDb();
  if (!db.chatSessions) db.chatSessions = [];

  const sid = String(sessionId || 'default-session');
  let session: LiveChatSession = db.chatSessions.find((s: any) => s.id === sid);

  const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  if (!session) {
    session = {
      id: sid,
      customerName: customerName || 'ग्राहक (Guest)',
      customerPhone: customerPhone || '',
      customerEmail: customerEmail || '',
      unreadForAdmin: 0,
      unreadForCustomer: 0,
      updatedAt: Date.now(),
      messages: [
        {
          id: 'welcome-1',
          sender: 'shop',
          senderName: 'बाबा फर्नीचर शोरूम',
          text:
            lang === 'hi'
              ? 'नमस्ते! 🙏 बाबा फर्नीचर उद्योग में आपका स्वागत है। हम 100% असली सागवान (Teak) और शीशम (Sheesham) की लकड़ी से टिकाऊ फर्नीचर तैयार करते हैं।\n\nआप यहाँ सीधे शोरूम मालिक से बात कर सकते हैं:'
              : 'Hello! 🙏 Welcome to Baba Furniture Udyog. Chat directly with our showroom owner and workshop team right here:',
          timestamp: Date.now() - 1000,
          formattedTime: lang === 'hi' ? 'अभी' : 'Just now',
        },
      ],
    };
    db.chatSessions.unshift(session);
  }

  if (customerName && customerName !== 'ग्राहक (Guest)') session.customerName = customerName;
  if (customerPhone) session.customerPhone = customerPhone;
  if (customerEmail) session.customerEmail = customerEmail;

  const userMsg = {
    id: `usr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    sender: 'user' as const,
    senderName: session.customerName || 'ग्राहक',
    text: cleanText,
    timestamp: Date.now(),
    formattedTime: nowTime,
  };
  session.messages.push(userMsg);
  session.unreadForAdmin = (session.unreadForAdmin || 0) + 1;
  session.updatedAt = Date.now();

  // Generate helpful instant workshop assistant response while notifying owner
  const smart = getSmartWorkshopReply(cleanText, lang === 'en' ? 'en' : 'hi', db.config);

  const autoShopMsg = {
    id: `shop-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    sender: 'shop' as const,
    senderName: 'बाबा फर्नीचर सहायता (Auto-Assistant)',
    text: smart.reply,
    timestamp: Date.now() + 10,
    formattedTime: nowTime,
    suggestedAction: smart.suggestedAction,
  };
  session.messages.push(autoShopMsg);

  saveLocalDb(db);

  res.json({
    reply: smart.reply,
    suggestedAction: smart.suggestedAction,
    session,
    source: 'in-app-live-chat',
  });
});

// Admin / Shop Owner fetches all customer live chat sessions
app.get('/api/admin/chats', requireAdmin(), (_req, res) => {
  const db = loadLocalDb();
  const sessions = (db.chatSessions || []).sort(
    (a: any, b: any) => (b.updatedAt || 0) - (a.updatedAt || 0)
  );
  res.json({ sessions });
});

// Admin / Shop Owner replies directly to a customer's live chat session
app.post('/api/admin/chats/:sessionId/reply', requireAdmin(), (req, res) => {
  const { text = '' } = sanitizeInput(req.body || {});
  const cleanReply = String(text).trim();
  if (!cleanReply) {
    return res.status(400).json({ error: 'कृपया उत्तर संदेश लिखें।' });
  }

  const db = loadLocalDb();
  const session = (db.chatSessions || []).find((s: any) => s.id === req.params.sessionId);
  if (!session) {
    return res.status(404).json({ error: 'चैट सत्र नहीं मिला।' });
  }

  const adminUser = (req as any).adminUser;
  const senderTitle =
    adminUser?.role === 'app_admin'
      ? 'प्रो. विकास चौरसिया (App Admin)'
      : 'शोरूम संचालक (Shop Owner)';

  const replyMsg = {
    id: `owner-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    sender: 'shop' as const,
    senderName: senderTitle,
    text: `👨‍💼 [${senderTitle}]: ${cleanReply}`,
    timestamp: Date.now(),
    formattedTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  };

  session.messages.push(replyMsg);
  session.updatedAt = Date.now();
  session.unreadForAdmin = 0;
  session.unreadForCustomer = (session.unreadForCustomer || 0) + 1;

  saveLocalDb(db);
  res.json({ success: true, session, message: replyMsg });
});

// ============================================================================
// CUSTOMER AUTH & AUDITABLE ACCOUNT DELETION
// ============================================================================

app.post('/api/users/register', (req, res) => {
  const { name = '', phone = '', email = '', city = 'Gorakhpur', password = '' } = sanitizeInput(
    req.body || {}
  );
  const cleanPhone = String(phone).replace(/[^0-9]/g, '').slice(-10);
  if (!name || cleanPhone.length !== 10 || String(password).length < 4) {
    return res.status(400).json({
      authenticated: false,
      error: 'कृपया पूरा नाम, 10-अंकों का मोबाइल नंबर और कम से कम 4 अक्षरों का पासवर्ड भरें।',
    });
  }
  const db = loadLocalDb();
  const userObj = {
    id: `CUST-${cleanPhone.slice(-4)}`,
    name,
    phone: cleanPhone,
    email,
    city,
    passwordHash: sha256Hex(String(password)),
    createdAt: new Date().toISOString(),
  };
  db.customers = [
    userObj,
    ...(db.customers || []).filter(
      (c: any) => String(c.phone || '').replace(/[^0-9]/g, '').slice(-10) !== cleanPhone
    ),
  ];
  saveLocalDb(db);
  return res.json({
    authenticated: true,
    user: { id: userObj.id, name, phone: cleanPhone, email, city },
  });
});

app.post('/api/users/login', (req, res) => {
  const { identifier = '', password = '' } = sanitizeInput(req.body || {});
  const cleanPhone = String(identifier).replace(/[^0-9]/g, '').slice(-10);
  const passHash = sha256Hex(String(password));
  const db = loadLocalDb();
  const found = (db.customers || []).find(
    (c: any) =>
      !c.isDeleted &&
      (String(c.phone || '').replace(/[^0-9]/g, '').slice(-10) === cleanPhone ||
        String(c.email || '').toLowerCase() === String(identifier).trim().toLowerCase()) &&
      c.passwordHash === passHash
  );
  if (found) {
    return res.json({
      authenticated: true,
      user: {
        id: found.id,
        name: found.name,
        phone: found.phone,
        email: found.email,
        city: found.city,
        mobileVerified: found.mobileVerified,
        emailVerified: found.emailVerified,
      },
    });
  }
  return res.status(401).json({
    authenticated: false,
    error: 'ग्राहक मोबाइल/ईमेल या पासवर्ड गलत है। यदि आपका खाता नहीं है तो कृपया पहले नया खाता (Sign Up) बनाएं।',
  });
});

// Genuine Secure Customer Account Deletion with Audit Log & Data Anonymization
app.post('/api/auth/delete-account', async (req, res) => {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ')
    ? authHeader.slice(7).trim()
    : String(req.body?.token || '').trim();
  const { confirmationText = '', email = '', phone = '' } = sanitizeInput(req.body || {});

  if (confirmationText !== 'DELETE') {
    return res.status(400).json({
      success: false,
      error: 'खाता हटाने के लिए कृपया पुष्टि बॉक्स में "DELETE" टाइप करें (Type DELETE to confirm).',
    });
  }

  let verifiedUserId = '';
  let verifiedEmail = String(email).trim().toLowerCase();
  const cleanPhone = String(phone).replace(/[^0-9]/g, '').slice(-10);

  if (supabase && token) {
    try {
      const { data: userData, error: userError } = await supabase.auth.getUser(token);
      if (!userError && userData?.user) {
        verifiedUserId = userData.user.id;
        verifiedEmail = (userData.user.email || '').toLowerCase();
      }
    } catch (authErr) {
      console.warn('[AUTH ERROR] Supabase token verification exception:', authErr);
    }
  }

  // Prevent customer endpoint from targeting admin account
  const db = loadLocalDb();
  const isAdmin =
    FIRST_APP_ADMIN_EMAILS.includes(verifiedEmail) ||
    SHOP_OWNER_EMAILS.includes(verifiedEmail) ||
    (db.adminTeam || []).some((a: any) => String(a.email).toLowerCase() === verifiedEmail);

  if (isAdmin) {
    return res.status(403).json({
      success: false,
      error: 'सुरक्षा त्रुटि: व्यवस्थापक (Admin / Shop Owner) खाता ग्राहक पोर्टल से नहीं हटाया जा सकता।',
    });
  }

  if (supabase && verifiedUserId) {
    try {
      const { error: delErr } = await (supabase.auth as any).admin?.deleteUser(verifiedUserId);
      if (delErr) {
        console.warn('[SUPABASE ADMIN] deleteUser note:', delErr.message);
      }
    } catch {}
  }

  db.customers = (db.customers || []).map((c: any) => {
    const isTarget =
      (verifiedEmail && String(c.email || '').toLowerCase() === verifiedEmail) ||
      (cleanPhone && String(c.phone || '').replace(/[^0-9]/g, '').slice(-10) === cleanPhone) ||
      (verifiedUserId && c.supabaseUserId === verifiedUserId);

    if (isTarget) {
      return {
        ...c,
        name: 'Anonymized Customer',
        phone: 'REDACTED',
        email: 'redacted@deleted.local',
        fullAddress: 'REDACTED ON ACCOUNT DELETION',
        landmark: '',
        isDeleted: true,
        deletedAt: new Date().toISOString(),
      };
    }
    return c;
  });

  db.inquiries = (db.inquiries || []).map((inq: any) => {
    const isTarget =
      (cleanPhone && String(inq.phone || '').replace(/[^0-9]/g, '').slice(-10) === cleanPhone) ||
      (verifiedEmail && String(inq.customerName || '').toLowerCase().includes(verifiedEmail));

    if (isTarget) {
      return {
        ...inq,
        customerName: 'Anonymized Customer (खाता हटाया गया)',
        phone: 'REDACTED',
        address: 'REDACTED',
        customDesignNote:
          '[Customer personal contact information erased upon account deletion - Transaction preserved]',
      };
    }
    return inq;
  });

  saveLocalDb(db);

  return res.json({
    success: true,
    message:
      'आपका ग्राहक खाता सफलतापूर्वक हटा दिया गया है एवं व्यक्तिगत डेटा सुरक्षित रूप से मिटा दिया गया है।',
  });
});

// ============================================================================
// CATALOG, SHOWROOM CONFIG & INQUIRY ENDPOINTS (Protected by Admin Auth)
// ============================================================================

app.put('/api/config', requireAdmin(), (req, res) => {
  const db = loadLocalDb();
  db.config = { ...db.config, ...sanitizeInput(req.body) };
  saveLocalDb(db);
  res.json(db.config);
});

app.post('/api/config/location', requireAdmin(), (req, res) => {
  const { latitude, longitude, addressLine, cityState, mapUrl } = sanitizeInput(req.body || {});
  const db = loadLocalDb();
  const latNum = Number(latitude) || 26.7606;
  const lngNum = Number(longitude) || 83.3732;
  db.config = {
    ...db.config,
    latitude: latNum,
    longitude: lngNum,
    addressLine: addressLine || db.config.addressLine,
    cityState: cityState || db.config.cityState,
    mapUrl: mapUrl || `https://www.google.com/maps?q=${latNum},${lngNum}`,
  };
  saveLocalDb(db);
  res.json({ updated: true, config: db.config });
});

app.post('/api/products', requireAdmin(), (req, res) => {
  const db = loadLocalDb();
  const prod = sanitizeInput(req.body);
  db.products = [prod, ...db.products.filter((p: any) => p.id !== prod.id)];
  saveLocalDb(db);
  res.status(201).json(prod);
});

app.put('/api/products/:id', requireAdmin(), (req, res) => {
  const db = loadLocalDb();
  const cleanBody = sanitizeInput(req.body);
  db.products = db.products.map((p: any) =>
    p.id === req.params.id ? { ...p, ...cleanBody } : p
  );
  saveLocalDb(db);
  res.json(cleanBody);
});

app.delete('/api/products/:id', requireAdmin(), (req, res) => {
  const db = loadLocalDb();
  db.products = db.products.filter((p: any) => p.id !== req.params.id);
  saveLocalDb(db);
  res.json({ deleted: true });
});

// Public quote submission
app.post('/api/inquiries', (req, res) => {
  const db = loadLocalDb();
  const cleanBody = sanitizeInput(req.body);
  const created = {
    ...cleanBody,
    id: cleanBody.id || `INQ-${Math.floor(1000 + Math.random() * 9000)}`,
    status: 'new',
    timestamp: Date.now(),
    formattedDate: new Date().toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }),
  };
  db.inquiries = [created, ...db.inquiries];
  saveLocalDb(db);
  res.status(201).json(created);
});

app.patch('/api/inquiries/:id/status', requireAdmin(), (req, res) => {
  const db = loadLocalDb();
  let updated: any = null;
  db.inquiries = db.inquiries.map((inq: any) => {
    if (inq.id === req.params.id) {
      updated = { ...inq, status: req.body.status };
      return updated;
    }
    return inq;
  });
  saveLocalDb(db);
  res.json(updated || { id: req.params.id, status: req.body.status });
});

app.delete('/api/inquiries/:id', requireAdmin(), (req, res) => {
  const db = loadLocalDb();
  db.inquiries = db.inquiries.filter((inq: any) => inq.id !== req.params.id);
  saveLocalDb(db);
  res.json({ deleted: true });
});

app.post('/api/reset', requireAdmin(), (_req, res) => {
  const freshDb = {
    config: INITIAL_SHOWROOM_CONFIG,
    products: INITIAL_PRODUCTS,
    inquiries: INITIAL_INQUIRIES,
    chatSessions: [],
    adminProfile: {
      ...DEFAULT_OWNER_ADMIN_PROFILE,
      role: 'app_admin',
      mfaEnabled: false,
    },
    customers: [],
    adminTeam: getDefaultAdminTeam(),
    invitations: [],
    authMethodsConfig: {
      emailPasswordEnabled: true,
      emailOtpEnabled: true,
      googleAuthEnabled: true,
      phoneOtpEnabled: false,
      whatsappOtpEnabled: false,
      updatedAt: new Date().toISOString(),
    },
  };
  saveLocalDb(freshDb);
  res.json({
    config: freshDb.config,
    products: freshDb.products,
    inquiries: freshDb.inquiries,
    updatedAt: new Date().toISOString(),
  });
});

// Serve static production frontend if dist exists
const distDir = path.join(__dirname, 'dist');
if (fs.existsSync(distDir)) {
  app.use(express.static(distDir));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(distDir, 'index.html'));
  });
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ Baba Furniture Udyog Server running at http://localhost:${PORT}`);
});
