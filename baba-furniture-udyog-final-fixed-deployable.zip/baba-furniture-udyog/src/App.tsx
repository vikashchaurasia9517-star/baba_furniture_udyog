/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  CustomerInquiry,
  CustomerUser,
  FurnitureCategory,
  Product,
  ShowroomConfig,
} from './types/furniture';
import {
  INITIAL_PRODUCTS,
  INITIAL_SHOWROOM_CONFIG,
  INITIAL_INQUIRIES,
} from './data/initialFurniture';
import { filterProducts } from './utils/furnitureLogic';
import {
  fetchBootstrapData,
  updateConfigApi,
  createProductApi,
  updateProductApi,
  deleteProductApi,
  createInquiryApi,
  updateInquiryStatusApi,
  deleteInquiryApi,
  resetDemoDataApi,
  getSavedCustomerUser,
  getSupabaseAuthSessionUser,
  getFrontendSupabaseClient,
  fetchAuthMethodsConfigApi,
  SupabaseStatusInfo,
} from './services/api';
import { CustomerAuthModal } from './components/CustomerAuthModal';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { CategoryNav } from './components/CategoryNav';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { QuoteRequestModal } from './components/QuoteRequestModal';
import { CustomDesignBuilder } from './components/CustomDesignBuilder';
import { WoodQualityShowcase } from './components/WoodQualityShowcase';
import { RoomFitEstimator } from './components/RoomFitEstimator';
import { DigitalCatalogModal } from './components/DigitalCatalogModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { ShowroomFooter } from './components/ShowroomFooter';
import { FloatingActionBar } from './components/FloatingActionBar';
import { LiveChatWidget } from './components/LiveChatWidget';
import { LiveSpecChartModal } from './components/LiveSpecChartModal';
import {
  Sparkles,
  MessageCircle,
  Phone,
  Camera,
  Share2,
  ShoppingCart,
  ShieldCheck,
  UserCheck,
  X,
  Copy,
  Check,
  MapPin,
} from 'lucide-react';

const STORAGE_KEYS = {
  PRODUCTS: 'baba_furniture_products_v2',
  CONFIG: 'baba_furniture_config_v2',
  INQUIRIES: 'baba_furniture_inquiries_v2',
  LANG: 'baba_furniture_lang_v2',
  CART: 'baba_furniture_cart_v2',
  GUEST_SESSION: 'baba_furniture_guest_session_v2',
};

function normalizeProductImages(items: Product[]): Product[] {
  return items.map((item) => ({
    ...item,
    imageUrl: item.imageUrl.replace('/src/assets/images/', '/images/'),
  }));
}

export default function App() {
  const [config, setConfig] = useState<ShowroomConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CONFIG);
      return saved ? { ...INITIAL_SHOWROOM_CONFIG, ...JSON.parse(saved) } : INITIAL_SHOWROOM_CONFIG;
    } catch {
      return INITIAL_SHOWROOM_CONFIG;
    }
  });

  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      return saved ? normalizeProductImages(JSON.parse(saved)) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [inquiries, setInquiries] = useState<CustomerInquiry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.INQUIRIES);
      return saved ? JSON.parse(saved) : INITIAL_INQUIRIES;
    } catch {
      return INITIAL_INQUIRIES;
    }
  });

  const [lang, setLang] = useState<'hi' | 'en'>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.LANG);
      return saved === 'en' || saved === 'hi' ? saved : 'hi';
    } catch {
      return 'hi';
    }
  });

  const [supabaseStatus, setSupabaseStatus] = useState<SupabaseStatusInfo | undefined>(
    undefined
  );

  // Filtering states
  const [activeCategory, setActiveCategory] = useState<FurnitureCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedWood, setSelectedWood] = useState('all');

  // Modal states
  const [activeProductDetail, setActiveProductDetail] = useState<Product | null>(null);
  const [activeQuoteProduct, setActiveQuoteProduct] = useState<Product | null>(null);
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false);
  const [isCustomOrderOpen, setIsCustomOrderOpen] = useState(false);
  const [isCatalogOpen, setIsCatalogOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isCustomerAuthOpen, setIsCustomerAuthOpen] = useState(false);
  const [customerUser, setCustomerUser] = useState<CustomerUser | null>(() =>
    getSavedCustomerUser()
  );
  const [authMethodsConfig, setAuthMethodsConfig] = useState<AuthMethodsConfig>({
    emailPasswordEnabled: true,
    emailOtpEnabled: true,
    googleAuthEnabled: true,
    phoneOtpEnabled: false,
    whatsappOtpEnabled: false,
  });
  const [customerAuthInitialMode, setCustomerAuthInitialMode] = useState<
    'password' | 'register' | 'otp' | 'forgot' | 'reset-password' | 'account-settings'
  >('password');
  const [isLiveChartOpen, setIsLiveChartOpen] = useState(false);
  const [isLiveChatOpen, setIsLiveChatOpen] = useState(false);
  const [chatPrefillText, setChatPrefillText] = useState('');

  // First-visit Auth Gate (Login / Sign Up / Guest Explore) & Cart Auth Gate
  const [showWelcomeAuthGate, setShowWelcomeAuthGate] = useState<boolean>(() => {
    try {
      if (getSavedCustomerUser()) return false;
      return sessionStorage.getItem(STORAGE_KEYS.GUEST_SESSION) !== '1';
    } catch {
      return false;
    }
  });
  const [cartItems, setCartItems] = useState<Product[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.CART);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  const [pendingCartProduct, setPendingCartProduct] = useState<Product | null>(null);
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState(false);

  // Rich Product + Website Share Modal state
  const [shareModalProduct, setShareModalProduct] = useState<Product | null>(null);
  const [shareCopied, setShareCopied] = useState(false);


  // Secret Admin Portal Trigger (?portal=admin, #admin, or Ctrl + Shift + A)
  useEffect(() => {
    const checkSecretPortal = () => {
      const params = new URLSearchParams(window.location.search);
      if (
        params.get('portal') === 'admin' ||
        window.location.hash === '#admin' ||
        window.location.hash === '#admin-portal'
      ) {
        setIsAdminOpen(true);
      }
    };
    checkSecretPortal();
    window.addEventListener('hashchange', checkSecretPortal);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        setIsAdminOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('hashchange', checkSecretPortal);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  // Restore Supabase Auth session & handle recovery links
  useEffect(() => {
    getSupabaseAuthSessionUser().then((user) => {
      if (user) setCustomerUser(user);
    });

    const sb = getFrontendSupabaseClient();
    if (sb) {
      const { data: authListener } = sb.auth.onAuthStateChange(
        async (event, session) => {
          if (event === 'PASSWORD_RECOVERY') {
            setCustomerAuthInitialMode('reset-password');
            setIsCustomerAuthOpen(true);
          } else if (
            event === 'SIGNED_IN' ||
            event === 'TOKEN_REFRESHED' ||
            event === 'USER_UPDATED'
          ) {
            if (session?.user) {
              const u = await getSupabaseAuthSessionUser();
              if (u) setCustomerUser(u);
            }
          } else if (event === 'SIGNED_OUT') {
            setCustomerUser(null);
          }
        }
      );

      return () => {
        authListener?.subscription?.unsubscribe();
      };
    }
  }, []);

  // Hydrate from Express + Supabase Backend API on mount
  useEffect(() => {
    let mounted = true;
    fetchAuthMethodsConfigApi().then((cfg) => {
      if (mounted && cfg) setAuthMethodsConfig(cfg);
    });
    fetchBootstrapData().then((data) => {
      if (!mounted || !data) return;
      if (data.config) setConfig(data.config);
      if (Array.isArray(data.products)) setProducts(normalizeProductImages(data.products));
      if (Array.isArray(data.inquiries)) setInquiries(data.inquiries);
      if (data.supabase) setSupabaseStatus(data.supabase);
    });
    return () => {
      mounted = false;
    };
  }, []);

  // Automatically add pending cart product once customer logs in
  useEffect(() => {
    if (customerUser && pendingCartProduct) {
      setCartItems((prev) =>
        prev.some((p) => p.id === pendingCartProduct.id)
          ? prev
          : [...prev, pendingCartProduct]
      );
      setPendingCartProduct(null);
      setIsCartDrawerOpen(true);
    }
  }, [customerUser, pendingCartProduct]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cartItems));
    } catch {}
  }, [cartItems]);

  const handleAddToCartWithAuthGate = (product: Product) => {
    if (!customerUser) {
      setPendingCartProduct(product);
      setIsCustomerAuthOpen(true);
      return;
    }
    setCartItems((prev) =>
      prev.some((p) => p.id === product.id) ? prev : [...prev, product]
    );
    setIsCartDrawerOpen(true);
  };

  const buildRichShareText = (product: Product): string => {
    const title = lang === 'hi' ? product.titleHi : product.title;
    const showPrice =
      config.showPricesOnWebsite !== false &&
      !product.hidePrice &&
      typeof product.price === 'number' &&
      product.price > 0;
    const priceText = showPrice
      ? `₹${Number(product.price).toLocaleString('en-IN')}${
          product.mrp ? ` (MRP ₹${Number(product.mrp).toLocaleString('en-IN')})` : ''
        }`
      : lang === 'hi'
      ? 'शोरूम रेट के लिए संपर्क करें'
      : 'Contact Showroom for Direct Price';
    const siteUrl =
      typeof window !== 'undefined' ? window.location.origin : 'https://babafurnitureudyog.com';
    return [
      `🪑 *${config.businessName} (${config.hindiName})*`,
      `✨ *${title}* (SKU: ${product.sku})`,
      `🪵 Wood: ${product.woodType} | Size: ${product.dimensions}`,
      `💰 Price: ${priceText}`,
      `🛡️ Warranty: ${product.warrantyYears} Years Written Termite Warranty`,
      `📍 Showroom: ${config.addressLine}, ${config.cityState}`,
      `📞 Call / WhatsApp: ${config.phone}`,
      `🗺️ Live Map: ${config.mapUrl || 'https://maps.google.com/?q=Gorakhpur,Uttar+Pradesh'}`,
      `🌐 Website: ${siteUrl}/?product=${encodeURIComponent(product.sku)}`,
    ].join('\n');
  };

  const handleOpenLiveChat = (product?: Product) => {
    if (product) {
      const prodName = lang === 'hi' ? product.titleHi : product.title;
      setChatPrefillText(
        lang === 'hi'
          ? `नमस्ते! मुझे ${prodName} (कोड: ${product.sku}, लकड़ी: ${product.woodType}) का दुकान रेट जानना है।`
          : `Hello! I would like to know the shop direct price for ${prodName} (${product.sku}, ${product.woodType}).`
      );
    } else {
      setChatPrefillText('');
    }
    setIsLiveChatOpen(true);
  };

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    } catch {}
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(config));
    } catch {}
  }, [config]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.INQUIRIES, JSON.stringify(inquiries));
    } catch {}
  }, [inquiries]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.LANG, lang);
    } catch {}
  }, [lang]);

  const handleUpdateConfig = async (newConfig: ShowroomConfig) => {
    setConfig(newConfig);
    const saved = await updateConfigApi(newConfig);
    if (saved) setConfig(saved);
  };

  const handleAddInquiry = async (
    newInq: Omit<CustomerInquiry, 'id' | 'timestamp' | 'formattedDate' | 'status'>
  ) => {
    const now = new Date();
    const formatted = now.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    const localCreated: CustomerInquiry = {
      ...newInq,
      id: `INQ-${Math.floor(1000 + Math.random() * 9000)}`,
      status: 'new',
      timestamp: Date.now(),
      formattedDate: formatted,
    };

    setInquiries((prev) => [localCreated, ...prev]);

    const serverCreated = await createInquiryApi(newInq);
    if (serverCreated) {
      setInquiries((prev) =>
        prev.map((item) => (item.id === localCreated.id ? serverCreated : item))
      );
    }
  };

  const handleUpdateInquiryStatus = async (
    id: string,
    status: CustomerInquiry['status']
  ) => {
    setInquiries((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status } : item))
    );
    await updateInquiryStatusApi(id, status);
  };

  const handleDeleteInquiry = async (id: string) => {
    setInquiries((prev) => prev.filter((item) => item.id !== id));
    await deleteInquiryApi(id);
  };

  const handleAddProduct = async (prod: Product) => {
    setProducts((prev) => [prod, ...prev]);
    const saved = await createProductApi(prod);
    if (saved) {
      setProducts((prev) => prev.map((p) => (p.id === prod.id ? saved : p)));
    }
  };

  const handleUpdateProduct = async (prod: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === prod.id ? prod : p)));
    await updateProductApi(prod);
  };

  const handleDeleteProduct = async (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    await deleteProductApi(id);
  };

  const handleResetDemoData = async () => {
    setProducts(INITIAL_PRODUCTS);
    setConfig(INITIAL_SHOWROOM_CONFIG);
    setInquiries(INITIAL_INQUIRIES);
    try {
      localStorage.removeItem(STORAGE_KEYS.PRODUCTS);
      localStorage.removeItem(STORAGE_KEYS.CONFIG);
      localStorage.removeItem(STORAGE_KEYS.INQUIRIES);
    } catch {}
    const resetRes = await resetDemoDataApi();
    if (resetRes) {
      setConfig(resetRes.config);
      setProducts(normalizeProductImages(resetRes.products));
      setInquiries(resetRes.inquiries);
    }
  };

  const filteredProducts = filterProducts(products, {
    category: activeCategory,
    searchQuery,
    woodType: selectedWood,
  });

  return (
    <div className="min-h-screen bg-[#FBF9F5] text-[#241E19] flex flex-col">
      {/* 1. Header */}
      <Header
        config={config}
        lang={lang}
        onToggleLang={() => setLang((prev) => (prev === 'hi' ? 'en' : 'hi'))}
        customerUser={customerUser}
        onOpenCustomerAuth={() => setIsCustomerAuthOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenCustomOrder={() => setIsCustomOrderOpen(true)}
        onOpenCatalog={() => setIsCatalogOpen(true)}
        onOpenLiveChart={() => setIsLiveChartOpen(true)}
        onOpenLiveChat={() => handleOpenLiveChat()}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* 2. Clean Full-Width Slide Images + Slide Text Overlay */}
        <Hero
          config={config}
          lang={lang}
          onExploreClick={() => {
            const el = document.getElementById('collections');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          onCustomOrderClick={() => setIsCustomOrderOpen(true)}
          onOpenCatalog={() => setIsCatalogOpen(true)}
        />

        {/* 3. Category Bar with Search and Wood selector */}
        <CategoryNav
          activeCategory={activeCategory}
          onSelectCategory={(cat) => setActiveCategory(cat)}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          selectedWood={selectedWood}
          onSelectWood={setSelectedWood}
          totalProductsCount={filteredProducts.length}
          lang={lang}
        />

        {/* 4. All Products Immediately Below Slide + Category Bar */}
        <section id="collections" className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 no-print">
          {filteredProducts.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-2xl border border-[#E0D5C3] p-8 space-y-4">
              <p className="text-[#6A5A4A] text-base">
                {lang === 'hi'
                  ? 'इस श्रेणी में अभी कोई फर्नीचर नहीं मिला। आप कस्टम ऑर्डर के लिए अपना डिज़ाइन भेज सकते हैं।'
                  : 'No furniture found matching your filter criteria. You can request a custom design.'}
              </p>
              <button
                onClick={() => {
                  setActiveCategory('all');
                  setSearchQuery('');
                  setSelectedWood('all');
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-[#8E5327] rounded-md cursor-pointer"
              >
                {lang === 'hi' ? 'सभी फिल्टर हटाएं' : 'Reset Filters'}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  config={config}
                  lang={lang}
                  onViewDetails={(prod) => setActiveProductDetail(prod)}
                  onRequestQuote={(prod) => {
                    setActiveQuoteProduct(prod);
                    setIsQuoteModalOpen(true);
                  }}
                  onOpenLiveChat={handleOpenLiveChat}
                  onAddToCart={handleAddToCartWithAuthGate}
                  onShareProduct={(prod) => setShareModalProduct(prod)}
                />
              ))}
            </div>
          )}

          {/* Compact Custom Design Icon Card (Opens Modal instead of sprawling inline form) */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-[#2D2319] via-[#3E2E1E] to-[#2D2319] text-white border border-[#C89D66]/40 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setIsCustomOrderOpen(true)}
                className="w-14 h-14 rounded-2xl bg-[#C89D66] text-[#241E19] flex items-center justify-center shrink-0 shadow-md cursor-pointer"
                title={lang === 'hi' ? 'अपना डिज़ाइन भेजें' : 'Send Your Custom Design'}
              >
                <Camera className="w-7 h-7" />
              </button>
              <div>
                <h3 className="font-display text-lg sm:text-xl font-bold text-[#FDE68A]">
                  {lang === 'hi'
                    ? '🎨 अपना कस्टम फर्नीचर डिज़ाइन आइकॉन (Photo / Size भेजें)'
                    : '🎨 Custom Furniture Design Icon (Send Photo & Dimensions)'}
                </h3>
                <p className="text-xs sm:text-sm text-[#E7D6C4]">
                  {lang === 'hi'
                    ? 'किसी भी फोटो या नाप के अनुसार 100% सागवान/शीशम फर्नीचर बनवाने के लिए इस आइकॉन पर क्लिक करें।'
                    : 'Click this icon card to upload your reference photo or custom room dimensions.'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsCustomOrderOpen(true)}
              className="px-5 py-2.5 text-xs sm:text-sm font-bold bg-[#C89D66] hover:bg-[#B38750] text-[#241E19] rounded-xl shrink-0 inline-flex items-center gap-2 cursor-pointer"
            >
              <Camera className="w-4 h-4" />
              <span>{lang === 'hi' ? 'अपना डिज़ाइन खोलें' : 'Open Custom Design'}</span>
            </button>
          </div>
        </section>

        {/* 5. Wood Quality & Timber Guarantee */}
        <div className="no-print">
          <WoodQualityShowcase lang={lang} config={config} />
        </div>

        {/* 6. Room Fit & Clearance Estimator */}
        <RoomFitEstimator lang={lang} config={config} />

        {/* 7. Showroom Direct Factory Workshop Banner */}
        <section className="bg-[#2D2319] text-white py-12 border-t border-[#4A3B2B] no-print">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
              <div className="space-y-2 text-center lg:text-left">
                <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#C89D66] uppercase tracking-wider">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{lang === 'hi' ? 'सीधे कारखाने से थोक व खुदरा' : 'Direct Factory Workshop'}</span>
                </div>
                <h3 className="font-display text-2xl sm:text-3xl font-bold">
                  {lang === 'hi'
                    ? 'पूरे घर का फर्नीचर (होल-हाउस पैकेज) बनवाना चाहते हैं?'
                    : 'Furnishing an Entire New Home or Villa?'}
                </h3>
                <p className="text-xs sm:text-sm text-[#D5C2A5] max-w-2xl leading-relaxed">
                  {lang === 'hi'
                    ? 'बेड, सोफा, डाइनिंग, अलमारी और मंदिर का पूरा कॉम्बो पैकेज सीधे कारखाने से ऑर्डर करें।'
                    : 'Order complete whole-home suites directly from our workshop with free site measurement.'}
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3 shrink-0">
                <button
                  onClick={() => handleOpenLiveChat()}
                  className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-lg shadow-sm transition-colors cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 fill-white" />
                  <span>{lang === 'hi' ? 'लाइव चैट पर पैकेज पूछें' : 'Consult via Live Chat'}</span>
                </button>
                <a
                  href={`tel:${config.phone.replace(/[^0-9+]/g, '')}`}
                  className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-[#2D2319] bg-[#EFE6D8] hover:bg-[#E3D6C1] rounded-lg transition-colors"
                >
                  <Phone className="w-4 h-4 text-[#8E5327]" />
                  <span>{lang === 'hi' ? 'फोन पर बात करें' : 'Call Workshop'}</span>
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Showroom Footer */}
      <div className="no-print">
        <ShowroomFooter
          config={config}
          lang={lang}
          customerUser={customerUser}
          onOpenCustomerAuth={() => setIsCustomerAuthOpen(true)}
          onOpenAdmin={() => setIsAdminOpen(true)}
          onOpenCustomOrder={() => setIsCustomOrderOpen(true)}
          onOpenCatalog={() => setIsCatalogOpen(true)}
          onOpenLiveChat={() => handleOpenLiveChat()}
        />
      </div>

      {/* Floating Bottom-Left Custom Design + Cart Quick Icons */}
      <div className="fixed bottom-5 left-4 z-40 flex items-center gap-2 no-print">
        <button
          onClick={() => setIsCustomOrderOpen(true)}
          className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-[#2D2319] hover:bg-[#8E5327] text-white text-xs font-bold shadow-xl border border-[#C89D66] transition-all cursor-pointer"
          title={lang === 'hi' ? 'अपना डिज़ाइन भेजें' : 'Custom Furniture Design'}
        >
          <Camera className="w-4 h-4 text-[#FBBF24]" />
          <span>{lang === 'hi' ? 'अपना डिज़ाइन' : 'Custom Design'}</span>
        </button>

        <button
          onClick={() => {
            if (!customerUser) {
              setIsCustomerAuthOpen(true);
            } else {
              setIsCartDrawerOpen(true);
            }
          }}
          className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-full bg-[#8E5327] hover:bg-[#73411C] text-white text-xs font-bold shadow-xl border border-white/20 transition-all cursor-pointer"
        >
          <ShoppingCart className="w-4 h-4" />
          <span>{cartItems.length}</span>
        </button>
      </div>

      {/* Floating Mobile Action Bar */}
      <div className="no-print">
        <FloatingActionBar
          config={config}
          lang={lang}
          onOpenCustomOrder={() => setIsCustomOrderOpen(true)}
          onOpenLiveChat={() => handleOpenLiveChat()}
        />
      </div>

      {/* First-Visit Welcome Auth Gate Modal (Login / Sign Up / Guest Explore Only) */}
      {showWelcomeAuthGate && !customerUser && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#FAF7F2] border-2 border-[#C89D66] rounded-2xl max-w-md w-full overflow-hidden shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#2D2319] text-[#FDE68A] inline-flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{config.businessName}</span>
              </span>
              <button
                onClick={() => {
                  try {
                    sessionStorage.setItem(STORAGE_KEYS.GUEST_SESSION, '1');
                  } catch {}
                  setShowWelcomeAuthGate(false);
                }}
                className="text-xs text-[#6A5A4A] hover:text-[#2D2319] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1.5">
              <h3 className="font-display text-xl font-bold text-[#2D2319]">
                {lang === 'hi'
                  ? 'बाबा फर्नीचर उद्योग शोरूम में आपका स्वागत है!'
                  : 'Welcome to Baba Furniture Udyog Showroom!'}
              </h3>
              <p className="text-xs text-[#6A5A4A] leading-relaxed">
                {lang === 'hi'
                  ? 'कार्ट में फर्नीचर जोड़ने, ऑर्डर ट्रैक करने और एक्सक्लूसिव शोरूम रेट पाने के लिए लॉगिन या साइन-अप करें — या केवल कैटलॉग देखने के लिए Guest (अतिथि) चुनें।'
                  : 'Login or Sign Up to add furniture to your cart, save delivery address, and unlock showroom quotes — or continue as Guest to explore.'}
              </p>
            </div>

            <div className="space-y-2.5 pt-1">
              <button
                onClick={() => {
                  setShowWelcomeAuthGate(false);
                  setIsCustomerAuthOpen(true);
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-[#8E5327] hover:bg-[#73411C] text-white text-xs sm:text-sm font-bold inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <UserCheck className="w-4 h-4" />
                <span>
                  {lang === 'hi'
                    ? 'लॉगिन / नया खाता बनाएं (Email / Password / Google)'
                    : 'Login / Sign Up (Email / Password / Google)'}
                </span>
              </button>

              <button
                onClick={() => {
                  try {
                    sessionStorage.setItem(STORAGE_KEYS.GUEST_SESSION, '1');
                  } catch {}
                  setShowWelcomeAuthGate(false);
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-[#EFE6D8] hover:bg-[#E3D6C1] text-[#2D2319] border border-[#C5B396] text-xs font-bold cursor-pointer"
              >
                {lang === 'hi'
                  ? 'अतिथि के रूप में केवल एक्सप्लोर करें (Continue as Guest - Explore Only)'
                  : 'Continue as Guest (Explore Only)'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Customer Cart Drawer Modal */}
      {isCartDrawerOpen && (
        <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#FAF7F2] border border-[#D8C7AE] rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#E5D7C3] pb-3">
              <h3 className="font-display text-lg font-bold text-[#2D2319] flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-[#8E5327]" />
                <span>
                  {lang === 'hi'
                    ? `मेरा शोरूम कार्ट (${cartItems.length})`
                    : `My Showroom Cart (${cartItems.length})`}
                </span>
              </h3>
              <button
                onClick={() => setIsCartDrawerOpen(false)}
                className="p-1 rounded-lg hover:bg-black/5 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {cartItems.length === 0 ? (
              <p className="text-xs text-[#6A5A4A] py-6 text-center">
                {lang === 'hi' ? 'आपका कार्ट खाली है।' : 'Your cart is currently empty.'}
              </p>
            ) : (
              <div className="space-y-3 max-h-72 overflow-y-auto">
                {cartItems.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 rounded-xl bg-white border border-[#E5D7C3] flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={item.imageUrl}
                        alt={item.title}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                      <div>
                        <div className="text-xs font-bold text-[#2D2319]">
                          {lang === 'hi' ? item.titleHi : item.title}
                        </div>
                        <div className="text-[11px] text-[#6A5A4A]">
                          {item.sku} · {item.woodType}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setIsCartDrawerOpen(false);
                          setActiveQuoteProduct(item);
                          setIsQuoteModalOpen(true);
                        }}
                        className="px-2.5 py-1 text-[11px] font-bold bg-[#8E5327] text-white rounded cursor-pointer"
                      >
                        {lang === 'hi' ? 'ऑर्डर/कोटेशन' : 'Book Quote'}
                      </button>
                      <button
                        onClick={() =>
                          setCartItems((prev) => prev.filter((p) => p.id !== item.id))
                        }
                        className="text-xs text-red-600 px-2 py-1 cursor-pointer"
                      >
                        ✕
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Rich Product + Website Share Modal */}
      {shareModalProduct && (
        <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#FAF7F2] border border-[#D8C7AE] rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#E5D7C3] pb-3">
              <div className="flex items-center gap-2">
                <Share2 className="w-5 h-5 text-[#8E5327]" />
                <h3 className="font-display text-lg font-bold text-[#2D2319]">
                  {lang === 'hi'
                    ? 'प्रोडक्ट और शोरूम वेबसाइट शेयर करें'
                    : 'Share Product & Showroom Website'}
                </h3>
              </div>
              <button
                onClick={() => setShareModalProduct(null)}
                className="p-1 rounded-lg hover:bg-black/5 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <pre className="p-3.5 rounded-xl bg-white border border-[#E5D7C3] text-xs text-[#2D2319] whitespace-pre-wrap font-sans leading-relaxed">
              {buildRichShareText(shareModalProduct)}
            </pre>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <a
                href={`https://wa.me/?text=${encodeURIComponent(
                  buildRichShareText(shareModalProduct)
                )}`}
                target="_blank"
                rel="noreferrer"
                className="py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold text-center"
              >
                💬 WhatsApp पर शेयर करें
              </a>
              <button
                onClick={async () => {
                  try {
                    await navigator.clipboard.writeText(
                      buildRichShareText(shareModalProduct)
                    );
                    setShareCopied(true);
                    setTimeout(() => setShareCopied(false), 2500);
                  } catch {}
                }}
                className="py-2.5 px-4 rounded-xl bg-[#2D2319] hover:bg-black text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {shareCopied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copy Full Details</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Product Detail Modal */}
      {activeProductDetail && (
        <ProductDetailModal
          product={activeProductDetail}
          config={config}
          lang={lang}
          onClose={() => setActiveProductDetail(null)}
          onRequestQuote={(prod) => {
            setActiveQuoteProduct(prod);
            setIsQuoteModalOpen(true);
          }}
          onOpenLiveChat={handleOpenLiveChat}
        />
      )}

      {/* Quote Request Modal */}
      {isQuoteModalOpen && (
        <QuoteRequestModal
          product={activeQuoteProduct}
          config={config}
          lang={lang}
          customerUser={customerUser}
          onClose={() => {
            setIsQuoteModalOpen(false);
            setActiveQuoteProduct(null);
          }}
          onSubmitInquiry={handleAddInquiry}
        />
      )}

      {/* Custom Order Modal */}
      {isCustomOrderOpen && (
        <div className="printable-modal-wrapper fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
          <div className="printable-modal-box relative w-full max-w-4xl my-8">
            <CustomDesignBuilder
              config={config}
              lang={lang}
              customerUser={customerUser}
              onClose={() => setIsCustomOrderOpen(false)}
              onSubmitInquiry={handleAddInquiry}
            />
          </div>
        </div>
      )}

      {/* Digital Catalog Download Modal */}
      {isCatalogOpen && (
        <DigitalCatalogModal
          products={products}
          config={config}
          lang={lang}
          onClose={() => setIsCatalogOpen(false)}
        />
      )}

      {/* Customer Auth & My Inquiries Modal */}
      {isCustomerAuthOpen && (
        <CustomerAuthModal
          isOpen={isCustomerAuthOpen}
          onClose={() => {
            setIsCustomerAuthOpen(false);
            setCustomerAuthInitialMode('password');
          }}
          customerUser={customerUser}
          onUpdateCustomerUser={setCustomerUser}
          onCustomerChange={setCustomerUser}
          inquiries={inquiries}
          config={config}
          lang={lang}
          onOpenCustomOrder={() => setIsCustomOrderOpen(true)}
          initialMode={customerAuthInitialMode}
        />
      )}

      {/* Admin Panel Modal */}
      {isAdminOpen && (
        <AdminPanelModal
          isOpen={isAdminOpen}
          onClose={() => setIsAdminOpen(false)}
          config={config}
          onUpdateConfig={handleUpdateConfig}
          products={products}
          onAddProduct={handleAddProduct}
          onUpdateProduct={handleUpdateProduct}
          onDeleteProduct={handleDeleteProduct}
          inquiries={inquiries}
          onUpdateInquiryStatus={handleUpdateInquiryStatus}
          onDeleteInquiry={handleDeleteInquiry}
          onResetDemoData={handleResetDemoData}
          supabaseStatus={supabaseStatus}
          lang={lang}
        />
      )}

      {/* Live Specs & Wood Comparison Chart Modal */}
      {isLiveChartOpen && (
        <LiveSpecChartModal
          isOpen={isLiveChartOpen}
          onClose={() => setIsLiveChartOpen(false)}
          config={config}
          lang={lang}
        />
      )}

      {/* Floating Live Chat Widget */}
      <LiveChatWidget
        config={config}
        lang={lang}
        customerUser={customerUser}
        onOpenCustomOrder={() => setIsCustomOrderOpen(true)}
        onOpenCatalog={() => setIsCatalogOpen(true)}
        onOpenLiveChart={() => setIsLiveChartOpen(true)}
        isOpenControlled={isLiveChatOpen}
        onOpenControlled={() => setIsLiveChatOpen(true)}
        onCloseControlled={() => setIsLiveChatOpen(false)}
        prefillMessage={chatPrefillText}
      />
    </div>
  );
}
