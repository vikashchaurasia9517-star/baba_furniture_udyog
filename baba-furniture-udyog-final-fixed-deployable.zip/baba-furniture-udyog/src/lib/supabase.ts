import { createClient, SupabaseClient } from '@supabase/supabase-js';

let cachedClient: SupabaseClient | null = null;
let cachedUrl = '';

/**
 * Retrieves the frontend Supabase configuration.
 * Exclusively reads the public project URL and Anon/Publishable Key from Vite environment variables.
 * Never handles or accepts service-role secret keys.
 */
export function getStoredSupabaseConfig(): { url: string; anonKey: string } {
  let url = '';
  let anonKey = '';

  try {
    url = (import.meta as any).env?.VITE_SUPABASE_URL || '';
    anonKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || '';
  } catch {
    // ignore env errors
  }

  if (typeof window !== 'undefined') {
    try {
      // Fallback for legacy development overrides if present
      url = url || localStorage.getItem('baba_supabase_url') || '';
      anonKey = anonKey || localStorage.getItem('baba_supabase_anon_key') || '';
    } catch {
      // ignore storage errors
    }
  }

  return { url: url.trim(), anonKey: anonKey.trim() };
}

/**
 * Returns a singleton instance of the frontend Supabase client.
 * Uses public Anon Key for client-side queries protected by Row Level Security (RLS).
 */
export function getFrontendSupabaseClient(): SupabaseClient | null {
  const { url, anonKey: key } = getStoredSupabaseConfig();

  if (!url || !key) return null;
  if (cachedClient && cachedUrl === url) return cachedClient;

  try {
    cachedClient = createClient(url, key, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: true,
      },
    });
    cachedUrl = url;
    return cachedClient;
  } catch (err) {
    console.warn('[SUPABASE CLIENT] Initialization error:', err);
    return null;
  }
}
