export type FurnitureCategory =
  | 'all'
  | 'beds'
  | 'dining'
  | 'sofas'
  | 'wardrobes'
  | 'temples'
  | 'living'
  | 'office';

export type WoodType =
  | 'Solid Teak (सागवान)'
  | 'Pure Sheesham (शीशम)'
  | 'Rosewood (शीशम रोसवुड)'
  | 'Engineered Hardwood'
  | 'Marine Grade Ply';

export interface Product {
  id: string;
  sku: string;
  title: string;
  titleHi: string;
  category: FurnitureCategory;
  categoryLabel: string;
  categoryLabelHi: string;
  woodType: WoodType;
  dimensions: string;
  price?: number;
  mrp?: number;
  hidePrice?: boolean;
  finishOptions: string[];
  features: string[];
  featuresHi: string[];
  imageUrl: string;
  description: string;
  descriptionHi: string;
  warrantyYears: number;
  isFeatured: boolean;
  inStock: boolean;
}

export type InquiryStatus = 'new' | 'contacted' | 'quoted' | 'closed';

export interface CustomerInquiry {
  id: string;
  customerName: string;
  phone: string;
  alternatePhone?: string;
  city?: string;
  fullAddress?: string;
  pincode?: string;
  landmark?: string;
  preferredContact: 'whatsapp' | 'call';
  productId?: string;
  productTitle?: string;
  productSku?: string;
  woodPreference?: string;
  customDesignNote?: string;
  customDesignImage?: string;
  status: InquiryStatus;
  timestamp: number;
  formattedDate: string;
}

export interface CustomerUser {
  id: string;
  name: string;
  phone: string;
  email?: string;
  city?: string;
  fullAddress?: string;
  pincode?: string;
  landmark?: string;
  alternatePhone?: string;
  gstNumber?: string;
  floorLiftInfo?: string;
  createdAt?: string;
  mobileVerified?: boolean;
  emailVerified?: boolean;
  whatsappVerified?: boolean;
  loginProvider?: 'google' | 'whatsapp' | 'truecaller' | 'otp' | 'password' | 'email-otp' | 'email-password';
  supabaseUserId?: string;
  emailConfirmedAt?: string | null;
  lastSignInAt?: string | null;
  hasPassword?: boolean;
  termsAccepted?: boolean;
}

export type AdminRole = 'shop_owner' | 'app_admin';

export interface AdminProfile {
  id?: string;
  email: string;
  phone?: string;
  username?: string;
  ownerName: string;
  role: AdminRole | string;
  roleTitle?: string;
  mfaEnabled?: boolean;
  invitedBy?: string;
  createdAt?: string;
}

export interface AdminInvitation {
  id: string;
  email: string;
  role: AdminRole;
  token?: string;
  invitedBy?: string;
  status: 'pending' | 'accepted' | 'revoked';
  expiresAt: string;
  createdAt: string;
}

export interface AuthMethodsConfig {
  emailPasswordEnabled: boolean;
  emailOtpEnabled: boolean;
  googleAuthEnabled: boolean;
  phoneOtpEnabled: boolean;
  whatsappOtpEnabled: boolean;
  updatedAt?: string;
  updatedBy?: string;
}

export interface HeroStatsConfig {
  stat1Value: string;
  stat1LabelHi: string;
  stat1LabelEn: string;
  stat2Value: string;
  stat2LabelHi: string;
  stat2LabelEn: string;
  stat3Value: string;
  stat3LabelHi: string;
  stat3LabelEn: string;
}

export interface WoodShowcaseItem {
  id: string;
  name: string;
  nameEn: string;
  durability: string;
  termiteRating: string;
  grainType: string;
  bestFor: string;
  descriptionHi: string;
  descriptionEn: string;
}

export interface RoomPresetItem {
  label: string;
  lengthFt: number;
  widthFt: number;
}

export interface ShowroomConfig {
  businessName: string;
  businessNameHi: string;
  tagline: string;
  taglineHi: string;
  ownerName: string;
  adminEmail: string;
  adminRole: string;
  phone: string;
  alternatePhone?: string;
  whatsappNumber: string;
  address: string;
  cityState: string;
  pincode?: string;
  landmark?: string;
  gstNumber?: string;
  googleMapsUrl?: string;
  latitude?: number;
  longitude?: number;
  showPricesOnWebsite?: boolean;
  welcomeOfferText?: string;
  timings: string;
  announcement: string;
  heroStats?: HeroStatsConfig;
  woodTypes?: WoodShowcaseItem[];
  roomPresets?: RoomPresetItem[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'shop';
  text: string;
  timestamp: number;
  formattedTime: string;
  suggestedAction?: {
    type: 'whatsapp' | 'call' | 'custom_order' | 'catalog' | 'chart';
    label: string;
  };
}


export interface LiveChatSession {
  id: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  unreadForAdmin: number;
  unreadForCustomer?: number;
  updatedAt: number;
  messages: {
    id: string;
    sender: 'user' | 'shop';
    senderName: string;
    text: string;
    timestamp: number;
    formattedTime: string;
    suggestedAction?: {
      type: 'whatsapp' | 'call' | 'custom_order' | 'catalog' | 'chart';
      label: string;
    };
  }[];
}
