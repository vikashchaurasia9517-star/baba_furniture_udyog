import { Product, ShowroomConfig } from '../types/furniture';

/**
 * Triggers a file download in the browser
 */
export async function downloadImageFile(imageUrl: string, suggestedFilename: string): Promise<boolean> {
  try {
    const response = await fetch(imageUrl);
    const blob = await response.blob();
    const blobUrl = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = suggestedFilename.replace(/[^a-zA-Z0-9_-]/g, '_') + '.jpg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(blobUrl);
    return true;
  } catch {
    // Fallback direct link
    const link = document.createElement('a');
    link.href = imageUrl;
    link.target = '_blank';
    link.download = suggestedFilename + '.jpg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    return true;
  }
}

/**
 * Share a product via Web Share API or WhatsApp fallback
 */
export async function shareProductDetails(
  product: Product,
  config: ShowroomConfig,
  lang: 'hi' | 'en'
): Promise<{ success: boolean; method: 'native' | 'whatsapp' | 'clipboard' }> {
  const title = lang === 'hi' ? product.titleHi : product.title;
  const shareText =
    lang === 'hi'
      ? `✨ *${config.businessNameHi}* पर यह खूबसूरत फर्नीचर देखें:\n\n*${title}* (SKU: ${product.sku})\n- लकड़ी: ${product.woodType}\n- माप: ${product.dimensions}\n- दीमक गारंटी: ${product.warrantyYears} वर्ष\n\nसीधे दुकान संपर्क: ${config.phone}\nपता: ${config.address}, ${config.cityState}`
      : `✨ Check out *${title}* (SKU: ${product.sku}) at *${config.businessName}*:\n- Wood: ${product.woodType}\n- Size: ${product.dimensions}\n- Termite Warranty: ${product.warrantyYears} Yrs\n\nContact: ${config.phone}\n${config.address}`;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://babafurnitureudyog.com';

  if (typeof navigator !== 'undefined' && navigator.share) {
    try {
      await navigator.share({
        title: `${title} | ${config.businessName}`,
        text: shareText,
        url: currentUrl,
      });
      return { success: true, method: 'native' };
    } catch {
      // User cancelled share dialog, fall through or return
      return { success: false, method: 'native' };
    }
  }

  // Fallback 1: WhatsApp share URL
  const whatsappShareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(
    `${shareText}\n\nवेबसाइट देखें: ${currentUrl}`
  )}`;

  if (typeof window !== 'undefined') {
    window.open(whatsappShareUrl, '_blank');
  }
  return { success: true, method: 'whatsapp' };
}

/**
 * Share the whole showroom catalog
 */
export async function shareCatalogLink(
  config: ShowroomConfig,
  lang: 'hi' | 'en'
): Promise<{ success: boolean; method: 'native' | 'whatsapp' | 'clipboard' }> {
  const shareText =
    lang === 'hi'
      ? `🛋️ *${config.businessNameHi}* (सॉलिड वुड फर्नीचर दुकान)\nसागवान व शीशम के बेड, सोफा, डाइनिंग टेबल, अलमारी और मंदिर की पूरी डिजिटल कैटलॉग देखें।\n\nसंपर्क: ${config.phone}\nपता: ${config.address}, ${config.cityState}`
      : `🛋️ *${config.businessName}* (Solid Wood Furniture Showcase)\nExplore our complete collection of Solid Teak & Sheesham beds, dining tables, sofas, and mandirs.\n\nCall: ${config.phone}\n${config.address}`;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://babafurnitureudyog.com';

  if (typeof navigator !== 'undefined' && navigator.share) {
    try {
      await navigator.share({
        title: `${config.businessName} - Digital Furniture Catalog`,
        text: shareText,
        url: currentUrl,
      });
      return { success: true, method: 'native' };
    } catch {
      return { success: false, method: 'native' };
    }
  }

  const whatsappShareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(
    `${shareText}\n\nकैटलॉग लिंक: ${currentUrl}`
  )}`;

  if (typeof window !== 'undefined') {
    window.open(whatsappShareUrl, '_blank');
  }
  return { success: true, method: 'whatsapp' };
}

/**
 * Copy text to clipboard
 */
export async function copyTextToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
    const input = document.createElement('textarea');
    input.value = text;
    document.body.appendChild(input);
    input.select();
    document.execCommand('copy');
    document.body.removeChild(input);
    return true;
  } catch {
    return false;
  }
}
