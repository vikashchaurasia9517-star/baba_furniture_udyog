import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildWhatsAppInquiryUrl,
  filterProducts,
  validateInquiryForm,
  calculateRoomFit,
  exportInquiriesToCsv,
} from './furnitureLogic';
import { CustomerInquiry, Product } from '../types/furniture';

const mockProducts: Product[] = [
  {
    id: 'prod-1',
    sku: 'BFU-BED-01',
    title: 'Royal Sagwan Carved King Bed',
    titleHi: 'शाही सागवान नक्काशीदार किंग बेड',
    category: 'beds',
    categoryLabel: 'Beds',
    categoryLabelHi: 'बेड्स',
    woodType: 'Solid Teak (सागवान)',
    dimensions: '78"L x 72"W x 48"H',
    finishOptions: ['Natural Teak', 'Dark Walnut'],
    features: ['Hydraulic Storage', 'Termite Proof'],
    featuresHi: ['हाइड्रोलिक स्टोरेज', 'दीमक प्रूफ'],
    imageUrl: '/test.jpg',
    description: 'Masterpiece solid teak bed.',
    descriptionHi: 'सॉलिड सागवान से निर्मित शाही बेड।',
    warrantyYears: 10,
    isFeatured: true,
    inStock: true,
  },
  {
    id: 'prod-2',
    sku: 'BFU-DIN-02',
    title: 'Heritage Sheesham 6-Seater Dining',
    titleHi: 'विरासत शीशम 6-सीटर डाइनिंग टेबल',
    category: 'dining',
    categoryLabel: 'Dining',
    categoryLabelHi: 'डाइनिंग',
    woodType: 'Pure Sheesham (शीशम)',
    dimensions: '60"L x 36"W x 30"H',
    finishOptions: ['Honey Oak'],
    features: ['Hand-carved Chairs'],
    featuresHi: ['हाथ से तराशी कुर्सियां'],
    imageUrl: '/dining.jpg',
    description: 'Spacious 6 seater family dining table.',
    descriptionHi: 'परिवार के लिए सुंदर 6-सीटर टेबल।',
    warrantyYears: 10,
    isFeatured: false,
    inStock: true,
  },
];

test('buildWhatsAppInquiryUrl formats URL with phone and encoded text', () => {
  const url = buildWhatsAppInquiryUrl({
    whatsappNumber: '+91 98765-43210',
    productTitle: 'Royal Sagwan Carved King Bed',
    sku: 'BFU-BED-01',
    woodType: 'Solid Teak (सागवान)',
    customerName: 'Vikash',
  });

  assert.ok(url.startsWith('https://wa.me/919876543210?text='));
  assert.ok(url.includes(encodeURIComponent('Royal Sagwan Carved King Bed')));
  assert.ok(url.includes(encodeURIComponent('BFU-BED-01')));
  assert.ok(url.includes(encodeURIComponent('Vikash')));
});

test('filterProducts filters by category correctly', () => {
  const beds = filterProducts(mockProducts, { category: 'beds' });
  assert.equal(beds.length, 1);
  assert.equal(beds[0].id, 'prod-1');

  const dining = filterProducts(mockProducts, { category: 'dining' });
  assert.equal(dining.length, 1);
  assert.equal(dining[0].id, 'prod-2');

  const all = filterProducts(mockProducts, { category: 'all' });
  assert.equal(all.length, 2);
});

test('filterProducts searches across title, sku and Hindi text', () => {
  const search1 = filterProducts(mockProducts, { searchQuery: 'Sheesham' });
  assert.equal(search1.length, 1);
  assert.equal(search1[0].sku, 'BFU-DIN-02');

  const search2 = filterProducts(mockProducts, { searchQuery: 'सागवान' });
  assert.equal(search2.length, 1);
  assert.equal(search2[0].id, 'prod-1');

  const searchSku = filterProducts(mockProducts, { searchQuery: 'BFU-BED-01' });
  assert.equal(searchSku.length, 1);
});

test('validateInquiryForm checks name and phone rules', () => {
  assert.equal(validateInquiryForm({ customerName: '', phone: '9876543210' }).isValid, false);
  assert.equal(validateInquiryForm({ customerName: 'A', phone: '9876543210' }).isValid, false);
  assert.equal(validateInquiryForm({ customerName: 'Rahul', phone: '123' }).isValid, false);
  assert.equal(validateInquiryForm({ customerName: 'Rahul Kumar', phone: '+91 98765 43210' }).isValid, true);
});

test('calculateRoomFit provides correct clearances and utilization', () => {
  // 14x12 ft bedroom with 6.5x6 ft bed
  const result = calculateRoomFit(14, 12, 6.5, 6);
  assert.equal(result.fits, true);
  assert.equal(result.clearanceLengthFt, 7.5);
  assert.equal(result.clearanceWidthFt, 6);
  assert.ok(result.areaUtilizationPct < 30);

  // Tiny room 7x7 with 6.5x6 bed
  const tightResult = calculateRoomFit(7, 7, 6.5, 6);
  assert.equal(tightResult.fits, false);
  assert.ok(tightResult.recommendation.includes('Too tight') || tightResult.recommendation.includes('Snug'));
});

test('exportInquiriesToCsv formats header and fields', () => {
  const inquiries: CustomerInquiry[] = [
    {
      id: 'INQ-1001',
      customerName: 'Amit Sharma',
      phone: '9876543210',
      city: 'Gorakhpur',
      preferredContact: 'whatsapp',
      productTitle: 'Royal Bed',
      productSku: 'BFU-BED-01',
      status: 'new',
      timestamp: 1742080000000,
      formattedDate: '25 Oct 2026',
    },
  ];
  const csv = exportInquiriesToCsv(inquiries);
  assert.ok(csv.includes('Inquiry ID,Date,Customer Name'));
  assert.ok(csv.includes('"INQ-1001"'));
  assert.ok(csv.includes('"Amit Sharma"'));
});
