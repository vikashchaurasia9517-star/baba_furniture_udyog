import test from 'node:test';
import assert from 'node:assert/strict';
import { Product, ShowroomConfig } from '../types/furniture';
import { shareProductDetails, shareCatalogLink } from './shareAndDownload';

const mockProduct: Product = {
  id: 'test-1',
  sku: 'BFU-BED-101',
  title: 'Royal King Bed',
  titleHi: 'शाही किंग बेड',
  category: 'beds',
  categoryLabel: 'Beds',
  categoryLabelHi: 'बेड्स',
  woodType: 'Solid Teak (सागवान)',
  dimensions: '78x72',
  finishOptions: ['Walnut'],
  features: ['Storage'],
  featuresHi: ['स्टोरेज'],
  imageUrl: '/test.jpg',
  description: 'Test desc',
  descriptionHi: 'टेस्ट विवरण',
  warrantyYears: 10,
  isFeatured: true,
  inStock: true,
};

const mockConfig: ShowroomConfig = {
  businessName: 'Baba Furniture Udyog',
  businessNameHi: 'बाबा फर्नीचर उद्योग',
  tagline: 'Craftsmanship',
  taglineHi: 'शिल्पकार',
  ownerName: 'प्रो. विकास चौरसिया (Vikash Chaurasia)',
  adminEmail: 'admin@babafurnitureudyog.com',
  adminRole: 'Founder & Managing Proprietor',
  phone: '9876543210',
  whatsappNumber: '919876543210',
  address: 'Shop 12',
  cityState: 'Gorakhpur',
  timings: '10am-9pm',
  announcement: 'Banner',
};

test('shareProductDetails handles fallback environment gracefully', async () => {
  // In Node environment, navigator is undefined
  const result = await shareProductDetails(mockProduct, mockConfig, 'hi');
  assert.equal(typeof result.success, 'boolean');
});

test('shareCatalogLink formats message properly without errors', async () => {
  const result = await shareCatalogLink(mockConfig, 'hi');
  assert.equal(typeof result.success, 'boolean');
});
