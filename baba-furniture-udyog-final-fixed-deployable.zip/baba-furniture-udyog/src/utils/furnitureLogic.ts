import {
  ChatMessage,
  CustomerInquiry,
  FurnitureCategory,
  Product,
  ShowroomConfig,
} from '../types/furniture';

/**
 * Formats a clean 10-12 digit WhatsApp phone number with India country code (91) if 10 digits
 */
export function normalizeWhatsAppNumber(rawPhone: string): string {
  const digits = rawPhone.replace(/[^0-9]/g, '');
  if (digits.length === 10) {
    return `91${digits}`;
  }
  if (digits.length === 11 && digits.startsWith('0')) {
    return `91${digits.slice(1)}`;
  }
  return digits || '919876543210';
}

/**
 * Formats a clean WhatsApp click-to-chat URL with a prefilled inquiry message
 */
export function buildWhatsAppInquiryUrl(params: {
  whatsappNumber: string;
  productTitle?: string;
  sku?: string;
  woodType?: string;
  customMessage?: string;
  customerName?: string;
}): string {
  const cleanNumber = normalizeWhatsAppNumber(params.whatsappNumber);
  let message = `नमस्ते Baba Furniture Udyog,\n`;

  if (params.customerName) {
    message += `मेरा नाम ${params.customerName} है।\n`;
  }

  if (params.productTitle) {
    message += `मुझे आपके फर्नीचर "${params.productTitle}"`;
    if (params.sku) {
      message += ` (SKU: ${params.sku})`;
    }
    message += ` के बारे में जानकारी और कीमत चाहिए।\n`;
    if (params.woodType) {
      message += `पसंदीदा लकड़ी: ${params.woodType}\n`;
    }
  } else if (params.customMessage) {
    message += `कस्टम फर्नीचर पूछताछ:\n${params.customMessage}\n`;
  } else {
    message += `मुझे आपके शोरूम के फर्नीचर कलेक्शंस के बारे में कोटेशन चाहिए।\n`;
  }

  message += `कृपया मुझे विवरण और कैटलॉग भेजें। धन्यवाद!`;

  return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
}

/**
 * Filter products by category, search query, and wood type
 */
export function filterProducts(
  products: Product[],
  options: {
    category?: FurnitureCategory;
    searchQuery?: string;
    woodType?: string;
  }
): Product[] {
  return products.filter((item) => {
    if (options.category && options.category !== 'all' && item.category !== options.category) {
      return false;
    }

    if (options.woodType && options.woodType !== 'all' && item.woodType !== options.woodType) {
      return false;
    }

    if (options.searchQuery && options.searchQuery.trim() !== '') {
      const q = options.searchQuery.toLowerCase().trim();
      const matchTitle = item.title.toLowerCase().includes(q);
      const matchTitleHi = item.titleHi.toLowerCase().includes(q);
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchDescHi = item.descriptionHi.toLowerCase().includes(q);
      const matchCategory = item.categoryLabel.toLowerCase().includes(q);
      const matchCategoryHi = item.categoryLabelHi.toLowerCase().includes(q);
      const matchWood = item.woodType.toLowerCase().includes(q);
      const matchSku = item.sku.toLowerCase().includes(q);
      const matchFeatures = item.features.some((f) => f.toLowerCase().includes(q));
      const matchFeaturesHi = item.featuresHi.some((f) => f.toLowerCase().includes(q));

      if (
        !matchTitle &&
        !matchTitleHi &&
        !matchDesc &&
        !matchDescHi &&
        !matchCategory &&
        !matchCategoryHi &&
        !matchWood &&
        !matchSku &&
        !matchFeatures &&
        !matchFeaturesHi
      ) {
        return false;
      }
    }

    return true;
  });
}

/**
 * Validates a quote inquiry form
 */
export function validateInquiryForm(form: {
  customerName: string;
  phone: string;
}): { isValid: boolean; error?: string } {
  if (!form.customerName || form.customerName.trim().length < 2) {
    return { isValid: false, error: 'कृपया अपना नाम दर्ज करें (कम से कम 2 अक्षर)' };
  }

  const cleanPhone = form.phone.replace(/[^0-9]/g, '');
  if (cleanPhone.length < 10) {
    return { isValid: false, error: 'कृपया एक मान्य 10-अंकों का मोबाइल नंबर दर्ज करें' };
  }

  return { isValid: true };
}

/**
 * Calculates whether a piece of furniture fits comfortably in a room
 * Standard clearance recommends at least 2.5 to 3.0 feet walk-space around furniture
 */
export interface RoomFitResult {
  fits: boolean;
  clearanceLengthFt: number;
  clearanceWidthFt: number;
  areaUtilizationPct: number;
  recommendation: string;
  recommendationHi: string;
}

export function calculateRoomFit(
  roomLengthFt: number,
  roomWidthFt: number,
  furnitureLengthFt: number,
  furnitureWidthFt: number
): RoomFitResult {
  if (
    !Number.isFinite(roomLengthFt) ||
    !Number.isFinite(roomWidthFt) ||
    roomLengthFt <= 0 ||
    roomWidthFt <= 0 ||
    furnitureLengthFt <= 0 ||
    furnitureWidthFt <= 0
  ) {
    return {
      fits: false,
      clearanceLengthFt: 0,
      clearanceWidthFt: 0,
      areaUtilizationPct: 0,
      recommendation: 'Please enter valid positive dimensions.',
      recommendationHi: 'कृपया मान्य माप दर्ज करें।',
    };
  }

  const clearanceLength = roomLengthFt - furnitureLengthFt;
  const clearanceWidth = roomWidthFt - furnitureWidthFt;

  const roomArea = roomLengthFt * roomWidthFt;
  const furnitureArea = furnitureLengthFt * furnitureWidthFt;
  const areaUtilization = Math.min(100, Math.round((furnitureArea / roomArea) * 100));

  const fitsComfortably = clearanceLength >= 2.5 && clearanceWidth >= 2.5;

  let recommendation = '';
  let recommendationHi = '';

  if (!fitsComfortably) {
    if (clearanceLength < 1.5 || clearanceWidth < 1.5) {
      recommendation = 'Too tight for this room. Doors or walkways may be obstructed.';
      recommendationHi = 'यह साइज कमरे के लिए बहुत बड़ा है। आने-जाने का रास्ता रुक सकता है।';
    } else {
      recommendation = 'Snug fit. Leaves minimal walking space. Consider compact sizing.';
      recommendationHi = 'फिट तो हो जाएगा, लेकिन चलने-फिरने की जगह कम बचेगी।';
    }
  } else if (areaUtilization <= 35) {
    recommendation = 'Ideal spacious layout! Leaves ample room for side tables and movement.';
    recommendationHi = 'उत्तम साइज! कमरे में साइड टेबल और घूमने-फिरने के लिए पर्याप्त जगह रहेगी।';
  } else {
    recommendation = 'Balanced fit. Suitable with standard circulation around the piece.';
    recommendationHi = 'संतुलित फिट। कमरे की बनावट के लिए पूरी तरह अनुकूल है।';
  }

  return {
    fits: fitsComfortably,
    clearanceLengthFt: Math.max(0, Number(clearanceLength.toFixed(1))),
    clearanceWidthFt: Math.max(0, Number(clearanceWidth.toFixed(1))),
    areaUtilizationPct: areaUtilization,
    recommendation,
    recommendationHi,
  };
}

/**
 * Generate CSV text for customer inquiries for export
 */
export function exportInquiriesToCsv(inquiries: CustomerInquiry[]): string {
  const headers = [
    'Inquiry ID',
    'Date',
    'Customer Name',
    'Phone',
    'City',
    'Preferred Contact',
    'Product Interested',
    'SKU',
    'Status',
    'Custom Note',
  ];
  const rows = inquiries.map((item) => [
    `"${item.id}"`,
    `"${item.formattedDate}"`,
    `"${item.customerName.replace(/"/g, '""')}"`,
    `"${item.phone}"`,
    `"${(item.city || '').replace(/"/g, '""')}"`,
    `"${item.preferredContact}"`,
    `"${(item.productTitle || 'General / Custom').replace(/"/g, '""')}"`,
    `"${item.productSku || '-'}"`,
    `"${item.status}"`,
    `"${(item.customDesignNote || '').replace(/"/g, '""').replace(/\r?\n/g, ' ')}"`,
  ]);

  return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
}

/**
 * Deterministic bilingual assistant reply helper shared by frontend and Express backend
 */
export function generateAssistantResponse(
  text: string,
  lang: 'hi' | 'en',
  config: ShowroomConfig
): { text: string; suggestedAction?: ChatMessage['suggestedAction'] } {
  const lower = text.toLowerCase();

  if (
    lower.includes('बेड') ||
    lower.includes('bed') ||
    lower.includes('king') ||
    lower.includes('किंग')
  ) {
    return {
      text:
        lang === 'hi'
          ? 'हमारे पास महाराजा रॉयल सागवान किंग बेड (78"x72") और शीशम बॉक्स बेड उपलब्ध हैं। इनमें हैवी-ड्यूटी हाइड्रोलिक स्टोरेज और 10 साल की दीमक गारंटी मिलती है।'
          : 'We craft Maharaja Solid Teak King Beds (78"x72") and Sheesham Box Beds equipped with heavy hydraulic lifts and a 10-year termite warranty.',
      suggestedAction: {
        type: 'catalog',
        label: lang === 'hi' ? 'बेड्स कैटलॉग देखें' : 'View Beds Catalog',
      },
    };
  }

  if (
    lower.includes('सागवान') ||
    lower.includes('शीशम') ||
    lower.includes('teak') ||
    lower.includes('sheesham') ||
    lower.includes('wood') ||
    lower.includes('लकड़ी')
  ) {
    return {
      text:
        lang === 'hi'
          ? 'सागवान (Teak) में कुदरती तेल अधिक होने से यह 100% दीमक-रोधी और 50+ साल चलने वाला होता है। शीशम (Sheesham) अपनी सुंदर कुदरती नसों और भारी मजबूती के लिए डाइनिंग टेबल व अलमारी के लिए श्रेष्ठ माना जाता है।'
          : 'Teak has natural oils offering 100% termite immunity (50+ yrs lifespan). Sheesham provides dense interlocking grain, ideal for dining tables and heavy almirahs.',
      suggestedAction: {
        type: 'chart',
        label: lang === 'hi' ? '📊 लकड़ी तुलना चार्ट देखें' : '📊 View Wood Spec Chart',
      },
    };
  }

  if (
    lower.includes('कस्टम') ||
    lower.includes('custom') ||
    lower.includes('साइज') ||
    lower.includes('नाप')
  ) {
    return {
      text:
        lang === 'hi'
          ? 'हाँ जी! आप Pinterest, Instagram या किसी भी शोरूम की फोटो भेजकर अपनी दीवार और कमरे के सटीक साइज अनुसार फर्नीचर बनवा सकते हैं।'
          : 'Yes! You can upload reference photos or sketches, specify timber and dimensions, and our workshop will build it to your exact specifications.',
      suggestedAction: {
        type: 'custom_order',
        label: lang === 'hi' ? 'फोटो / डिज़ाइन अपलोड करें' : 'Upload Design Blueprint',
      },
    };
  }

  if (
    lower.includes('दुकान') ||
    lower.includes('पता') ||
    lower.includes('address') ||
    lower.includes('timing') ||
    lower.includes('समय') ||
    lower.includes('कहाँ')
  ) {
    return {
      text:
        lang === 'hi'
          ? `हमारी दुकान का पता: ${config.address}, ${config.cityState}।\nखुलने का समय: ${config.timings}।\nफोन: ${config.phone}।`
          : `Showroom Address: ${config.address}, ${config.cityState}.\nTimings: ${config.timings}.\nPhone: ${config.phone}.`,
      suggestedAction: {
        type: 'call',
        label: lang === 'hi' ? 'दुकान पर कॉल करें' : 'Call Showroom',
      },
    };
  }

  return {
    text:
      lang === 'hi'
        ? `धन्यवाद आपके सवाल के लिए! हमारे दुकान संचालक (${config.ownerName}) से सीधे व्हाट्सएप पर बात करने के लिए नीचे दिए गए व्हाट्सएप बटन पर क्लिक करें।`
        : `Thank you for your inquiry! You can chat directly with our showroom owner (${config.ownerName}) via WhatsApp:`,
    suggestedAction: {
      type: 'whatsapp',
      label: lang === 'hi' ? 'व्हाट्सएप चैट खोलें' : 'Chat on WhatsApp',
    },
  };
}
