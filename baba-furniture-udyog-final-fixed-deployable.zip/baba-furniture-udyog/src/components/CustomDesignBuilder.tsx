import React, { useState } from 'react';
import { CustomerInquiry, CustomerUser, ShowroomConfig } from '../types/furniture';
import { validateInquiryForm, buildWhatsAppInquiryUrl } from '../utils/furnitureLogic';
import { UploadCloud, CheckCircle2, Send, MessageCircle, X, Sparkles } from 'lucide-react';

interface CustomDesignBuilderProps {
  config: ShowroomConfig;
  lang: 'hi' | 'en';
  customerUser?: CustomerUser | null;
  onClose?: () => void;
  onSubmitInquiry: (inquiry: Omit<CustomerInquiry, 'id' | 'timestamp' | 'formattedDate' | 'status'>) => void;
}

export const CustomDesignBuilder: React.FC<CustomDesignBuilderProps> = ({
  config,
  lang,
  customerUser,
  onClose,
  onSubmitInquiry,
}) => {
  const [furnitureType, setFurnitureType] = useState('Beds & Bedroom');
  const [woodType, setWoodType] = useState('Solid Teak (सागवान)');
  const [dimensions, setDimensions] = useState('6 ft x 6.5 ft (King Size)');
  const [finish, setFinish] = useState('Warm Walnut Polish');
  const [notes, setNotes] = useState('');
  const [customerName, setCustomerName] = useState(customerUser?.name || '');
  const [phone, setPhone] = useState(customerUser?.phone || '');
  const [city, setCity] = useState(customerUser?.city || '');
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setErrorMessage('कृपया 5MB से छोटी फोटो चुनें।');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
        setErrorMessage('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateInquiryForm({ customerName, phone });
    if (!validation.isValid) {
      setErrorMessage(validation.error || 'Please fill required details.');
      return;
    }

    const noteText = `[Custom Order Request]\nType: ${furnitureType}\nWood: ${woodType}\nSize: ${dimensions}\nFinish: ${finish}\nCustomer Note: ${notes}`;

    onSubmitInquiry({
      customerName,
      phone,
      city,
      preferredContact: 'whatsapp',
      productTitle: `Custom ${furnitureType} Request`,
      woodPreference: woodType,
      customDesignNote: noteText,
      customDesignImage: previewImage || undefined,
    });

    setIsSubmitted(true);
  };

  const whatsAppMessage = `नमस्ते Baba Furniture Udyog,\nमेरा नाम ${customerName || 'Customer'} है।\nमुझे अपने घर के लिए कस्टम फर्नीचर बनवाना है:\n- प्रकार: ${furnitureType}\n- लकड़ी: ${woodType}\n- अनुमानित साइज: ${dimensions}\n- पॉलिश: ${finish}\n${notes ? `- विवरण: ${notes}\n` : ''}कृपया इसका कोटेशन और समय बताएं।`;

  const directWhatsAppUrl = buildWhatsAppInquiryUrl({
    whatsappNumber: config.whatsappNumber,
    customMessage: whatsAppMessage,
  });

  return (
    <div className="bg-[#FAF7F2] border border-[#E0D5C3] rounded-2xl p-6 sm:p-8 shadow-sm">
      <div className="flex items-start justify-between gap-4 pb-4 border-b border-[#E8DEC8]">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#8E5327] bg-[#F1E7D6] px-2.5 py-0.5 rounded">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'कस्टम फर्नीचर निर्माण' : 'Bespoke Furniture Workshop'}</span>
          </div>
          <h3 className="font-display text-xl sm:text-2xl font-bold text-[#2D2319] pt-1">
            {lang === 'hi' ? 'अपना मनपसंद डिज़ाइन भेजें (Custom Order)' : 'Build to Your Exact Blueprint'}
          </h3>
          <p className="text-xs sm:text-sm text-[#6A5A4A] pt-1">
            {lang === 'hi'
              ? 'Pinterest, Instagram या किसी शोरूम की फोटो अपलोड करें। हम सीधे अपनी फैक्ट्री में आपके साइज और बजट अनुसार तैयार करेंगे।'
              : 'Upload a reference photo from Pinterest, Instagram or sketches. We will craft it in solid seasoned timber to your exact room specs.'}
          </p>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="no-print p-1 text-stone-500 hover:text-stone-900 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {isSubmitted ? (
        <div className="py-8 text-center space-y-4">
          <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-700">
            <CheckCircle2 className="w-9 h-9" />
          </div>
          <h4 className="font-display text-xl font-bold text-[#2D2319]">
            {lang === 'hi' ? 'कस्टम डिज़ाइन अनुरोध सफलतापूर्वक दर्ज हुआ!' : 'Design Blueprint Received!'}
          </h4>
          <p className="text-sm text-[#5A4D40] max-w-md mx-auto leading-relaxed">
            {lang === 'hi'
              ? `श्री ${customerName}, हमारे मास्टर कारपेंटर आपकी आवश्यकता का अध्ययन कर रहे हैं। तुरंत फोटो भेजने या बात करने के लिए व्हाट्सएप पर क्लिक करें:`
              : `Thank you ${customerName}! Our master craftsmen are reviewing your specs. Open WhatsApp to immediately share more references:`}
          </p>

          <div className="no-print pt-3 flex flex-wrap justify-center gap-3">
            <a
              href={directWhatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-[#1E6B3E] hover:bg-[#165430] rounded-lg shadow-sm transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span>{lang === 'hi' ? 'व्हाट्सएप पर फोटो भेजें' : 'Chat & Send Photos on WhatsApp'}</span>
            </a>
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-5 py-3 text-sm font-semibold text-[#2D2319] bg-white border border-[#D5C2A5] hover:bg-[#FAF8F5] rounded-lg transition-colors cursor-pointer"
            >
              <span>{lang === 'hi' ? 'रसीद प्रिंट / डाउनलोड' : 'Print / Download Slip'}</span>
            </button>
            <button
              onClick={() => {
                setIsSubmitted(false);
                if (onClose) onClose();
              }}
              className="px-5 py-3 text-sm font-medium text-[#2D2319] bg-[#EFE6D8] hover:bg-[#E3D6C1] rounded-lg transition-colors cursor-pointer"
            >
              {lang === 'hi' ? 'पूर्ण हुआ' : 'Done'}
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="pt-6 space-y-5">
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-xs rounded-md">
              {errorMessage}
            </div>
          )}

          {/* Grid selections */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Furniture Type */}
            <div>
              <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                {lang === 'hi' ? 'फर्नीचर का प्रकार' : 'Furniture Category'}
              </label>
              <select
                value={furnitureType}
                onChange={(e) => setFurnitureType(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
              >
                <option value="Beds & Bedroom">{lang === 'hi' ? 'बेड (King / Queen)' : 'Beds & Bedroom'}</option>
                <option value="Dining Sets">{lang === 'hi' ? 'डाइनिंग टेबल व कुर्सियां' : 'Dining Sets'}</option>
                <option value="Luxury Sofas">{lang === 'hi' ? 'शाही सोफा सेट' : 'Living Sofas'}</option>
                <option value="Almirahs & Wardrobes">{lang === 'hi' ? 'अलमारी / वार्डरोब' : 'Wardrobes'}</option>
                <option value="Wooden Mandir">{lang === 'hi' ? 'पूजा मंदिर' : 'Puja Mandir'}</option>
                <option value="TV Units & Tables">{lang === 'hi' ? 'टीवी यूनिट व टेबल' : 'TV Console / Table'}</option>
                <option value="Office & Study">{lang === 'hi' ? 'ऑफिस व स्टडी टेबल' : 'Office & Study Desk'}</option>
                <option value="Complete Home Set">{lang === 'hi' ? 'पूरे घर का फर्नीचर (फुल पैकेज)' : 'Complete Home Package'}</option>
              </select>
            </div>

            {/* Wood Selection */}
            <div>
              <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                {lang === 'hi' ? 'पसंदीदा लकड़ी' : 'Preferred Timber'}
              </label>
              <select
                value={woodType}
                onChange={(e) => setWoodType(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
              >
                <option value="Solid Teak (सागवान)">Solid Teak (सागवान) - Most Durable</option>
                <option value="Pure Sheesham (शीशम)">Pure Sheesham (शीशम) - Natural Grain</option>
                <option value="Rosewood (शीशम रोसवुड)">Rosewood (शीशम रोसवुड) - Luxury Carved</option>
                <option value="Engineered Hardwood">Engineered Hardwood</option>
                <option value="Marine Grade Ply">Marine Grade Ply (Modular / Wardrobe)</option>
              </select>
            </div>

            {/* Dimensions */}
            <div>
              <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                {lang === 'hi' ? 'अनुमानित साइज / माप' : 'Approx Dimensions'}
              </label>
              <input
                type="text"
                placeholder={lang === 'hi' ? 'जैसे: 6x6.5 फीट, या 6-सीटर...' : 'e.g. 6x6.5 ft or 6-seater'}
                value={dimensions}
                onChange={(e) => setDimensions(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
              />
            </div>

            {/* Polish Finish */}
            <div>
              <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                {lang === 'hi' ? 'पॉलिश शेड' : 'Polish Tone'}
              </label>
              <select
                value={finish}
                onChange={(e) => setFinish(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
              >
                <option value="Warm Walnut Polish">Warm Walnut Polish (रिच डार्क)</option>
                <option value="Natural Teak Honey">Natural Honey Gloss (गोल्डन)</option>
                <option value="Antique Matte">Antique Matte Finish (सटल मैट)</option>
                <option value="Deco High Gloss">Deco High Gloss Paint / Duco</option>
              </select>
            </div>
          </div>

          {/* Photo Upload Area */}
          <div>
            <label className="block text-xs font-semibold text-[#2D2319] mb-1">
              {lang === 'hi' ? 'रेफरेंस फोटो / डिज़ाइन अपलोड करें (वैकल्पिक)' : 'Reference Image or Sketch (Optional)'}
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed border-[#D5C2A5] rounded-xl bg-white hover:bg-[#FAF8F5] transition-colors relative">
              <div className="space-y-2 text-center">
                {previewImage ? (
                  <div className="relative inline-block">
                    <img
                      src={previewImage}
                      alt="Uploaded Reference Preview"
                      className="h-32 w-auto object-cover rounded-lg border border-[#D5C2A5]"
                    />
                    <button
                      type="button"
                      onClick={() => setPreviewImage(null)}
                      className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full p-1 shadow-sm hover:bg-red-700 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <>
                    <UploadCloud className="mx-auto h-8 w-8 text-[#8E5327]" />
                    <div className="flex text-xs text-[#5A4D40] justify-center">
                      <label className="relative cursor-pointer rounded-md font-semibold text-[#8E5327] hover:underline focus-within:outline-none">
                        <span>{lang === 'hi' ? 'अपने फोन या कंप्यूटर से फोटो चुनें' : 'Upload from your device'}</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="sr-only"
                        />
                      </label>
                    </div>
                    <p className="text-[11px] text-stone-400">PNG, JPG, WEBP (अधिकतम 5MB)</p>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Description & Contact Details */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                {lang === 'hi' ? 'आपका नाम *' : 'Your Name *'}
              </label>
              <input
                type="text"
                required
                placeholder={lang === 'hi' ? 'जैसे: विकास चौरसिया' : 'e.g. Vikash Chaurasia'}
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                {lang === 'hi' ? 'मोबाइल नंबर (WhatsApp) *' : 'Phone / WhatsApp *'}
              </label>
              <input
                type="tel"
                required
                placeholder="9876543210"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                {lang === 'hi' ? 'शहर / डिलीवरी स्थान' : 'City / Delivery Location'}
              </label>
              <input
                type="text"
                placeholder={lang === 'hi' ? 'जैसे: गोरखपुर, देवरिया' : 'e.g. Gorakhpur'}
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#2D2319] mb-1">
              {lang === 'hi' ? 'विशेष आवश्यकताएं / नोट' : 'Any Specific Instructions'}
            </label>
            <textarea
              rows={2}
              placeholder={
                lang === 'hi'
                  ? 'जैसे: मुझे बेड में एक्स्ट्रा बॉक्स स्टोरेज चाहिए, या मंदिर में घंटी के साथ दराज चाहिए...'
                  : 'Tell us any details about hydraulic lift, wood thickness, custom carving, or delivery deadline...'
              }
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
            />
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-lg shadow-sm transition-all cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>{lang === 'hi' ? 'कस्टम डिज़ाइन कोटेशन भेजें' : 'Request Custom Blueprint Quote'}</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
