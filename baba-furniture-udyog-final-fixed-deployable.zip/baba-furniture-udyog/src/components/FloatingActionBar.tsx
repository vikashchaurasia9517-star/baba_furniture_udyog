import React from 'react';
import { ShowroomConfig } from '../types/furniture';
import { Phone, MessageCircle, Sparkles } from 'lucide-react';

interface FloatingActionBarProps {
  config: ShowroomConfig;
  lang: 'hi' | 'en';
  onOpenCustomOrder: () => void;
  onOpenLiveChat: () => void;
}

export const FloatingActionBar: React.FC<FloatingActionBarProps> = ({
  config,
  lang,
  onOpenCustomOrder,
  onOpenLiveChat,
}) => {
  return (
    <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#2D2319]/95 backdrop-blur-md border-t border-[#4A3B2B] px-3 py-2 text-white shadow-2xl flex items-center justify-between gap-2 max-h-[58px]">
      {/* Call button */}
      <a
        href={`tel:${config.phone.replace(/[^0-9+]/g, '')}`}
        className="flex-1 flex items-center justify-center gap-1.5 py-2 px-2 text-xs font-semibold text-[#E7D6C4] bg-[#3B2F23] hover:bg-[#4A3B2B] rounded-md transition-colors"
      >
        <Phone className="w-3.5 h-3.5 text-[#C89D66]" />
        <span>{lang === 'hi' ? 'कॉल करें' : 'Call'}</span>
      </a>

      {/* Live Chat button */}
      <button
        onClick={onOpenLiveChat}
        className="flex-1 flex items-center justify-center gap-1.5 py-2 px-2 text-xs font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-md transition-colors cursor-pointer"
      >
        <MessageCircle className="w-3.5 h-3.5 fill-white" />
        <span>{lang === 'hi' ? 'लाइव चैट' : 'Live Chat'}</span>
      </button>

      {/* Custom Order */}
      <button
        onClick={onOpenCustomOrder}
        className="flex-1 flex items-center justify-center gap-1.5 py-2 px-2 text-xs font-semibold text-[#241E19] bg-[#C89D66] hover:bg-[#B38750] rounded-md transition-colors cursor-pointer"
      >
        <Sparkles className="w-3.5 h-3.5" />
        <span className="truncate">{lang === 'hi' ? 'कस्टम ऑर्डर' : 'Custom'}</span>
      </button>
    </div>
  );
};
