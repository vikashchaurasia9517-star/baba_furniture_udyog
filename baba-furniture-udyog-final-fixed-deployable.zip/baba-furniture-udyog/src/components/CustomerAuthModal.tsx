import React, { useState, useEffect } from 'react';
import { AuthMethodsConfig, CustomerInquiry, CustomerUser, ShowroomConfig } from '../types/furniture';
import {
  supabaseSignUpCustomerApi,
  supabaseSignInCustomerApi,
  supabaseSendEmailOtpApi,
  supabaseVerifyEmailOtpApi,
  supabaseForgotPasswordApi,
  supabaseResetPasswordApi,
  supabaseChangePasswordApi,
  supabaseResendVerificationApi,
  supabaseUpdateCustomerProfileApi,
  supabaseDeleteCustomerAccountApi,
  supabaseSignOutCustomerApi,
  getFrontendSupabaseClient,
} from '../services/api';
import {
  X,
  User,
  LogOut,
  KeyRound,
  MapPin,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Mail,
  Sparkles,
  ArrowRight,
  RefreshCw,
  AlertCircle,
  Eye,
  EyeOff,
  Lock,
  Trash2,
  Save,
  ShieldAlert,
  HelpCircle,
  Settings,
  Phone,
  Building,
} from 'lucide-react';

export interface CustomerAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  customerUser: CustomerUser | null;
  onCustomerChange?: (user: CustomerUser | null) => void;
  onUpdateCustomerUser?: (user: CustomerUser | null) => void;
  inquiries: CustomerInquiry[];
  config: ShowroomConfig;
  lang: 'hi' | 'en';
  onOpenCustomOrder?: () => void;
  initialMode?: 'password' | 'register' | 'otp' | 'forgot' | 'reset-password' | 'account-settings';
  authMethodsConfig?: AuthMethodsConfig;
}

export const CustomerAuthModal: React.FC<CustomerAuthModalProps> = ({
  isOpen,
  onClose,
  customerUser,
  onCustomerChange,
  onUpdateCustomerUser,
  inquiries,
  config,
  lang,
  onOpenCustomOrder,
  initialMode = 'password',
  authMethodsConfig,
}) => {
  const activeMethods: AuthMethodsConfig = authMethodsConfig || {
    emailPasswordEnabled: true,
    emailOtpEnabled: true,
    googleAuthEnabled: true,
    phoneOtpEnabled: false,
    whatsappOtpEnabled: false,
  };
  const updateCustomer = (user: CustomerUser | null) => {
    if (onUpdateCustomerUser) onUpdateCustomerUser(user);
    if (onCustomerChange) onCustomerChange(user);
  };

  // Auth Modes: 'password' | 'register' | 'otp' | 'forgot' | 'reset-password'
  const [authMode, setAuthMode] = useState<
    'password' | 'register' | 'otp' | 'forgot' | 'reset-password'
  >(initialMode === 'reset-password' ? 'reset-password' : initialMode === 'register' ? 'register' : initialMode === 'otp' ? 'otp' : 'password');

  // Account Settings Subtabs (for logged-in user)
  const [accountTab, setAccountTab] = useState<'profile' | 'inquiries' | 'security' | 'delete'>('profile');

  // Password Login State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Registration State
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [showRegConfirmPassword, setShowRegConfirmPassword] = useState(false);
  const [regTermsAccepted, setRegTermsAccepted] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);

  // Verification Pending State
  const [verificationPendingEmail, setVerificationPendingEmail] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);
  const [isResendingVerification, setIsResendingVerification] = useState(false);

  // Email OTP Login State
  const [otpEmail, setOtpEmail] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [otpCooldown, setOtpCooldown] = useState(0);
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);

  // Forgot Password State
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSent, setForgotSent] = useState(false);
  const [forgotCooldown, setForgotCooldown] = useState(0);
  const [isSendingForgot, setIsSendingForgot] = useState(false);

  // Reset Password State
  const [resetNewPassword, setResetNewPassword] = useState('');
  const [resetConfirmPassword, setResetConfirmPassword] = useState('');
  const [showResetNewPassword, setShowResetNewPassword] = useState(false);
  const [showResetConfirmPassword, setShowResetConfirmPassword] = useState(false);
  const [isResettingPassword, setIsResettingPassword] = useState(false);
  const [resetCompleted, setResetCompleted] = useState(false);

  // Customer Profile Editing State
  const [profileName, setProfileName] = useState(customerUser?.name || '');
  const [profilePhone, setProfilePhone] = useState(customerUser?.phone || '');
  const [profileAddress, setProfileAddress] = useState(customerUser?.fullAddress || '');
  const [profileCity, setProfileCity] = useState(customerUser?.city || 'Gorakhpur');
  const [profilePincode, setProfilePincode] = useState(customerUser?.pincode || '273001');
  const [profileLandmark, setProfileLandmark] = useState(customerUser?.landmark || '');
  const [profileAltPhone, setProfileAltPhone] = useState(customerUser?.alternatePhone || '');
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  // Change / Set Password State
  const [changeCurrentPassword, setChangeCurrentPassword] = useState('');
  const [changeNewPassword, setChangeNewPassword] = useState('');
  const [changeConfirmPassword, setChangeConfirmPassword] = useState('');
  const [showChangeCurrent, setShowChangeCurrent] = useState(false);
  const [showChangeNew, setShowChangeNew] = useState(false);
  const [showChangeConfirm, setShowChangeConfirm] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // Delete Account State
  const [deleteConfirmationText, setDeleteConfirmationText] = useState('');
  const [deletePassword, setDeletePassword] = useState('');
  const [showDeletePassword, setShowDeletePassword] = useState(false);
  const [isDeletingAccount, setIsDeletingAccount] = useState(false);

  // Common UI State
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  // Sync profile form when customerUser changes
  useEffect(() => {
    if (customerUser) {
      setProfileName(customerUser.name || '');
      setProfilePhone(customerUser.phone || '');
      setProfileAddress(customerUser.fullAddress || '');
      setProfileCity(customerUser.city || 'Gorakhpur');
      setProfilePincode(customerUser.pincode || '273001');
      setProfileLandmark(customerUser.landmark || '');
      setProfileAltPhone(customerUser.alternatePhone || '');
    }
  }, [customerUser]);

  // Handle initialMode changes
  useEffect(() => {
    if (initialMode === 'reset-password') {
      setAuthMode('reset-password');
    }
  }, [initialMode]);

  // Timers for cooldowns
  useEffect(() => {
    let t: any = null;
    if (resendCooldown > 0) {
      t = setInterval(() => setResendCooldown((p) => Math.max(0, p - 1)), 1000);
    }
    return () => {
      if (t) clearInterval(t);
    };
  }, [resendCooldown]);

  useEffect(() => {
    let t: any = null;
    if (otpCooldown > 0) {
      t = setInterval(() => setOtpCooldown((p) => Math.max(0, p - 1)), 1000);
    }
    return () => {
      if (t) clearInterval(t);
    };
  }, [otpCooldown]);

  useEffect(() => {
    let t: any = null;
    if (forgotCooldown > 0) {
      t = setInterval(() => setForgotCooldown((p) => Math.max(0, p - 1)), 1000);
    }
    return () => {
      if (t) clearInterval(t);
    };
  }, [forgotCooldown]);

  if (!isOpen) return null;

  // Filter inquiries for this customer
  const myInquiries = inquiries.filter((inq) => {
    if (!customerUser) return false;
    const userPhoneClean = (customerUser.phone || '').replace(/[^0-9]/g, '').slice(-10);
    const inqPhoneClean = (inq.customerPhone || '').replace(/[^0-9]/g, '').slice(-10);
    if (userPhoneClean && inqPhoneClean && userPhoneClean === inqPhoneClean) return true;
    if (customerUser.email && inq.customerEmail && customerUser.email.toLowerCase() === inq.customerEmail.toLowerCase()) return true;
    return false;
  });

  // --------------------------------------------------------------------------
  // HANDLERS
  // --------------------------------------------------------------------------

  // 1. Password Login
  const handlePasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setNotice('');

    const email = loginEmail.trim();
    if (!email || !loginPassword) {
      setError(lang === 'hi' ? 'कृपया ईमेल और पासवर्ड दर्ज करें।' : 'Please enter both email and password.');
      return;
    }

    setIsLoggingIn(true);
    const res = await supabaseSignInCustomerApi(email, loginPassword);
    setIsLoggingIn(false);

    if (!res.success || !res.user) {
      setError(res.error || (lang === 'hi' ? 'लॉगिन असफल रहा। कृपया ईमेल व पासवर्ड जांचें।' : 'Login failed. Please check your credentials.'));
      return;
    }

    updateCustomer(res.user);
    setNotice(lang === 'hi' ? 'सफलतापूर्वक लॉगिन हो गया!' : 'Successfully signed in!');
  };

  // 2. Registration
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setNotice('');

    const name = regName.trim();
    const email = regEmail.trim();

    if (!name || name.length < 2) {
      setError(lang === 'hi' ? 'कृपया अपना पूरा नाम दर्ज करें।' : 'Please enter your full name.');
      return;
    }
    if (!email || !email.includes('@')) {
      setError(lang === 'hi' ? 'कृपया एक वैध ईमेल पता दर्ज करें।' : 'Please enter a valid email address.');
      return;
    }
    if (regPassword.length < 6) {
      setError(lang === 'hi' ? 'पासवर्ड कम से कम 6 अक्षरों का होना चाहिए।' : 'Password must be at least 6 characters.');
      return;
    }
    if (regPassword !== regConfirmPassword) {
      setError(lang === 'hi' ? 'पासवर्ड और कन्फर्म पासवर्ड एक समान होने चाहिए।' : 'Passwords do not match.');
      return;
    }
    if (!regTermsAccepted) {
      setError(lang === 'hi' ? 'कृपया सेवा की शर्तें और गोपनीयता नीति स्वीकार करें।' : 'Please accept the Terms & Privacy Policy.');
      return;
    }

    setIsRegistering(true);
    const res = await supabaseSignUpCustomerApi({
      name,
      email,
      password: regPassword,
    });
    setIsRegistering(false);

    if (!res.success) {
      setError(res.error || (lang === 'hi' ? 'पंजीकरण असफल रहा।' : 'Registration failed.'));
      return;
    }

    if (res.emailConfirmationRequired) {
      setVerificationPendingEmail(email);
      setResendCooldown(60);
      setNotice(
        lang === 'hi'
          ? 'पंजीकरण सफल! सत्यापन ईमेल आपके इनबॉक्स में भेज दिया गया है।'
          : 'Registration successful! Verification email sent to your inbox.'
      );
    } else if (res.user) {
      updateCustomer(res.user);
      setNotice(lang === 'hi' ? 'खाता सफलतापूर्वक बन गया एवं लॉगिन हो गया!' : 'Account successfully created and signed in!');
    }
  };

  // 3. Resend Verification Email
  const handleResendVerification = async () => {
    if (resendCooldown > 0 || !verificationPendingEmail) return;
    setError('');
    setIsResendingVerification(true);
    const res = await supabaseResendVerificationApi(verificationPendingEmail);
    setIsResendingVerification(false);

    if (!res.success) {
      setError(res.error || (lang === 'hi' ? 'सत्यापन ईमेल पुनः भेजने में त्रुटि हुई।' : 'Error resending verification email.'));
      return;
    }

    setResendCooldown(60);
    setNotice(res.message || (lang === 'hi' ? 'सत्यापन लिंक पुनः भेज दिया गया है।' : 'Verification link resent.'));
  };

  // 4. Send Email OTP
  const handleSendEmailOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setNotice('');

    const email = otpEmail.trim();
    if (!email || !email.includes('@')) {
      setError(lang === 'hi' ? 'कृपया एक वैध ईमेल पता दर्ज करें।' : 'Please enter a valid email address.');
      return;
    }

    setIsSendingOtp(true);
    const res = await supabaseSendEmailOtpApi(email);
    setIsSendingOtp(false);

    if (!res.success) {
      setError(res.error || (lang === 'hi' ? 'OTP भेजने में त्रुटि हुई।' : 'Error sending OTP.'));
      return;
    }

    setOtpSent(true);
    setOtpCooldown(60);
    setNotice(res.message || (lang === 'hi' ? 'OTP आपके ईमेल पर भेज दिया गया है।' : 'OTP sent to your email.'));
  };

  // 5. Verify Email OTP
  const handleVerifyEmailOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setNotice('');

    const email = otpEmail.trim();
    const token = otpCode.trim();

    if (!token || token.length < 6) {
      setError(lang === 'hi' ? 'कृपया 6-अंकों का मान्य OTP कोड दर्ज करें।' : 'Please enter valid 6-digit OTP code.');
      return;
    }

    setIsVerifyingOtp(true);
    const res = await supabaseVerifyEmailOtpApi(email, token);
    setIsVerifyingOtp(false);

    if (!res.success || !res.user) {
      setError(res.error || (lang === 'hi' ? 'अमान्य या समाप्त हो चुका OTP कोड।' : 'Invalid or expired OTP code.'));
      return;
    }

    updateCustomer(res.user);
    setNotice(lang === 'hi' ? 'सफलतापूर्वक ईमेल OTP द्वारा लॉगिन हो गया!' : 'Successfully authenticated via Email OTP!');
  };

  // 6. Google Sign-In
  const handleGoogleSignIn = async () => {
    setError('');
    setNotice('');
    const sb = getFrontendSupabaseClient();
    if (!sb) {
      setError(lang === 'hi' ? 'Supabase क्लाइंट कॉन्फ़िगर नहीं है।' : 'Supabase client is not configured.');
      return;
    }

    try {
      const redirectUrl = `${window.location.origin}/`;
      const { error: oauthError } = await sb.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: redirectUrl,
        },
      });

      if (oauthError) {
        setError(oauthError.message || 'Google Auth Error');
      }
    } catch (err: any) {
      setError(err?.message || (lang === 'hi' ? 'Google लॉगिन में त्रुटि हुई।' : 'Error initiating Google login.'));
    }
  };

  // 7. Forgot Password
  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setNotice('');

    const email = forgotEmail.trim();
    if (!email || !email.includes('@')) {
      setError(lang === 'hi' ? 'कृपया एक वैध ईमेल पता दर्ज करें।' : 'Please enter a valid email address.');
      return;
    }

    setIsSendingForgot(true);
    const res = await supabaseForgotPasswordApi(email);
    setIsSendingForgot(false);

    if (!res.success) {
      setError(res.error || (lang === 'hi' ? 'अनुरोध भेजने में त्रुटि हुई।' : 'Error requesting password reset.'));
      return;
    }

    setForgotSent(true);
    setForgotCooldown(60);
    setNotice(res.message);
  };

  // 8. Reset Password (from recovery link)
  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setNotice('');

    if (resetNewPassword.length < 6) {
      setError(lang === 'hi' ? 'नया पासवर्ड कम से कम 6 अक्षरों का होना चाहिए।' : 'New password must be at least 6 characters.');
      return;
    }
    if (resetNewPassword !== resetConfirmPassword) {
      setError(lang === 'hi' ? 'पासवर्ड और कन्फर्म पासवर्ड एक समान होने चाहिए।' : 'Passwords do not match.');
      return;
    }

    setIsResettingPassword(true);
    const res = await supabaseResetPasswordApi(resetNewPassword);
    setIsResettingPassword(false);

    if (!res.success) {
      setError(res.error || (lang === 'hi' ? 'पासवर्ड रीसेट करने में त्रुटि हुई।' : 'Error resetting password.'));
      return;
    }

    setResetCompleted(true);
    setNotice(res.message);
  };

  // 9. Save Customer Profile
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerUser) return;
    setError('');
    setNotice('');

    const name = profileName.trim();
    if (!name || name.length < 2) {
      setError(lang === 'hi' ? 'कृपया मान्य नाम दर्ज करें।' : 'Please enter a valid name.');
      return;
    }

    setIsSavingProfile(true);
    const res = await supabaseUpdateCustomerProfileApi(customerUser, {
      name,
      phone: profilePhone.trim(),
      address: profileAddress.trim(),
      city: profileCity.trim(),
      pincode: profilePincode.trim(),
      landmark: profileLandmark.trim(),
      alternatePhone: profileAltPhone.trim(),
    });
    setIsSavingProfile(false);

    if (!res.success || !res.user) {
      setError(res.error || (lang === 'hi' ? 'प्रोफाइल सहेजने में त्रुटि हुई।' : 'Error saving profile.'));
      return;
    }

    updateCustomer(res.user);
    setNotice(lang === 'hi' ? 'प्रोफाइल सफलतापूर्वक अपडेट हो गई!' : 'Profile updated successfully!');
  };

  // 10. Change or Set Password
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerUser) return;
    setError('');
    setNotice('');

    if (customerUser.hasPassword && !changeCurrentPassword) {
      setError(lang === 'hi' ? 'कृपया अपना वर्तमान पासवर्ड दर्ज करें।' : 'Please enter your current password.');
      return;
    }
    if (changeNewPassword.length < 6) {
      setError(lang === 'hi' ? 'नया पासवर्ड कम से कम 6 अक्षरों का होना चाहिए।' : 'New password must be at least 6 characters.');
      return;
    }
    if (changeNewPassword !== changeConfirmPassword) {
      setError(lang === 'hi' ? 'नया पासवर्ड और कन्फर्म पासवर्ड मेल नहीं खाते।' : 'New passwords do not match.');
      return;
    }

    setIsChangingPassword(true);
    const res = await supabaseChangePasswordApi({
      user: customerUser,
      currentPassword: changeCurrentPassword,
      newPassword: changeNewPassword,
    });
    setIsChangingPassword(false);

    if (!res.success) {
      setError(res.error || (lang === 'hi' ? 'पासवर्ड बदलने में त्रुटि हुई।' : 'Error changing password.'));
      return;
    }

    setChangeCurrentPassword('');
    setChangeNewPassword('');
    setChangeConfirmPassword('');
    setNotice(res.message);

    // Update customer user hasPassword state
    updateCustomer({ ...customerUser, hasPassword: true });
  };

  // 11. Delete Account
  const handleDeleteAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerUser) return;
    setError('');
    setNotice('');

    if (deleteConfirmationText.trim().toUpperCase() !== 'DELETE') {
      setError(lang === 'hi' ? 'पुष्टि करने के लिए कृपया ठीक "DELETE" टाइप करें।' : 'Please type "DELETE" exactly to confirm.');
      return;
    }

    if (customerUser.hasPassword && !deletePassword) {
      setError(lang === 'hi' ? 'पुष्टि के लिए अपना वर्तमान पासवर्ड दर्ज करें।' : 'Please enter your current password to confirm.');
      return;
    }

    setIsDeletingAccount(true);
    const res = await supabaseDeleteCustomerAccountApi({
      user: customerUser,
      confirmationText: deleteConfirmationText.trim().toUpperCase(),
      currentPassword: deletePassword,
    });
    setIsDeletingAccount(false);

    if (!res.success) {
      setError(res.error || (lang === 'hi' ? 'खाता हटाने में त्रुटि हुई।' : 'Error deleting account.'));
      return;
    }

    updateCustomer(null);
    setNotice(res.message);
  };

  // 12. Sign Out
  const handleSignOut = async () => {
    await supabaseSignOutCustomerApi();
    updateCustomer(null);
    setNotice(lang === 'hi' ? 'सफलतापूर्वक लॉगआउट कर दिया गया।' : 'Successfully logged out.');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-[#FAF6F0] rounded-2xl max-w-2xl w-full border border-[#D4C3AA] shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="px-5 py-4 bg-[#2D2319] text-[#F5EBE1] flex items-center justify-between border-b border-[#4A3B2C]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#8E5327] flex items-center justify-center text-white shadow-xs">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold tracking-wide">
                {customerUser
                  ? lang === 'hi' ? 'ग्राहक खाता सेटिंग्स (Account Settings)' : 'Customer Account Settings'
                  : lang === 'hi' ? 'बाबा फ़र्नीचर उद्योग — ग्राहक लॉगिन / खाता' : 'Customer Account & Inquiries'}
              </h2>
              <p className="text-[11px] text-[#D8C7B5]">
                {customerUser
                  ? `${customerUser.email || customerUser.phone || 'Customer'} · Real Supabase Auth`
                  : lang === 'hi' ? 'प्रमाणित कोटेशन, ऑर्डर ट्रैकिंग एवं सुरक्षित सेवा' : 'Verified quotes, tracking & secure service'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#D8C7B5] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notice & Error Banners */}
        {notice && (
          <div className="mx-5 mt-4 p-3 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-xl text-xs flex items-start gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div className="flex-1 font-medium">{notice}</div>
            <button onClick={() => setNotice('')} className="text-emerald-700 hover:text-emerald-900">×</button>
          </div>
        )}

        {error && (
          <div className="mx-5 mt-4 p-3 bg-red-50 border border-red-300 text-red-900 rounded-xl text-xs flex items-start gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
            <div className="flex-1 font-medium">{error}</div>
            <button onClick={() => setError('')} className="text-red-700 hover:text-red-900">×</button>
          </div>
        )}

        <div className="p-5 max-h-[80vh] overflow-y-auto">
          {/* ================================================================ */}
          {/* LOGGED IN CUSTOMER VIEW (Account Settings & Profile)             */}
          {/* ================================================================ */}
          {customerUser ? (
            <div className="space-y-5">
              {/* User Overview Card */}
              <div className="p-4 rounded-xl bg-white border border-[#E2D6C3] flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
                <div className="space-y-1.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-bold text-base text-[#241E19]">{customerUser.name}</span>
                    {customerUser.emailVerified ? (
                      <span className="px-2.5 py-0.5 text-[11px] font-bold bg-emerald-100 text-emerald-800 rounded-full inline-flex items-center gap-1 border border-emerald-300">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                        {lang === 'hi' ? 'ईमेल सत्यापित' : 'Email Verified'}
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 text-[11px] font-bold bg-amber-100 text-amber-800 rounded-full inline-flex items-center gap-1 border border-amber-300">
                        <AlertCircle className="w-3.5 h-3.5 text-amber-700" />
                        {lang === 'hi' ? 'सत्यापन प्रतीक्षित' : 'Verification Pending'}
                      </span>
                    )}
                    <span className="px-2 py-0.5 text-[10px] font-semibold bg-[#F0E6D8] text-[#5C4938] rounded-md">
                      {customerUser.loginProvider === 'google' ? 'Google Sign-In' : customerUser.loginProvider === 'otp' ? 'Email OTP' : 'Email & Password'}
                    </span>
                  </div>

                  <div className="text-xs text-[#6E5E4F] flex flex-wrap items-center gap-x-3 gap-y-1">
                    {customerUser.email && (
                      <span className="inline-flex items-center gap-1">
                        <Mail className="w-3.5 h-3.5 text-[#8E5327]" />
                        {customerUser.email}
                      </span>
                    )}
                    {customerUser.phone && (
                      <span className="inline-flex items-center gap-1">
                        <Phone className="w-3.5 h-3.5 text-[#8E5327]" />
                        +91 {customerUser.phone}
                      </span>
                    )}
                    <span className="inline-flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-[#8E5327]" />
                      {customerUser.city || 'Gorakhpur'}
                    </span>
                  </div>

                  {!customerUser.emailVerified && customerUser.email && (
                    <div className="pt-1 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={async () => {
                          setError('');
                          const res = await supabaseResendVerificationApi(customerUser.email!);
                          if (res.success) setNotice(res.message);
                          else setError(res.error || 'पुनः सत्यापन भेजने में त्रुटि हुई।');
                        }}
                        className="text-[11px] font-bold text-[#8E5327] hover:underline cursor-pointer inline-flex items-center gap-1"
                      >
                        <RefreshCw className="w-3 h-3" />
                        {lang === 'hi' ? 'सत्यापन ईमेल पुनः भेजें (Resend Verification Email)' : 'Resend Verification Email'}
                      </button>
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {onOpenCustomOrder && (
                    <button
                      onClick={() => {
                        onClose();
                        onOpenCustomOrder();
                      }}
                      className="px-3 py-2 text-xs font-semibold bg-[#8E5327] hover:bg-[#72421E] text-white rounded-lg cursor-pointer transition-colors"
                    >
                      {lang === 'hi' ? 'कस्टम डिज़ाइन ऑर्डर' : 'Custom Order'}
                    </button>
                  )}
                  <button
                    onClick={handleSignOut}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 rounded-lg cursor-pointer transition-colors"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>{lang === 'hi' ? 'लॉगआउट' : 'Logout'}</span>
                  </button>
                </div>
              </div>

              {/* Sub-Navigation Tabs */}
              <div className="flex border-b border-[#D4C3AA] text-xs font-bold gap-2">
                <button
                  type="button"
                  onClick={() => setAccountTab('profile')}
                  className={`pb-2 px-3 border-b-2 transition-all cursor-pointer ${
                    accountTab === 'profile'
                      ? 'border-[#8E5327] text-[#8E5327]'
                      : 'border-transparent text-[#6E5E4F] hover:text-[#241E19]'
                  }`}
                >
                  👤 {lang === 'hi' ? 'प्रोफाइल व पता' : 'Profile & Address'}
                </button>
                <button
                  type="button"
                  onClick={() => setAccountTab('inquiries')}
                  className={`pb-2 px-3 border-b-2 transition-all cursor-pointer ${
                    accountTab === 'inquiries'
                      ? 'border-[#8E5327] text-[#8E5327]'
                      : 'border-transparent text-[#6E5E4F] hover:text-[#241E19]'
                  }`}
                >
                  📦 {lang === 'hi' ? `कोटेशन (${myInquiries.length})` : `Inquiries (${myInquiries.length})`}
                </button>
                <button
                  type="button"
                  onClick={() => setAccountTab('security')}
                  className={`pb-2 px-3 border-b-2 transition-all cursor-pointer ${
                    accountTab === 'security'
                      ? 'border-[#8E5327] text-[#8E5327]'
                      : 'border-transparent text-[#6E5E4F] hover:text-[#241E19]'
                  }`}
                >
                  🔐 {lang === 'hi' ? 'सुरक्षा व पासवर्ड' : 'Security & Password'}
                </button>
                <button
                  type="button"
                  onClick={() => setAccountTab('delete')}
                  className={`pb-2 px-3 border-b-2 transition-all cursor-pointer ${
                    accountTab === 'delete'
                      ? 'border-red-600 text-red-600'
                      : 'border-transparent text-[#6E5E4F] hover:text-red-600'
                  }`}
                >
                  ⚠️ {lang === 'hi' ? 'खाता हटाएं' : 'Delete Account'}
                </button>
              </div>

              {/* Tab 1: Profile & Delivery Address Editing */}
              {accountTab === 'profile' && (
                <form onSubmit={handleSaveProfile} className="p-4 rounded-xl bg-white border border-[#E2D6C3] space-y-4">
                  <div className="flex items-center justify-between border-b border-[#EFE6D8] pb-2">
                    <h3 className="font-bold text-xs text-[#241E19] uppercase tracking-wider">
                      {lang === 'hi' ? 'व्यक्तिगत जानकारी व डिलीवरी विवरण' : 'Personal Information & Delivery Details'}
                    </h3>
                    <span className="text-[11px] text-[#6E5E4F]">
                      {lang === 'hi' ? 'ईमेल पता अपरिवर्तनीय है' : 'Email address is immutable'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block font-bold text-[#241E19] mb-1">
                        {lang === 'hi' ? 'पूरा नाम' : 'Full Name'} *
                      </label>
                      <input
                        type="text"
                        value={profileName}
                        onChange={(e) => setProfileName(e.target.value)}
                        className="w-full px-3 py-2 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                        required
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-[#241E19] mb-1">
                        {lang === 'hi' ? 'ईमेल पता (अपरिवर्तनीय)' : 'Email Address (Read-only)'}
                      </label>
                      <input
                        type="email"
                        value={customerUser.email || ''}
                        disabled
                        className="w-full px-3 py-2 bg-[#EFE6D8] border border-[#D4C3AA] rounded-lg text-xs font-semibold text-[#6E5E4F] cursor-not-allowed"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-[#241E19] mb-1">
                        {lang === 'hi' ? 'प्राथमिक मोबाइल नंबर (10 अंक)' : 'Primary Phone Number'}
                      </label>
                      <div className="flex gap-2">
                        <span className="px-2.5 py-2 bg-[#EFE6D8] border border-[#D4C3AA] rounded-lg text-xs font-bold text-[#5C4938]">
                          +91
                        </span>
                        <input
                          type="tel"
                          maxLength={10}
                          value={profilePhone}
                          onChange={(e) => setProfilePhone(e.target.value.replace(/[^0-9]/g, ''))}
                          placeholder="9876543210"
                          className="w-full px-3 py-2 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block font-bold text-[#241E19] mb-1">
                        {lang === 'hi' ? 'वैकल्पिक संपर्क नंबर' : 'Alternate Phone Number'}
                      </label>
                      <input
                        type="tel"
                        maxLength={10}
                        value={profileAltPhone}
                        onChange={(e) => setProfileAltPhone(e.target.value.replace(/[^0-9]/g, ''))}
                        placeholder="वैकल्पिक नंबर"
                        className="w-full px-3 py-2 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block font-bold text-[#241E19] mb-1">
                        {lang === 'hi' ? 'पूरा डिलीवरी पता (मकान / गली / क्षेत्र)' : 'Full Delivery Address'}
                      </label>
                      <textarea
                        rows={2}
                        value={profileAddress}
                        onChange={(e) => setProfileAddress(e.target.value)}
                        placeholder="जैसे: हाउस नं 12, बशारतपुर, निकट मेडिकल कॉलेज रोड"
                        className="w-full px-3 py-2 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-medium focus:outline-none focus:border-[#8E5327]"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-[#241E19] mb-1">
                        {lang === 'hi' ? 'शहर / जिला' : 'City / District'}
                      </label>
                      <input
                        type="text"
                        value={profileCity}
                        onChange={(e) => setProfileCity(e.target.value)}
                        className="w-full px-3 py-2 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-[#241E19] mb-1">
                        {lang === 'hi' ? 'पिनकोड' : 'Pincode'}
                      </label>
                      <input
                        type="text"
                        maxLength={6}
                        value={profilePincode}
                        onChange={(e) => setProfilePincode(e.target.value.replace(/[^0-9]/g, ''))}
                        className="w-full px-3 py-2 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block font-bold text-[#241E19] mb-1">
                        {lang === 'hi' ? 'नजदीकी लैंडमार्क' : 'Nearest Landmark'}
                      </label>
                      <input
                        type="text"
                        value={profileLandmark}
                        onChange={(e) => setProfileLandmark(e.target.value)}
                        placeholder="जैसे: दुर्गा मंदिर के पास"
                        className="w-full px-3 py-2 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-medium focus:outline-none focus:border-[#8E5327]"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      disabled={isSavingProfile}
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-[#8E5327] hover:bg-[#72421E] text-white text-xs font-bold rounded-lg cursor-pointer transition-colors shadow-xs disabled:opacity-50"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{isSavingProfile ? 'सहेजा जा रहा है...' : lang === 'hi' ? 'विवरण सहेजें' : 'Save Details'}</span>
                    </button>
                  </div>
                </form>
              )}

              {/* Tab 2: Customer Inquiries */}
              {accountTab === 'inquiries' && (
                <div className="space-y-2.5">
                  <div className="text-xs font-bold uppercase tracking-wider text-[#8E5327]">
                    {lang === 'hi' ? '📦 आपके सभी कोटेशन व पूछताछ रिकॉर्ड:' : '📦 Your Quotes & Inquiries:'}
                  </div>
                  {myInquiries.length === 0 ? (
                    <div className="p-6 text-center rounded-xl bg-white border border-[#E2D6C3] text-xs text-[#7A6B5C]">
                      {lang === 'hi'
                        ? 'वर्तमान में आपके खाते से कोई पूछताछ दर्ज नहीं है। आप किसी भी उत्पाद पर "कोटेशन प्राप्त करें" चुन सकते हैं।'
                        : 'No inquiries recorded for this account yet. Click "Get Instant Quote" on any product to send one.'}
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {myInquiries.map((inq) => (
                        <div
                          key={inq.id}
                          className="p-3.5 rounded-xl bg-white border border-[#E5D7C3] flex items-center justify-between gap-3 text-xs shadow-2xs"
                        >
                          <div>
                            <div className="font-bold text-[#241E19] text-sm">{inq.productTitle}</div>
                            <div className="text-[#6E5E4F] mt-0.5">
                              {inq.formattedDate} · {inq.preferredWood || 'Standard Wood'} · {inq.city}
                            </div>
                          </div>
                          <span className={`px-2.5 py-1 rounded-full font-bold text-[11px] inline-flex items-center gap-1 ${
                            inq.status === 'resolved'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}>
                            {inq.status === 'resolved' ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                            ) : (
                              <Clock className="w-3.5 h-3.5 text-amber-700" />
                            )}
                            <span>{inq.status.toUpperCase()}</span>
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Tab 3: Security & Password */}
              {accountTab === 'security' && (
                <div className="space-y-4">
                  {/* Account Metadata Overview */}
                  <div className="p-4 rounded-xl bg-white border border-[#E2D6C3] text-xs space-y-2">
                    <h3 className="font-bold text-[#241E19] flex items-center gap-1.5 border-b border-[#EFE6D8] pb-2">
                      <ShieldCheck className="w-4 h-4 text-[#8E5327]" />
                      <span>{lang === 'hi' ? 'खाता सुरक्षा स्थिति' : 'Account Security Status'}</span>
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-[#6E5E4F]">
                      <div>
                        <strong>Supabase Auth UID:</strong> <span className="font-mono text-[10px] break-all">{customerUser.supabaseUserId || customerUser.id}</span>
                      </div>
                      <div>
                        <strong>{lang === 'hi' ? 'साइन-इन विधि:' : 'Sign-in Method:'}</strong> {customerUser.loginProvider.toUpperCase()}
                      </div>
                      <div>
                        <strong>{lang === 'hi' ? 'पासवर्ड सक्रिय:' : 'Password Set:'}</strong> {customerUser.hasPassword ? 'हां (Yes)' : 'नहीं (No - OTP / OAuth)'}
                      </div>
                      <div>
                        <strong>{lang === 'hi' ? 'पंजीकरण तिथि:' : 'Registered At:'}</strong> {customerUser.createdAt ? new Date(customerUser.createdAt).toLocaleDateString() : 'Active'}
                      </div>
                    </div>
                  </div>

                  {/* Change / Set Password Form */}
                  <form onSubmit={handleChangePassword} className="p-4 rounded-xl bg-white border border-[#E2D6C3] space-y-3.5 text-xs">
                    <h3 className="font-bold text-[#241E19] flex items-center gap-1.5">
                      <Lock className="w-4 h-4 text-[#8E5327]" />
                      <span>
                        {customerUser.hasPassword
                          ? lang === 'hi' ? 'पासवर्ड बदलें (Change Password)' : 'Change Password'
                          : lang === 'hi' ? 'पासवर्ड सेट करें (Set New Password)' : 'Set Password'}
                      </span>
                    </h3>

                    {customerUser.hasPassword && (
                      <div>
                        <label className="block font-bold text-[#241E19] mb-1">
                          {lang === 'hi' ? 'वर्तमान पासवर्ड' : 'Current Password'} *
                        </label>
                        <div className="relative">
                          <input
                            type={showChangeCurrent ? 'text' : 'password'}
                            value={changeCurrentPassword}
                            onChange={(e) => setChangeCurrentPassword(e.target.value)}
                            className="w-full px-3 py-2 pr-10 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                            required
                          />
                          <button
                            type="button"
                            onClick={() => setShowChangeCurrent(!showChangeCurrent)}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8E5327] hover:text-[#241E19]"
                          >
                            {showChangeCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>
                    )}

                    <div>
                      <label className="block font-bold text-[#241E19] mb-1">
                        {lang === 'hi' ? 'नया पासवर्ड (कम से कम 6 अक्षर)' : 'New Password (min 6 characters)'} *
                      </label>
                      <div className="relative">
                        <input
                          type={showChangeNew ? 'text' : 'password'}
                          value={changeNewPassword}
                          onChange={(e) => setChangeNewPassword(e.target.value)}
                          className="w-full px-3 py-2 pr-10 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                          required
                          minLength={6}
                        />
                        <button
                          type="button"
                          onClick={() => setShowChangeNew(!showChangeNew)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8E5327] hover:text-[#241E19]"
                        >
                          {showChangeNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block font-bold text-[#241E19] mb-1">
                        {lang === 'hi' ? 'नए पासवर्ड की पुष्टि करें' : 'Confirm New Password'} *
                      </label>
                      <div className="relative">
                        <input
                          type={showChangeConfirm ? 'text' : 'password'}
                          value={changeConfirmPassword}
                          onChange={(e) => setChangeConfirmPassword(e.target.value)}
                          className="w-full px-3 py-2 pr-10 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                          required
                          minLength={6}
                        />
                        <button
                          type="button"
                          onClick={() => setShowChangeConfirm(!showChangeConfirm)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8E5327] hover:text-[#241E19]"
                        >
                          {showChangeConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <div className="flex justify-end pt-2">
                      <button
                        type="submit"
                        disabled={isChangingPassword}
                        className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#8E5327] hover:bg-[#72421E] text-white text-xs font-bold rounded-lg cursor-pointer transition-colors disabled:opacity-50"
                      >
                        <Lock className="w-3.5 h-3.5" />
                        <span>{isChangingPassword ? 'अपडेट हो रहा है...' : lang === 'hi' ? 'पासवर्ड अपडेट करें' : 'Update Password'}</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Tab 4: Delete Account (Real and Secure) */}
              {accountTab === 'delete' && (
                <form onSubmit={handleDeleteAccount} className="p-4 rounded-xl bg-red-50/60 border border-red-300 space-y-4 text-xs">
                  <div className="flex items-start gap-2.5">
                    <ShieldAlert className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <h3 className="font-bold text-red-900 text-sm">
                        {lang === 'hi' ? 'स्थायी ग्राहक खाता विलोपन (Delete Customer Account)' : 'Permanently Delete Customer Account'}
                      </h3>
                      <p className="text-red-800 text-[11px] leading-relaxed">
                        {lang === 'hi'
                          ? 'चेतावनी: खाता हटाने पर आपकी व्यक्तिगत प्रोफाइल एवं Supabase क्रेडेंशियल्स पूरी तरह हटा दिए जाएंगे। आपकी पूर्व पूछताछ व ऑर्डर रिकॉर्ड को व्यावसायिक व टैक्स ऑडिट के लिए सुरक्षित रखते हुए व्यक्तिगत संपर्क विवरण पूरी तरह अनामित (anonymized) कर दिया जाएगा।'
                          : 'Warning: Deleting your account will permanently remove your login credentials and personal profile. Historical inquiry and quote records are anonymized to protect your personal privacy while preserving audit records.'}
                      </p>
                    </div>
                  </div>

                  {customerUser.hasPassword && (
                    <div>
                      <label className="block font-bold text-red-900 mb-1">
                        {lang === 'hi' ? 'सुरक्षा हेतु वर्तमान पासवर्ड दर्ज करें' : 'Enter Current Password for Re-authentication'} *
                      </label>
                      <div className="relative">
                        <input
                          type={showDeletePassword ? 'text' : 'password'}
                          value={deletePassword}
                          onChange={(e) => setDeletePassword(e.target.value)}
                          className="w-full px-3 py-2 pr-10 bg-white border border-red-300 rounded-lg text-xs font-semibold focus:outline-none focus:border-red-600"
                          placeholder="पासवर्ड दर्ज करें"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowDeletePassword(!showDeletePassword)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-red-700"
                        >
                          {showDeletePassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block font-bold text-red-900 mb-1">
                      {lang === 'hi' ? 'पुष्टि के लिए ठीक "DELETE" टाइप करें' : 'Type "DELETE" exactly to confirm'} *
                    </label>
                    <input
                      type="text"
                      value={deleteConfirmationText}
                      onChange={(e) => setDeleteConfirmationText(e.target.value)}
                      placeholder="DELETE"
                      className="w-full px-3 py-2 bg-white border border-red-300 rounded-lg text-xs font-bold text-red-900 tracking-wider focus:outline-none focus:border-red-600"
                      required
                    />
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => setAccountTab('profile')}
                      className="px-3 py-2 bg-white text-xs font-semibold text-[#6E5E4F] border border-[#D4C3AA] rounded-lg hover:bg-[#FAF6F0]"
                    >
                      {lang === 'hi' ? 'रद्द करें (Cancel)' : 'Cancel'}
                    </button>
                    <button
                      type="submit"
                      disabled={isDeletingAccount || deleteConfirmationText.trim().toUpperCase() !== 'DELETE'}
                      className="inline-flex items-center gap-1.5 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg cursor-pointer transition-colors disabled:opacity-40"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{isDeletingAccount ? 'हटाया जा रहा है...' : lang === 'hi' ? 'स्थायी रूप से हटाएं' : 'Permanently Delete'}</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          ) : (
            /* ================================================================ */
            /* UNAUTHENTICATED CUSTOMER VIEW (Login, Register, OTP, Forgot)     */
            /* ================================================================ */
            <div className="space-y-5">
              {/* Top Navigation Tabs */}
              <div className="flex items-center gap-1.5 bg-[#EFE6D8] p-1 rounded-xl text-xs font-bold">
                {activeMethods.emailPasswordEnabled && (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        setAuthMode('password');
                        setError('');
                      }}
                      className={`flex-1 py-2 px-2 text-center rounded-lg cursor-pointer transition-all ${
                        authMode === 'password'
                          ? 'bg-[#2D2319] text-white shadow-xs'
                          : 'text-[#5C4938] hover:bg-black/5'
                      }`}
                    >
                      🔑 {lang === 'hi' ? 'पासवर्ड लॉगिन' : 'Password Login'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setAuthMode('register');
                        setError('');
                      }}
                      className={`flex-1 py-2 px-2 text-center rounded-lg cursor-pointer transition-all ${
                        authMode === 'register'
                          ? 'bg-[#2D2319] text-white shadow-xs'
                          : 'text-[#5C4938] hover:bg-black/5'
                      }`}
                    >
                      📝 {lang === 'hi' ? 'नया खाता बनाएं' : 'Sign Up'}
                    </button>
                  </>
                )}
                {activeMethods.emailOtpEnabled && (
                  <button
                    type="button"
                    onClick={() => {
                      setAuthMode('otp');
                      setError('');
                    }}
                    className={`flex-1 py-2 px-2 text-center rounded-lg cursor-pointer transition-all ${
                      authMode === 'otp'
                        ? 'bg-[#2D2319] text-white shadow-xs'
                        : 'text-[#5C4938] hover:bg-black/5'
                    }`}
                  >
                    ✉️ {lang === 'hi' ? 'ईमेल OTP' : 'Email OTP'}
                  </button>
                )}
              </div>

              {/* ------------------------------------------------------------ */}
              {/* MODE 1: PASSWORD LOGIN                                       */}
              {/* ------------------------------------------------------------ */}
              {authMode === 'password' && (
                <div className="p-4 rounded-xl bg-white border border-[#E2D6C3] space-y-4 shadow-xs">
                  <div className="border-b border-[#EFE6D8] pb-2">
                    <h3 className="font-bold text-xs text-[#241E19] uppercase tracking-wider">
                      {lang === 'hi' ? 'ग्राहक ईमेल व पासवर्ड द्वारा लॉगिन' : 'Customer Sign In with Email & Password'}
                    </h3>
                  </div>

                  <form onSubmit={handlePasswordLogin} className="space-y-3.5 text-xs">
                    <div>
                      <label className="block font-bold text-[#241E19] mb-1">
                        {lang === 'hi' ? 'ईमेल पता' : 'Email Address'} *
                      </label>
                      <input
                        type="email"
                        value={loginEmail}
                        onChange={(e) => setLoginEmail(e.target.value)}
                        placeholder="yourname@gmail.com"
                        className="w-full px-3 py-2 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                        required
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-bold text-[#241E19]">
                          {lang === 'hi' ? 'पासवर्ड' : 'Password'} *
                        </label>
                        <button
                          type="button"
                          onClick={() => {
                            setAuthMode('forgot');
                            setError('');
                          }}
                          className="text-[11px] font-bold text-[#8E5327] hover:underline cursor-pointer"
                        >
                          {lang === 'hi' ? 'पासवर्ड भूल गए?' : 'Forgot Password?'}
                        </button>
                      </div>
                      <div className="relative">
                        <input
                          type={showLoginPassword ? 'text' : 'password'}
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full px-3 py-2 pr-10 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowLoginPassword(!showLoginPassword)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8E5327] hover:text-[#241E19]"
                        >
                          {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isLoggingIn}
                      className="w-full py-2.5 bg-[#8E5327] hover:bg-[#72421E] text-white font-bold rounded-lg text-xs cursor-pointer transition-colors shadow-xs disabled:opacity-50"
                    >
                      {isLoggingIn ? 'प्रमाणित किया जा रहा है...' : lang === 'hi' ? 'लॉगिन करें' : 'Sign In'}
                    </button>
                  </form>

                  {/* Alternative OAuth Sign-in */}
                  <div className="relative flex py-1 items-center">
                    <div className="flex-grow border-t border-[#E5D7C3]"></div>
                    <span className="flex-shrink mx-3 text-[11px] text-[#7A6B5C] font-semibold">या वैकल्पिक विधि</span>
                    <div className="flex-grow border-t border-[#E5D7C3]"></div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={handleGoogleSignIn}
                      className="flex items-center justify-center gap-2 py-2 px-3 bg-white border border-[#D4C3AA] rounded-lg text-xs font-semibold text-[#241E19] hover:bg-[#FAF6F0] cursor-pointer transition-colors"
                    >
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path
                          fill="#4285F4"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                        />
                      </svg>
                      <span>Google Login</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setAuthMode('otp')}
                      className="flex items-center justify-center gap-1.5 py-2 px-3 bg-white border border-[#D4C3AA] rounded-lg text-xs font-semibold text-[#241E19] hover:bg-[#FAF6F0] cursor-pointer transition-colors"
                    >
                      <Mail className="w-4 h-4 text-[#8E5327]" />
                      <span>Email OTP</span>
                    </button>
                  </div>
                </div>
              )}

              {/* ------------------------------------------------------------ */}
              {/* MODE 2: CUSTOMER REGISTRATION                                */}
              {/* ------------------------------------------------------------ */}
              {authMode === 'register' && (
                <div className="p-4 rounded-xl bg-white border border-[#E2D6C3] space-y-4 shadow-xs">
                  {/* If verification email is pending */}
                  {verificationPendingEmail ? (
                    <div className="p-4 rounded-xl bg-amber-50/80 border border-amber-300 text-xs space-y-3">
                      <div className="flex items-start gap-2">
                        <Mail className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                        <div>
                          <h4 className="font-bold text-amber-900 text-sm">
                            {lang === 'hi' ? 'सत्यापन लिंक भेजा गया' : 'Verification Email Sent'}
                          </h4>
                          <p className="text-amber-800 mt-1 leading-relaxed">
                            {lang === 'hi'
                              ? `हमने सत्यापन लिंक ${verificationPendingEmail} पर भेज दिया है। कृपया अपने इनबॉक्स अथवा स्पैम फ़ोल्डर में जाकर लिंक पर क्लिक करें।`
                              : `We have sent a confirmation link to ${verificationPendingEmail}. Please check your inbox or spam folder and click the link.`}
                          </p>
                        </div>
                      </div>

                      <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t border-amber-200">
                        <button
                          type="button"
                          onClick={handleResendVerification}
                          disabled={resendCooldown > 0 || isResendingVerification}
                          className="px-3 py-1.5 bg-[#8E5327] hover:bg-[#72421E] text-white rounded-lg font-bold text-xs cursor-pointer transition-colors disabled:opacity-50"
                        >
                          {isResendingVerification
                            ? 'भेजा जा रहा है...'
                            : resendCooldown > 0
                            ? `पुनः भेजें (${resendCooldown}s)`
                            : lang === 'hi' ? 'सत्यापन पुनः भेजें' : 'Resend Email'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setVerificationPendingEmail('');
                            setAuthMode('password');
                          }}
                          className="text-xs font-bold text-[#8E5327] hover:underline"
                        >
                          {lang === 'hi' ? 'लॉगिन स्क्रीन पर जाएं' : 'Back to Login'}
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* Registration Form */
                    <form onSubmit={handleRegister} className="space-y-3.5 text-xs">
                      <div className="border-b border-[#EFE6D8] pb-2">
                        <h3 className="font-bold text-xs text-[#241E19] uppercase tracking-wider">
                          {lang === 'hi' ? 'नया ग्राहक खाता बनाएं' : 'Create New Customer Account'}
                        </h3>
                      </div>

                      <div>
                        <label className="block font-bold text-[#241E19] mb-1">
                          {lang === 'hi' ? 'पूरा नाम' : 'Full Name'} *
                        </label>
                        <input
                          type="text"
                          value={regName}
                          onChange={(e) => setRegName(e.target.value)}
                          placeholder="जैसे: राहुल शर्मा"
                          className="w-full px-3 py-2 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                          required
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-[#241E19] mb-1">
                          {lang === 'hi' ? 'ईमेल पता' : 'Email Address'} *
                        </label>
                        <input
                          type="email"
                          value={regEmail}
                          onChange={(e) => setRegEmail(e.target.value)}
                          placeholder="rahul@gmail.com"
                          className="w-full px-3 py-2 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                          required
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-[#241E19] mb-1">
                          {lang === 'hi' ? 'पासवर्ड (कम से कम 6 अक्षर)' : 'Password (min 6 chars)'} *
                        </label>
                        <div className="relative">
                          <input
                            type={showRegPassword ? 'text' : 'password'}
                            value={regPassword}
                            onChange={(e) => setRegPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full px-3 py-2 pr-10 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                            required
                            minLength={6}
                          />
                          <button
                            type="button"
                            onClick={() => setShowRegPassword(!showRegPassword)}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8E5327] hover:text-[#241E19]"
                          >
                            {showRegPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="block font-bold text-[#241E19] mb-1">
                          {lang === 'hi' ? 'पासवर्ड की पुष्टि करें' : 'Confirm Password'} *
                        </label>
                        <div className="relative">
                          <input
                            type={showRegConfirmPassword ? 'text' : 'password'}
                            value={regConfirmPassword}
                            onChange={(e) => setRegConfirmPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full px-3 py-2 pr-10 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                            required
                            minLength={6}
                          />
                          <button
                            type="button"
                            onClick={() => setShowRegConfirmPassword(!showRegConfirmPassword)}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8E5327] hover:text-[#241E19]"
                          >
                            {showRegConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      <div className="flex items-start gap-2 pt-1">
                        <input
                          type="checkbox"
                          id="termsCheckbox"
                          checked={regTermsAccepted}
                          onChange={(e) => setRegTermsAccepted(e.target.checked)}
                          className="mt-0.5 rounded-sm border-[#D4C3AA] text-[#8E5327] focus:ring-[#8E5327]"
                          required
                        />
                        <label htmlFor="termsCheckbox" className="text-[11px] text-[#6E5E4F] leading-tight">
                          {lang === 'hi'
                            ? 'मैं बाबा फ़र्नीचर उद्योग के नियम, सेवा शर्तें और गोपनीयता नीति स्वीकार करता/करती हूँ।'
                            : 'I accept Baba Furniture Udyog Terms of Service & Privacy Policy.'}
                        </label>
                      </div>

                      <button
                        type="submit"
                        disabled={isRegistering}
                        className="w-full py-2.5 bg-[#8E5327] hover:bg-[#72421E] text-white font-bold rounded-lg text-xs cursor-pointer transition-colors shadow-xs disabled:opacity-50"
                      >
                        {isRegistering ? 'खाता बनाया जा रहा है...' : lang === 'hi' ? 'खाता बनाएं (Sign Up)' : 'Create Account'}
                      </button>

                      <div className="text-center text-[11px] text-[#6E5E4F] pt-1">
                        {lang === 'hi' ? 'पहले से खाता है?' : 'Already have an account?'}{' '}
                        <button
                          type="button"
                          onClick={() => setAuthMode('password')}
                          className="font-bold text-[#8E5327] hover:underline"
                        >
                          {lang === 'hi' ? 'लॉगिन करें' : 'Sign In'}
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}

              {/* ------------------------------------------------------------ */}
              {/* MODE 3: EMAIL OTP LOGIN                                      */}
              {/* ------------------------------------------------------------ */}
              {authMode === 'otp' && (
                <div className="p-4 rounded-xl bg-white border border-[#E2D6C3] space-y-4 shadow-xs text-xs">
                  <div className="border-b border-[#EFE6D8] pb-2">
                    <h3 className="font-bold text-xs text-[#241E19] uppercase tracking-wider">
                      {lang === 'hi' ? 'ईमेल OTP द्वारा सुरक्षित लॉगिन' : 'Secure Login via Email OTP'}
                    </h3>
                  </div>

                  {!otpSent ? (
                    <form onSubmit={handleSendEmailOtp} className="space-y-3.5">
                      <div>
                        <label className="block font-bold text-[#241E19] mb-1">
                          {lang === 'hi' ? 'अपना पंजीकृत ईमेल पता दर्ज करें' : 'Enter Registered Email Address'} *
                        </label>
                        <input
                          type="email"
                          value={otpEmail}
                          onChange={(e) => setOtpEmail(e.target.value)}
                          placeholder="yourname@gmail.com"
                          className="w-full px-3 py-2 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                          required
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={isSendingOtp}
                        className="w-full py-2.5 bg-[#8E5327] hover:bg-[#72421E] text-white font-bold rounded-lg text-xs cursor-pointer transition-colors shadow-xs disabled:opacity-50"
                      >
                        {isSendingOtp ? 'OTP भेजा जा रहा है...' : lang === 'hi' ? 'OTP कोड भेजें' : 'Send OTP Code'}
                      </button>
                    </form>
                  ) : (
                    <form onSubmit={handleVerifyEmailOtp} className="space-y-3.5">
                      <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-[11px] text-emerald-800">
                        OTP {otpEmail} पर भेजा गया है।
                      </div>

                      <div>
                        <label className="block font-bold text-[#241E19] mb-1">
                          {lang === 'hi' ? '6-अंकों का OTP कोड दर्ज करें' : 'Enter 6-Digit OTP Code'} *
                        </label>
                        <input
                          type="text"
                          maxLength={6}
                          value={otpCode}
                          onChange={(e) => setOtpCode(e.target.value.replace(/[^0-9]/g, ''))}
                          placeholder="••••••"
                          className="w-full px-3 py-2 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-center tracking-widest text-base font-bold focus:outline-none focus:border-[#8E5327]"
                          required
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={isVerifyingOtp}
                        className="w-full py-2.5 bg-[#8E5327] hover:bg-[#72421E] text-white font-bold rounded-lg text-xs cursor-pointer transition-colors shadow-xs disabled:opacity-50"
                      >
                        {isVerifyingOtp ? 'सत्यापित किया जा रहा है...' : lang === 'hi' ? 'सत्यापित करें व लॉगिन करें' : 'Verify & Sign In'}
                      </button>

                      <div className="flex items-center justify-between pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            setOtpSent(false);
                            setOtpCode('');
                          }}
                          className="text-[11px] text-[#6E5E4F] hover:underline"
                        >
                          {lang === 'hi' ? 'ईमेल बदलें' : 'Change Email'}
                        </button>

                        <button
                          type="button"
                          onClick={handleSendEmailOtp}
                          disabled={otpCooldown > 0 || isSendingOtp}
                          className="text-[11px] font-bold text-[#8E5327] hover:underline disabled:opacity-50"
                        >
                          {otpCooldown > 0 ? `पुनः OTP भेजें (${otpCooldown}s)` : lang === 'hi' ? 'पुनः OTP भेजें' : 'Resend OTP'}
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}

              {/* ------------------------------------------------------------ */}
              {/* MODE 4: FORGOT PASSWORD                                      */}
              {/* ------------------------------------------------------------ */}
              {authMode === 'forgot' && (
                <div className="p-4 rounded-xl bg-white border border-[#E2D6C3] space-y-4 shadow-xs text-xs">
                  <div className="border-b border-[#EFE6D8] pb-2">
                    <h3 className="font-bold text-xs text-[#241E19] uppercase tracking-wider">
                      {lang === 'hi' ? 'पासवर्ड रीसेट लिंक प्राप्त करें' : 'Reset Your Password'}
                    </h3>
                  </div>

                  <form onSubmit={handleForgotPassword} className="space-y-3.5">
                    <div>
                      <label className="block font-bold text-[#241E19] mb-1">
                        {lang === 'hi' ? 'पंजीकृत ईमेल पता' : 'Registered Email Address'} *
                      </label>
                      <input
                        type="email"
                        value={forgotEmail}
                        onChange={(e) => setForgotEmail(e.target.value)}
                        placeholder="yourname@gmail.com"
                        className="w-full px-3 py-2 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                        required
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isSendingForgot || forgotCooldown > 0}
                      className="w-full py-2.5 bg-[#8E5327] hover:bg-[#72421E] text-white font-bold rounded-lg text-xs cursor-pointer transition-colors shadow-xs disabled:opacity-50"
                    >
                      {isSendingForgot
                        ? 'लिंक भेजा जा रहा है...'
                        : forgotCooldown > 0
                        ? `पुनः भेजें (${forgotCooldown}s)`
                        : lang === 'hi' ? 'रीसेट लिंक भेजें' : 'Send Reset Link'}
                    </button>

                    <div className="text-center pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          setAuthMode('password');
                          setError('');
                        }}
                        className="text-[11px] font-bold text-[#8E5327] hover:underline"
                      >
                        {lang === 'hi' ? '← पासवर्ड लॉगिन स्क्रीन पर लौटें' : '← Back to Sign In'}
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* ------------------------------------------------------------ */}
              {/* MODE 5: RESET PASSWORD SCREEN                                */}
              {/* ------------------------------------------------------------ */}
              {authMode === 'reset-password' && (
                <div className="p-4 rounded-xl bg-white border border-[#E2D6C3] space-y-4 shadow-xs text-xs">
                  <div className="border-b border-[#EFE6D8] pb-2">
                    <h3 className="font-bold text-xs text-[#241E19] uppercase tracking-wider">
                      {lang === 'hi' ? 'नया पासवर्ड निर्धारित करें' : 'Set New Password'}
                    </h3>
                  </div>

                  {resetCompleted ? (
                    <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-900 space-y-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                        <div>
                          <h4 className="font-bold text-sm">पासवर्ड सफलतापूर्वक बदल दिया गया!</h4>
                          <p className="text-[11px] mt-1">
                            आप अब अपने नए पासवर्ड के साथ सुरक्षित लॉगिन कर सकते हैं।
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          setResetCompleted(false);
                          setAuthMode('password');
                        }}
                        className="w-full py-2 bg-[#8E5327] hover:bg-[#72421E] text-white font-bold rounded-lg text-xs cursor-pointer"
                      >
                        {lang === 'hi' ? 'लॉगिन करें' : 'Sign In Now'}
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handleResetPassword} className="space-y-3.5">
                      <div>
                        <label className="block font-bold text-[#241E19] mb-1">
                          {lang === 'hi' ? 'नया पासवर्ड (कम से कम 6 अक्षर)' : 'New Password (min 6 chars)'} *
                        </label>
                        <div className="relative">
                          <input
                            type={showResetNewPassword ? 'text' : 'password'}
                            value={resetNewPassword}
                            onChange={(e) => setResetNewPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full px-3 py-2 pr-10 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                            required
                            minLength={6}
                          />
                          <button
                            type="button"
                            onClick={() => setShowResetNewPassword(!showResetNewPassword)}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8E5327] hover:text-[#241E19]"
                          >
                            {showResetNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="block font-bold text-[#241E19] mb-1">
                          {lang === 'hi' ? 'नए पासवर्ड की पुष्टि करें' : 'Confirm New Password'} *
                        </label>
                        <div className="relative">
                          <input
                            type={showResetConfirmPassword ? 'text' : 'password'}
                            value={resetConfirmPassword}
                            onChange={(e) => setResetConfirmPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full px-3 py-2 pr-10 bg-[#FAF6F0] border border-[#D4C3AA] rounded-lg text-xs font-semibold focus:outline-none focus:border-[#8E5327]"
                            required
                            minLength={6}
                          />
                          <button
                            type="button"
                            onClick={() => setShowResetConfirmPassword(!showResetConfirmPassword)}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8E5327] hover:text-[#241E19]"
                          >
                            {showResetConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={isResettingPassword}
                        className="w-full py-2.5 bg-[#8E5327] hover:bg-[#72421E] text-white font-bold rounded-lg text-xs cursor-pointer transition-colors shadow-xs disabled:opacity-50"
                      >
                        {isResettingPassword ? 'पासवर्ड अपडेट हो रहा है...' : lang === 'hi' ? 'पासवर्ड अपडेट करें' : 'Update Password'}
                      </button>

                      <div className="text-center pt-1">
                        <button
                          type="button"
                          onClick={() => setAuthMode('password')}
                          className="text-[11px] font-bold text-[#8E5327] hover:underline"
                        >
                          {lang === 'hi' ? 'लॉगिन स्क्रीन पर लौटें' : 'Back to Login'}
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-[#EFE6D8] border-t border-[#D4C3AA] flex flex-wrap items-center justify-between text-[11px] text-[#6E5E4F]">
          <div className="flex items-center gap-1.5 font-medium">
            <Building className="w-3.5 h-3.5 text-[#8E5327]" />
            <span>बाबा फ़र्नीचर उद्योग · बशारतपुर, गोरखपुर</span>
          </div>
          <div className="text-[10px] text-[#8E5327] font-semibold">
            Real Supabase Authentication · Enterprise Grade Security
          </div>
        </div>
      </div>
    </div>
  );
};