import React, { useState } from 'react';
import { Product, ShowroomConfig } from '../types/furniture';
import { shareProductDetails, downloadImageFile } from '../utils/shareAndDownload';
import {
  MessageCircle,
  FileText,
  Ruler,
  ShieldCheck,
  Eye,
  Share2,
  Download,
  Check,
  ShoppingCart,
} from 'lucide-react';

interface ProductCardProps {
  product: Product;
  config: ShowroomConfig;
  lang: 'hi' | 'en';
  onViewDetails: (product: Product) => void;
  onRequestQuote: (product: Product) => void;
  onOpenLiveChat?: (product?: Product) => void;
  onAddToCart?: (product: Product) => void;
  onShareProduct?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  config,
  lang,
  onViewDetails,
  onRequestQuote,
  onOpenLiveChat,
  onAddToCart,
  onShareProduct,
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);

  const showPrice =
    config.showPricesOnWebsite !== false &&
    !product.hidePrice &&
    typeof product.price === 'number' &&
    product.price > 0;

  const discountPct =
    showPrice && product.mrp && product.mrp > (product.price || 0)
      ? Math.round(((product.mrp - (product.price || 0)) / product.mrp) * 100)
      : 0;

  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onShareProduct) {
      onShareProduct(product);
      return;
    }
    await shareProductDetails(product, config, lang);
    setShareSuccess(true);
    setTimeout(() => setShareSuccess(false), 2500);
  };

  const handleDownload = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const filename = `${config.businessName}_${product.sku}_${product.title}`;
    await downloadImageFile(product.imageUrl, filename);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 2500);
  };

  return (
    <article className="group bg-white rounded-xl border border-[#E0D5C3] shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col overflow-hidden relative">
      <div
        onClick={() => onViewDetails(product)}
        className="relative aspect-[4/3] bg-[#F2ECE1] overflow-hidden cursor-pointer"
      >
        <img
          src={product.imageUrl}
          alt={lang === 'hi' ? product.titleHi : product.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
          referrerPolicy="no-referrer"
        />

        <div className="absolute top-3 left-3 flex flex-col gap-1">
          <span className="bg-[#2D2319]/85 backdrop-blur-xs text-white text-[11px] font-medium px-2.5 py-1 rounded">
            {lang === 'hi' ? product.categoryLabelHi : product.categoryLabel}
          </span>
          {discountPct > 0 && (
            <span className="bg-emerald-700 text-white text-[10px] font-bold px-2 py-0.5 rounded w-fit">
              {discountPct}% OFF
            </span>
          )}
        </div>

        <div className="absolute top-3 right-3 flex items-center gap-1.5">
          <span className="bg-white/90 text-[#4A3E33] text-[10px] font-mono tabular-nums px-2 py-0.5 rounded shadow-xs">
            {product.sku}
          </span>
          <button
            onClick={handleShare}
            className="p-1.5 bg-white/90 hover:bg-white text-[#2D2319] hover:text-[#8E5327] rounded-full shadow-sm transition-all cursor-pointer"
            title={lang === 'hi' ? 'प्रोडक्ट और वेबसाइट विवरण शेयर करें' : 'Share Product & Website Details'}
          >
            {shareSuccess ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={handleDownload}
            className="p-1.5 bg-white/90 hover:bg-white text-[#2D2319] hover:text-[#8E5327] rounded-full shadow-sm transition-all cursor-pointer"
            title={lang === 'hi' ? 'फोटो डाउनलोड करें' : 'Download Photo'}
          >
            {downloadSuccess ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Download className="w-3.5 h-3.5" />}
          </button>
        </div>

        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/95 text-[#2D2319] text-xs font-semibold shadow-md">
            <Eye className="w-3.5 h-3.5 text-[#8E5327]" />
            <span>{lang === 'hi' ? 'पूरा विवरण देखें' : 'View Details'}</span>
          </span>
        </div>
      </div>

      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-3">
        <div className="space-y-1.5">
          <div className="text-xs text-[#8E5327] font-medium flex items-center flex-wrap gap-1.5">
            <span>{product.woodType}</span>
            <span aria-hidden="true">·</span>
            <span className="flex items-center gap-1 text-[#5A4D40]">
              <Ruler className="w-3 h-3" />
              <span>{product.dimensions}</span>
            </span>
          </div>

          <h3
            onClick={() => onViewDetails(product)}
            className="font-display text-base sm:text-lg font-bold text-[#2D2319] group-hover:text-[#8E5327] transition-colors cursor-pointer line-clamp-1"
          >
            {lang === 'hi' ? product.titleHi : product.title}
          </h3>

          <p className="text-xs text-[#6A5A4A] line-clamp-2 leading-relaxed">
            {lang === 'hi' ? product.descriptionHi : product.description}
          </p>
        </div>

        {/* Dynamic Price Box (Controlled by Owner 1-Click Price Show/Hide Toggle) */}
        <div className="pt-2 border-t border-[#F0E6D8] flex items-center justify-between">
          {showPrice ? (
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-base sm:text-lg font-bold text-[#2D2319]">
                  ₹{Number(product.price).toLocaleString('en-IN')}
                </span>
                {product.mrp && product.mrp > (product.price || 0) && (
                  <span className="text-xs text-stone-400 line-through">
                    ₹{Number(product.mrp).toLocaleString('en-IN')}
                  </span>
                )}
              </div>
              <div className="text-[10px] text-emerald-700 font-medium">
                {lang === 'hi' ? 'शोरूम डायरेक्ट रेट' : 'Factory Direct Price'}
              </div>
            </div>
          ) : (
            <div className="text-xs font-semibold text-[#8E5327]">
              {lang === 'hi' ? '📞 कीमत के लिए पूछताछ करें' : '📞 Price on Request'}
            </div>
          )}

          <span className="flex items-center gap-1 text-emerald-800 text-xs font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
            <span>{product.warrantyYears} {lang === 'hi' ? 'साल गारंटी' : 'Yr Warranty'}</span>
          </span>
        </div>

        <div className="pt-1 grid grid-cols-2 gap-2">
          {onAddToCart ? (
            <button
              onClick={() => onAddToCart(product)}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-[#2D2319] hover:bg-black rounded-md transition-colors cursor-pointer"
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              <span className="truncate">{lang === 'hi' ? 'कार्ट में जोड़ें' : 'Add to Cart'}</span>
            </button>
          ) : (
            <button
              onClick={() => (onOpenLiveChat ? onOpenLiveChat(product) : onViewDetails(product))}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-md transition-colors cursor-pointer"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-white" />
              <span className="truncate">{lang === 'hi' ? 'लाइव चैट' : 'Live Chat'}</span>
            </button>
          )}

          <button
            onClick={() => onRequestQuote(product)}
            className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#2D2319] bg-[#EFE6D8] hover:bg-[#E3D6C1] border border-[#C5B396] rounded-md transition-colors cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5 text-[#8E5327]" />
            <span className="truncate">{lang === 'hi' ? 'कोटेशन मांगें' : 'Get Quote'}</span>
          </button>
        </div>

        <button
          onClick={handleShare}
          className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-[11px] font-semibold text-[#8E5327] bg-[#FAF5EC] hover:bg-[#F3E9D8] border border-[#E5D7C3] rounded-md transition-colors cursor-pointer"
        >
          <Share2 className="w-3 h-3" />
          <span>
            {lang === 'hi'
              ? 'प्रोडक्ट व वेबसाइट विवरण शेयर करें'
              : 'Share Product & Showroom Details'}
          </span>
        </button>
      </div>
    </article>
  );
};
export default ProductCard;
