import React, { useState } from 'react';
import { CustomerUser, ShowroomConfig } from '../types/furniture';
import { Phone, MessageCircle, ShieldCheck, Lock, UserCheck, Globe, Share2, Menu, X } from 'lucide-react';
import { shareCatalogLink } from '../utils/shareAndDownload';

interface HeaderProps {
  config: ShowroomConfig;
  lang: 'hi' | 'en';
  onToggleLang: () => void;
  customerUser?: CustomerUser | null;
  onOpenCustomerAuth?: () => void;
  onOpenAdmin: () => void;
  onOpenCustomOrder: () => void;
  onOpenCatalog: () => void;
  onOpenLiveChart: () => void;
  onOpenLiveChat: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  config,
  lang,
  onToggleLang,
  customerUser,
  onOpenCustomerAuth,
  onOpenAdmin,
  onOpenCustomOrder,
  onOpenCatalog,
  onOpenLiveChart,
  onOpenLiveChat,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#FBF9F5]/95 backdrop-blur-md border-b border-[#E8DEC8] no-print">
      {/* Top Quiet Announcement Strip */}
      <div className="bg-[#2D2319] text-[#E7D6C4] px-4 py-1.5 text-xs">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 truncate">
            <ShieldCheck className="w-3.5 h-3.5 text-[#C89D66] shrink-0" />
            <span className="truncate">{config.announcement}</span>
          </div>
          <div className="hidden sm:flex items-center gap-6 shrink-0 text-xs">
            <a
              href={`tel:${config.phone.replace(/[^0-9+]/g, '')}`}
              className="flex items-center gap-1.5 hover:text-[#C89D66] transition-colors"
            >
              <Phone className="w-3 h-3 text-[#C89D66]" />
              <span>{config.phone}</span>
            </a>
            <span className="text-stone-500">|</span>
            <button
              onClick={onOpenCatalog}
              className="text-[#E7D6C4] hover:text-[#C89D66] transition-colors cursor-pointer"
            >
              {lang === 'hi' ? 'डिजिटल कैटलॉग' : 'Download Catalog'}
            </button>
          </div>
        </div>
      </div>

      {/* Strict 3-Zone Top Bar Contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark */}
        <a href="#top" className="flex flex-col shrink-0 group">
          <span className="font-display text-xl sm:text-2xl font-bold tracking-tight text-[#2D2319] group-hover:text-[#8E5327] transition-colors whitespace-nowrap">
            {lang === 'hi' ? config.businessNameHi : config.businessName}
          </span>
          <span className="text-[10px] sm:text-xs text-[#8E5327] tracking-wider uppercase font-medium">
            {lang === 'hi' ? 'सॉलिड वुड फर्नीचर निर्माण एवं शोरूम' : 'Solid Wood Craft & Showroom'}
          </span>
        </a>

        {/* Zone 2: Desktop Nav Links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#4A3E33]">
          <a
            href="#collections"
            className="hover:text-[#8E5327] transition-colors whitespace-nowrap shrink-0"
          >
            {lang === 'hi' ? 'फर्नीचर संग्रह' : 'Collections'}
          </a>
          <button
            onClick={onOpenCustomOrder}
            className="hover:text-[#8E5327] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {lang === 'hi' ? 'कस्टम डिज़ाइन' : 'Custom Order'}
          </button>
          <a
            href="#wood-quality"
            className="hover:text-[#8E5327] transition-colors whitespace-nowrap shrink-0"
          >
            {lang === 'hi' ? 'लकड़ी की पहचान' : 'Wood Quality'}
          </a>
          <a
            href="#room-fit"
            className="hover:text-[#8E5327] transition-colors whitespace-nowrap shrink-0"
          >
            {lang === 'hi' ? 'कमरा साइज जांच' : 'Room Fit'}
          </a>
          <button
            onClick={onOpenLiveChart}
            className="hover:text-[#8E5327] transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1 font-semibold text-[#8E5327]"
          >
            <span>📊</span>
            <span>{lang === 'hi' ? 'लाइव चार्ट' : 'Live Chart'}</span>
          </button>
          <a
            href="#showroom-info"
            className="hover:text-[#8E5327] transition-colors whitespace-nowrap shrink-0"
          >
            {lang === 'hi' ? 'हमारा शोरूम' : 'Showroom'}
          </a>
        </nav>

        {/* Zone 3: Primary Action & Controls */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Share Website */}
          <button
            onClick={() => shareCatalogLink(config, lang)}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-[#4A3E33] border border-[#D5C2A5] rounded-md hover:bg-[#F2E8DC] transition-colors cursor-pointer"
            title={lang === 'hi' ? 'दुकान शेयर करें' : 'Share Website'}
          >
            <Share2 className="w-3.5 h-3.5 text-[#8E5327]" />
            <span className="hidden md:inline">{lang === 'hi' ? 'शेयर' : 'Share'}</span>
          </button>

          {/* Language Toggle */}
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-[#4A3E33] border border-[#D5C2A5] rounded-md hover:bg-[#F2E8DC] transition-colors cursor-pointer"
            title="Switch Language / भाषा बदलें"
          >
            <Globe className="w-3.5 h-3.5 text-[#8E5327]" />
            <span>{lang === 'hi' ? 'EN' : 'हिंदी'}</span>
          </button>

          {/* Customer Login & My Orders */}
          {onOpenCustomerAuth && (
            <button
              onClick={onOpenCustomerAuth}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-medium text-[#2D2319] bg-white hover:bg-[#FAF6F0] border border-[#D5C2A5] rounded-md transition-colors cursor-pointer"
              title="Customer Login & My Orders"
            >
              <UserCheck className="w-3.5 h-3.5 text-[#8E5327]" />
              <span className="hidden sm:inline">
                {customerUser
                  ? customerUser.name.split(' ')[0]
                  : lang === 'hi'
                  ? 'ग्राहक लॉगिन'
                  : 'Customer Login'}
              </span>
            </button>
          )}

          {/* Admin Owner Access is hidden from public header for security (Accessible via ?portal=admin, #admin, Ctrl+Shift+A, or 5-click footer copyright) */}

          {/* Primary CTA: Live Chat */}
          <button
            onClick={onOpenLiveChat}
            className="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-1.5 sm:py-2 text-xs sm:text-sm font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-md shadow-sm transition-all whitespace-nowrap shrink-0 cursor-pointer"
            title={lang === 'hi' ? 'लाइव चैट खोलें' : 'Open Live Chat'}
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>{lang === 'hi' ? 'लाइव चैट' : 'Live Chat'}</span>
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            className="lg:hidden p-1.5 text-[#2D2319] border border-[#D5C2A5] rounded-md hover:bg-[#F2E8DC] cursor-pointer"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Collapsible Mobile / Tablet Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#FAF6F0] border-t border-[#E8DEC8] px-4 py-3 space-y-2">
          <div className="grid grid-cols-2 gap-2 text-xs font-semibold text-[#2D2319]">
            <a
              href="#collections"
              onClick={() => setMobileMenuOpen(false)}
              className="p-2 rounded bg-white border border-[#E0D5C3] hover:bg-[#EFE6D8]"
            >
              🛋️ {lang === 'hi' ? 'फर्नीचर संग्रह' : 'Collections'}
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenCustomOrder();
              }}
              className="p-2 rounded bg-white border border-[#E0D5C3] hover:bg-[#EFE6D8] text-left cursor-pointer"
            >
              ✨ {lang === 'hi' ? 'कस्टम डिज़ाइन' : 'Custom Order'}
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenLiveChart();
              }}
              className="p-2 rounded bg-white border border-[#E0D5C3] hover:bg-[#EFE6D8] text-left text-[#8E5327] cursor-pointer"
            >
              📊 {lang === 'hi' ? 'लाइव तुलना चार्ट' : 'Live Specs Chart'}
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenCatalog();
              }}
              className="p-2 rounded bg-white border border-[#E0D5C3] hover:bg-[#EFE6D8] text-left cursor-pointer"
            >
              📖 {lang === 'hi' ? 'PDF कैटलॉग' : 'PDF Catalog'}
            </button>
            <a
              href="#wood-quality"
              onClick={() => setMobileMenuOpen(false)}
              className="p-2 rounded bg-white border border-[#E0D5C3] hover:bg-[#EFE6D8]"
            >
              🪵 {lang === 'hi' ? 'लकड़ी की पहचान' : 'Wood Quality'}
            </a>
            <a
              href="#room-fit"
              onClick={() => setMobileMenuOpen(false)}
              className="p-2 rounded bg-white border border-[#E0D5C3] hover:bg-[#EFE6D8]"
            >
              📐 {lang === 'hi' ? 'कमरा साइज जांच' : 'Room Fit'}
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
