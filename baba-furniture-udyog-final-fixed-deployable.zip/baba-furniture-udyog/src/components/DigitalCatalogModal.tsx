import React, { useState } from 'react';
import { Product, ShowroomConfig } from '../types/furniture';
import { shareCatalogLink } from '../utils/shareAndDownload';
import { X, Download, ShieldCheck, Phone, MapPin, Share2, Check } from 'lucide-react';

interface DigitalCatalogModalProps {
  products: Product[];
  config: ShowroomConfig;
  lang: 'hi' | 'en';
  onClose: () => void;
}

export const DigitalCatalogModal: React.FC<DigitalCatalogModalProps> = ({
  products,
  config,
  lang,
  onClose,
}) => {
  const [shared, setShared] = useState(false);

  const handlePrintOrDownload = () => {
    window.print();
  };

  const handleShareCatalog = async () => {
    await shareCatalogLink(config, lang);
    setShared(true);
    setTimeout(() => setShared(false), 2500);
  };

  return (
    <div className="printable-modal-wrapper fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <div className="printable-modal-box relative w-full max-w-5xl bg-white rounded-2xl border border-[#D5C2A5] shadow-2xl overflow-hidden my-6 max-h-[90vh] flex flex-col">
        {/* Modal Top Action Bar */}
        <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-4 border-b border-[#E8DEC8] bg-[#FAF6F0] shrink-0">
          <div>
            <h3 className="font-display text-lg font-bold text-[#2D2319]">
              {lang === 'hi'
                ? 'बाबा फर्नीचर उद्योग — डिजिटल कैटलॉग'
                : 'Baba Furniture Udyog — Showroom Catalog'}
            </h3>
            <p className="text-xs text-[#6A5A4A]">
              {lang === 'hi'
                ? 'कैटलॉग डाउनलोड करें या व्हाट्सएप पर किसी को शेयर करें'
                : 'Download PDF booklet or share catalog with family'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Share Catalog Button */}
            <button
              onClick={handleShareCatalog}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#2D2319] bg-white hover:bg-[#EFE6D8] border border-[#D5C2A5] rounded-lg transition-colors cursor-pointer"
              title="Share Catalog on WhatsApp"
            >
              {shared ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700">{lang === 'hi' ? 'शेयर हुआ!' : 'Shared!'}</span>
                </>
              ) : (
                <>
                  <Share2 className="w-3.5 h-3.5 text-[#8E5327]" />
                  <span>{lang === 'hi' ? 'कैटलॉग शेयर करें' : 'Share'}</span>
                </>
              )}
            </button>

            {/* Print / Download PDF */}
            <button
              onClick={handlePrintOrDownload}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-lg transition-colors cursor-pointer shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'PDF डाउनलोड / प्रिंट' : 'Download / Print PDF'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-stone-500 hover:text-stone-900 rounded-md transition-colors cursor-pointer ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Catalog Sheet Body */}
        <div className="p-6 sm:p-10 overflow-y-auto print:overflow-visible space-y-8 bg-white print:p-0">
          {/* Catalog Letterhead */}
          <div className="border-b-2 border-[#8E5327] pb-6 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
            <div>
              <div className="text-xs font-semibold text-[#8E5327] uppercase tracking-widest">
                Official Showroom & Workshop Catalog · 2026 Edition
              </div>
              <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#2D2319] pt-1">
                {config.businessName}
              </h1>
              <p className="text-sm text-[#8E5327] font-medium pt-0.5">
                {config.businessNameHi} · {config.taglineHi}
              </p>
            </div>

            <div className="text-xs text-[#5A4D40] space-y-1 text-left md:text-right">
              <div className="flex items-center md:justify-end gap-1.5 font-semibold text-[#2D2319]">
                <Phone className="w-3.5 h-3.5 text-[#8E5327]" />
                <span>{config.phone}</span>
              </div>
              <div className="flex items-center md:justify-end gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#8E5327]" />
                <span>
                  {config.address}, {config.cityState}
                </span>
              </div>
              <div className="text-emerald-800 font-semibold flex items-center md:justify-end gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                <span>100% Solid Seasoned Teak & Sheesham Wood Only</span>
              </div>
            </div>
          </div>

          {/* Catalog Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((item) => (
              <div
                key={item.id}
                className="border border-[#E0D5C3] rounded-xl p-4 bg-[#FAF8F5] space-y-3 print:break-inside-avoid"
              >
                <div className="aspect-[4/3] rounded-lg overflow-hidden bg-white border border-[#E8DEC8]">
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between text-[11px] text-[#8E5327] font-semibold">
                    <span>{item.categoryLabel}</span>
                    <span className="font-mono">{item.sku}</span>
                  </div>
                  <h4 className="font-display font-bold text-sm text-[#2D2319] pt-0.5 line-clamp-1">
                    {lang === 'hi' ? item.titleHi : item.title}
                  </h4>
                  <div className="text-xs text-[#5A4D40] pt-1">
                    <strong>Wood:</strong> {item.woodType}
                  </div>
                  <div className="text-xs text-[#5A4D40]">
                    <strong>Size:</strong> {item.dimensions}
                  </div>
                  <div className="text-xs text-[#5A4D40]">
                    <strong>Finishes:</strong> {item.finishOptions.join(', ')}
                  </div>
                </div>

                <div className="pt-2 border-t border-[#E8DEC8] flex items-center justify-between text-[11px] text-[#6A5A4A]">
                  <span className="font-semibold text-emerald-800">
                    {item.warrantyYears}-Yr Termite Proof
                  </span>
                  <span className="text-[#8E5327] font-medium">Price on Direct Request</span>
                </div>
              </div>
            ))}
          </div>

          {/* Terms & Footer Note */}
          <div className="pt-6 border-t border-[#E8DEC8] text-xs text-[#6A5A4A] space-y-2">
            <p>
              <strong>Note:</strong> Baba Furniture Udyog manufactures all items directly in its
              workshop. Custom sizes, hydraulic storage types, and polish shades can be customized to
              individual client architectural requirements.
            </p>
            <p className="text-center text-stone-400 font-mono text-[10px]">
              Baba Furniture Udyog © 2026 · All Rights Reserved
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
