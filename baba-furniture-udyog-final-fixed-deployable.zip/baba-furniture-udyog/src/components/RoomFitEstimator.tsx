import React, { useState } from 'react';
import { calculateRoomFit } from '../utils/furnitureLogic';
import { Maximize2, CheckCircle2, AlertTriangle, HelpCircle } from 'lucide-react';

import { ShowroomConfig } from '../types/furniture';

interface RoomFitEstimatorProps {
  lang: 'hi' | 'en';
  config?: ShowroomConfig;
}

const FURNITURE_PRESETS = [
  { label: 'King Size Bed (किंग बेड)', lengthFt: 6.5, widthFt: 6.0 },
  { label: 'Queen Size Bed (क्वीन बेड)', lengthFt: 6.5, widthFt: 5.0 },
  { label: '6-Seater Dining Table (6-सीटर डाइनिंग)', lengthFt: 6.0, widthFt: 4.5 },
  { label: '8-Seater Dining Table (8-सीटर डाइनिंग)', lengthFt: 8.0, widthFt: 5.0 },
  { label: 'L-Shape Living Sofa (L-शेप सोफा)', lengthFt: 7.5, widthFt: 6.0 },
  { label: 'Grand Puja Mandir (भव्य मंदिर)', lengthFt: 4.0, widthFt: 2.5 },
  { label: 'Executive Boss Desk (ऑफिस टेबल)', lengthFt: 5.5, widthFt: 3.0 },
];

export const RoomFitEstimator: React.FC<RoomFitEstimatorProps> = ({ lang, config }) => {
  const presetsList = config?.roomPresets && config.roomPresets.length > 0 ? config.roomPresets : FURNITURE_PRESETS;
  const [roomLengthInput, setRoomLengthInput] = useState<string>('14');
  const [roomWidthInput, setRoomWidthInput] = useState<string>('12');
  const [selectedPresetIndex, setSelectedPresetIndex] = useState<number>(0);

  const roomLength = Math.max(4, Math.min(50, Number(roomLengthInput) || 14));
  const roomWidth = Math.max(4, Math.min(50, Number(roomWidthInput) || 12));

  const selectedPreset = presetsList[selectedPresetIndex] || presetsList[0];
  const fitResult = calculateRoomFit(
    roomLength,
    roomWidth,
    selectedPreset.lengthFt,
    selectedPreset.widthFt
  );

  // Clamp percentage between 18% and 96% so it always fits inside the room box cleanly
  const widthPct = Math.min(96, Math.max(18, (selectedPreset.lengthFt / roomLength) * 100));
  const heightPct = Math.min(96, Math.max(18, (selectedPreset.widthFt / roomWidth) * 100));

  return (
    <section className="bg-white py-12 border-b border-[#E8DEC8] no-print" id="room-fit">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#8E5327] bg-[#F1E7D6] px-2.5 py-0.5 rounded">
            <Maximize2 className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'कमरा साइज एवं फिटिंग कैलकुलेटर' : 'Smart Room Clearance Estimator'}</span>
          </div>
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#2D2319]">
            {lang === 'hi'
              ? 'जांचें कि क्या यह फर्नीचर आपके कमरे में सही से फिट होगा'
              : 'Will it Fit? Check Clearance Before You Order'}
          </h2>
          <p className="text-xs sm:text-sm text-[#6A5A4A] leading-relaxed">
            {lang === 'hi'
              ? 'अपने कमरे की लंबाई व चौड़ाई दर्ज करें। हमारा सिस्टम आपको बताएगा कि साइड टेबल, दरवाजे और आने-जाने के लिए कितनी जगह बचेगी।'
              : 'Enter your room dimensions to see 2D spatial footprint and comfortable walking clearances.'}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Controls */}
          <div className="lg:col-span-5 bg-[#FAF7F2] p-6 rounded-2xl border border-[#E0D5C3] space-y-5">
            <div>
              <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                {lang === 'hi' ? 'फर्नीचर का चयन करें' : 'Select Furniture Model'}
              </label>
              <select
                value={selectedPresetIndex}
                onChange={(e) => setSelectedPresetIndex(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
              >
                {presetsList.map((preset, idx) => (
                  <option key={idx} value={idx}>
                    {preset.label} — {preset.lengthFt} x {preset.widthFt} ft
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                  {lang === 'hi' ? 'कमरे की लंबाई (Room Length in Ft)' : 'Room Length (ft)'}
                </label>
                <input
                  type="number"
                  min="6"
                  max="40"
                  step="0.5"
                  value={roomLengthInput}
                  onChange={(e) => setRoomLengthInput(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                  {lang === 'hi' ? 'कमरे की चौड़ाई (Room Width in Ft)' : 'Room Width (ft)'}
                </label>
                <input
                  type="number"
                  min="6"
                  max="40"
                  step="0.5"
                  value={roomWidthInput}
                  onChange={(e) => setRoomWidthInput(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
                />
              </div>
            </div>

            {/* Fit Feedback Card */}
            <div
              className={`p-4 rounded-xl border ${
                fitResult.fits
                  ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
                  : 'bg-amber-50/80 border-amber-200 text-amber-950'
              }`}
            >
              <div className="flex items-center gap-2 font-bold text-sm">
                {fitResult.fits ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" />
                ) : (
                  <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0" />
                )}
                <span>
                  {fitResult.fits
                    ? lang === 'hi'
                      ? 'शानदार फिट! कमरा खुला और हवादार रहेगा'
                      : 'Comfortable Fit Confirmed!'
                    : lang === 'hi'
                    ? 'थोड़ा टाइट हो सकता है'
                    : 'Caution: Snug or Narrow Clearance'}
                </span>
              </div>

              <p className="text-xs pt-1.5 leading-relaxed text-[#4A3E33]">
                {lang === 'hi' ? fitResult.recommendationHi : fitResult.recommendation}
              </p>

              <div className="grid grid-cols-3 gap-2 pt-3 text-center border-t border-black/5 mt-3">
                <div>
                  <div className="text-[10px] text-stone-500 uppercase">
                    {lang === 'hi' ? 'लंबाई में बची जगह' : 'Length Space'}
                  </div>
                  <div className="font-mono text-xs font-bold">{fitResult.clearanceLengthFt} ft</div>
                </div>
                <div>
                  <div className="text-[10px] text-stone-500 uppercase">
                    {lang === 'hi' ? 'चौड़ाई में बची जगह' : 'Width Space'}
                  </div>
                  <div className="font-mono text-xs font-bold">{fitResult.clearanceWidthFt} ft</div>
                </div>
                <div>
                  <div className="text-[10px] text-stone-500 uppercase">
                    {lang === 'hi' ? 'कमरा घेराव' : 'Room Coverage'}
                  </div>
                  <div className="font-mono text-xs font-bold">{fitResult.areaUtilizationPct}%</div>
                </div>
              </div>
            </div>

            <div className="text-xs text-[#6A5A4A] flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-[#8E5327] shrink-0" />
              <span>
                {lang === 'hi'
                  ? 'अगर आपके कमरे का साइज अलग है, तो हम आपकी नाप के हिसाब से सटीक फर्नीचर बना देंगे।'
                  : 'Need a custom size? Our carpenters can build to your exact wall dimensions.'}
              </span>
            </div>
          </div>

          {/* Interactive 2D Visualizer Canvas */}
          <div className="lg:col-span-7 bg-[#FAF7F2] p-6 rounded-2xl border border-[#E0D5C3] flex flex-col items-center justify-center min-h-[360px]">
            <div className="text-xs font-semibold text-[#8E5327] uppercase tracking-wider mb-3">
              {lang === 'hi' ? '2D फ्लोर प्लान प्रीव्यू (अनुपातिक नक्शा)' : '2D Proportional Room Blueprint'}
            </div>

            {/* Room Boundary */}
            <div
              className="relative bg-white border-2 border-dashed border-[#8E5327] rounded-lg shadow-inner flex items-center justify-center transition-all duration-300 overflow-hidden"
              style={{
                width: `${Math.min(320, Math.max(180, (roomLength / 20) * 260))}px`,
                height: `${Math.min(260, Math.max(150, (roomWidth / 20) * 220))}px`,
              }}
            >
              {/* Labels for room boundary */}
              <span className="absolute top-1.5 left-1/2 -translate-x-1/2 text-[10px] font-mono text-stone-500 bg-white/80 px-1 rounded">
                {roomLength} ft
              </span>
              <span className="absolute left-1.5 top-1/2 -translate-y-1/2 text-[10px] font-mono text-stone-500 bg-white/80 px-1 rounded">
                {roomWidth} ft
              </span>

              {/* Furniture Footprint */}
              <div
                className="bg-[#C89D66]/80 border-2 border-[#8E5327] rounded flex flex-col items-center justify-center text-center p-1 text-[#241E19] shadow-sm transition-all duration-300"
                style={{
                  width: `${widthPct}%`,
                  height: `${heightPct}%`,
                }}
              >
                <span className="text-[10px] font-bold truncate max-w-full">
                  {selectedPreset.label.split('(')[0]}
                </span>
                <span className="text-[9px] font-mono">
                  {selectedPreset.lengthFt} x {selectedPreset.widthFt} ft
                </span>
              </div>

              {/* Walking aisle hint */}
              <div className="absolute bottom-1.5 right-2 text-[9px] text-stone-400 font-mono">
                {lang === 'hi' ? 'पैदल रास्ता' : 'Walk Aisle'}
              </div>
            </div>

            <p className="text-[11px] text-stone-500 pt-6 text-center">
              {lang === 'hi'
                ? 'नक्शे में भूरा डिब्बा फर्नीचर का स्थान दर्शाता है। चारों तरफ कम से कम 2.5 फीट खाली जगह जरूरी होती है।'
                : 'The brown zone represents furniture placement. At least 2.5 ft perimeter clearance ensures easy door and drawer opening.'}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
