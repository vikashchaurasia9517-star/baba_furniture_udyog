import React, { useState } from 'react';
import { CustomerUser, ShowroomConfig } from '../types/furniture';
import { Phone, MessageCircle, MapPin, Clock, ShieldCheck, FileText, X } from 'lucide-react';

interface ShowroomFooterProps {
  config: ShowroomConfig;
  lang: 'hi' | 'en';
  customerUser?: CustomerUser | null;
  onOpenCustomerAuth?: () => void;
  onOpenAdmin: () => void;
  onOpenCustomOrder: () => void;
  onOpenCatalog: () => void;
  onOpenLiveChat?: () => void;
}

export const ShowroomFooter: React.FC<ShowroomFooterProps> = ({
  config,
  lang,
  onOpenAdmin,
  onOpenCustomOrder,
  onOpenCatalog,
  onOpenLiveChat,
}) => {
  const [secretClicks, setSecretClicks] = useState(0);
  const [showTermsModal, setShowTermsModal] = useState(false);

  const handleCopyrightClick = () => {
    const next = secretClicks + 1;
    if (next >= 5) {
      setSecretClicks(0);
      onOpenAdmin();
    } else {
      setSecretClicks(next);
    }
  };

  return (
    <footer className="bg-[#241E19] text-[#D5C2A5] border-t border-[#3B3026] pt-12 pb-24 sm:pb-12" id="showroom-info">
      <div id="direct-contact" className="sr-only">Direct Contact</div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Col 1: Brand & Craftsmanship */}
          <div className="space-y-4">
            <div>
              <span className="font-display text-2xl font-bold text-white tracking-tight">
                {lang === 'hi' ? config.businessNameHi : config.businessName}
              </span>
              <p className="text-xs text-[#C89D66] font-medium pt-0.5">
                {config.businessName} · GST: {config.gstNumber || '09AABCB2026F1Z5'}
              </p>
            </div>
            <p className="text-xs text-[#B3A088] leading-relaxed">
              {lang === 'hi'
                ? 'पिछले 3 दशकों से शुद्ध सागवान (Teak) और शीशम (Sheesham) की सीजन्ड लकड़ी से मजबूत, खूबसूरत और पीढ़ियों तक चलने वाला फर्नीचर तैयार कर रहे हैं।'
                : 'Pioneers in handcrafted solid wood furniture. Direct workshop pricing with 10-year borer and termite resistance warranty.'}
            </p>
            <div className="flex items-center gap-2 text-xs text-[#C89D66]">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>
                {lang === 'hi'
                  ? '10-वर्ष की लिखित दीमक एवं सॉलिड वुड गारंटी'
                  : '10-Year Certified Hardwood Guarantee'}
              </span>
            </div>
          </div>

          {/* Col 2: Showroom Location & Timings */}
          <div className="space-y-3">
            <h4 className="font-display text-sm font-bold text-white tracking-wider uppercase">
              {lang === 'hi' ? 'शोरूम एवं कारखाना पता' : 'Shop & Workshop'}
            </h4>
            <div className="space-y-2 text-xs text-[#B3A088]">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#C89D66] shrink-0 mt-0.5" />
                <span>{config.address}, {config.cityState}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#C89D66] shrink-0" />
                <span>{config.timings}</span>
              </div>
            </div>
          </div>

          {/* Col 3: Direct Contact & In-App Live Chat */}
          <div className="space-y-3">
            <h4 className="font-display text-sm font-bold text-white tracking-wider uppercase">
              {lang === 'hi' ? 'सीधा संपर्क एवं ऑर्डर' : 'Direct Contacts'}
            </h4>
            <div className="space-y-2 text-xs">
              <a
                href={`tel:${config.phone.replace(/[^0-9+]/g, '')}`}
                className="flex items-center gap-2 text-[#E7D6C4] hover:text-[#C89D66] transition-colors"
              >
                <Phone className="w-4 h-4 text-[#C89D66]" />
                <span className="font-mono text-sm">{config.phone}</span>
              </a>
              {onOpenLiveChat && (
                <button
                  onClick={onOpenLiveChat}
                  className="flex items-center gap-2 text-[#E7D6C4] hover:text-[#C89D66] transition-colors cursor-pointer text-left"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-500" />
                  <span>{lang === 'hi' ? 'दुकान मालिक से लाइव चैट करें' : 'In-App Live Chat with Owner'}</span>
                </button>
              )}
              <div className="pt-2">
                <button
                  onClick={onOpenCatalog}
                  className="text-xs text-[#C89D66] hover:underline cursor-pointer"
                >
                  {lang === 'hi' ? 'डिजिटल कैटलॉग डाउनलोड करें' : 'Download Showroom Catalog'}
                </button>
              </div>
            </div>
          </div>

          {/* Col 4: Quick Links & Terms Policy (Admin button hidden from public view) */}
          <div className="space-y-3">
            <h4 className="font-display text-sm font-bold text-white tracking-wider uppercase">
              {lang === 'hi' ? 'महत्वपूर्ण लिंक व नीतियां' : 'Quick Links & Policies'}
            </h4>
            <ul className="space-y-2 text-xs text-[#B3A088]">
              <li>
                <a href="#collections" className="hover:text-white transition-colors">
                  {lang === 'hi' ? 'सभी फर्नीचर कैटलॉग' : 'All Collections'}
                </a>
              </li>
              <li>
                <button
                  onClick={onOpenCustomOrder}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  {lang === 'hi' ? 'कस्टम फर्नीचर (अपना डिज़ाइन भेजें)' : 'Custom Furniture Blueprint'}
                </button>
              </li>
              <li>
                <a href="#wood-quality" className="hover:text-white transition-colors">
                  {lang === 'hi' ? 'सागवान व शीशम की पहचान' : 'Timber Quality Guide'}
                </a>
              </li>
              <li>
                <a href="#room-fit" className="hover:text-white transition-colors">
                  {lang === 'hi' ? 'कमरा नाप कैलकुलेटर' : 'Room Fit Estimator'}
                </a>
              </li>
              <li className="pt-1">
                <button
                  onClick={() => setShowTermsModal(true)}
                  className="inline-flex items-center gap-1.5 text-xs text-[#C89D66] hover:underline cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>{lang === 'hi' ? 'नियम, शर्तें एवं वारंटी नीति' : 'Terms, Warranty & Privacy Policy'}</span>
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright line (5-click secret trigger opens Admin Portal) */}
        <div className="pt-8 border-t border-[#3B3026] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#8A7966]">
          <p
            onClick={handleCopyrightClick}
            className="select-none cursor-default"
            title={lang === 'hi' ? 'बाबा फर्नीचर उद्योग' : 'Baba Furniture Udyog'}
          >
            © 2026 {config.businessName}. {lang === 'hi' ? 'सर्वाधिकार सुरक्षित।' : 'All rights reserved.'}
          </p>
          <p className="text-center sm:text-right">
            {lang === 'hi'
              ? '100% सॉलिड वुड फर्नीचर निर्माण · सीधे कारखाने से आपके घर तक'
              : 'Handcrafted with Pride in India · Teak & Sheesham Specialists'}
          </p>
        </div>
      </div>

      {/* Terms, Conditions & Warranty Policy Modal */}
      {showTermsModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#FAF8F5] text-[#241E19] border border-[#D5C2A5] rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#E0D5C3] pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-[#8E5327]" />
                <h3 className="font-display text-lg font-bold text-[#2D2319]">
                  {lang === 'hi'
                    ? 'नियम, शर्तें, वारंटी एवं गोपनीयता नीति'
                    : 'Terms of Service, Timber Warranty & Privacy Policy'}
                </h3>
              </div>
              <button
                onClick={() => setShowTermsModal(false)}
                className="p-1 rounded-lg hover:bg-black/5 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs sm:text-sm text-[#4A3E33] leading-relaxed">
              <p>
                <strong>1. 100% शुद्ध लकड़ी एवं सीज़निंग गारंटी:</strong> बाबा फर्नीचर उद्योग में निर्मित सभी सागवान (Grade-A Solid Teak) और शीशम (Pure Sheesham) के फर्नीचर क्लिन-ड्राइड (Kiln-Seasoned) और एंटी-बोरर ट्रीटेड होते हैं। प्रत्येक प्रीमियम फर्नीचर पर <strong>10 वर्ष की लिखित दीमक एवं घुन वारंटी</strong> दी जाती है।
              </p>
              <p>
                <strong>2. कस्टम डिज़ाइन एवं बुकिंग नियम:</strong> ग्राहक के कमरे के नाप या फोटो के अनुसार कस्टम फर्नीचर या शादी-विवाह पैकेज का निर्माण प्रारंभ करने के लिए कुल अनुमानित मूल्य का न्यूनतम <strong>25% अग्रिम (Booking Advance)</strong> जमा करना अनिवार्य है।
              </p>
              <p>
                <strong>3. निरीक्षण, डिलीवरी एवं शेष भुगतान:</strong> पॉलिश से पूर्व ग्राहक कारखाने में लकड़ी के कोरे ढांचे (Raw Timber Structure) की जांच कर सकते हैं। सुरक्षित डिलीवरी के समय शेष 75% राशि देय होगी।
              </p>
              <p>
                <strong>4. गोपनीयता एवं खाता सुरक्षा:</strong> ग्राहकों का मोबाइल नंबर, पता, ईमेल एवं इन-ऐप लाइव चैट संवाद पूर्णतः गोपनीय एवं सुरक्षित रखा जाता है। ग्राहक कभी भी अपने प्रोफ़ाइल सेटिंग्स से अपना खाता हटाने (Account Deletion) का अधिकार रखते हैं।
              </p>
            </div>

            <div className="pt-3 border-t border-[#E0D5C3] flex justify-end">
              <button
                onClick={() => setShowTermsModal(false)}
                className="px-5 py-2 text-xs font-bold bg-[#8E5327] hover:bg-[#73411C] text-white rounded-lg cursor-pointer"
              >
                {lang === 'hi' ? 'समझ गया / बंद करें' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
};
