import React, { useState } from 'react';
import { Product, ShowroomConfig } from '../types/furniture';
import { shareProductDetails, downloadImageFile, copyTextToClipboard } from '../utils/shareAndDownload';
import {
  X,
  MessageCircle,
  PhoneCall,
  ShieldCheck,
  Ruler,
  CheckCircle2,
  Share2,
  Layers,
  Download,
  Copy,
  Check,
} from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  config: ShowroomConfig;
  lang: 'hi' | 'en';
  onClose: () => void;
  onRequestQuote: (product: Product) => void;
  onOpenLiveChat?: (product?: Product) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  config,
  lang,
  onClose,
  onRequestQuote,
  onOpenLiveChat,
}) => {
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!product) return null;

  const handleShare = async () => {
    await shareProductDetails(product, config, lang);
  };

  const handleCopyLink = async () => {
    const success = await copyTextToClipboard(window.location.href);
    if (success) {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleDownloadImage = async () => {
    setDownloading(true);
    const filename = `${config.businessName}_${product.sku}_${product.title}`;
    await downloadImageFile(product.imageUrl, filename);
    setDownloading(false);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white rounded-2xl border border-[#D5C2A5] shadow-2xl overflow-hidden my-8">
        {/* Header bar with Download and Share */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E8DEC8] bg-[#FAF6F0]">
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono font-medium text-[#8E5327] bg-[#EFE6D8] px-2 py-0.5 rounded">
              SKU: {product.sku}
            </span>
            <span className="text-xs text-stone-500">
              {lang === 'hi' ? product.categoryLabelHi : product.categoryLabel}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Download Button in Header */}
            <button
              onClick={handleDownloadImage}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#2D2319] bg-[#EFE6D8] hover:bg-[#E3D6C1] rounded-md border border-[#D5C2A5] transition-colors cursor-pointer"
              title={lang === 'hi' ? 'फोटो डाउनलोड करें' : 'Download Photo'}
            >
              {downloadSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700">{lang === 'hi' ? 'डाउनलोड हुआ' : 'Downloaded'}</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5 text-[#8E5327]" />
                  <span>{lang === 'hi' ? 'डाउनलोड' : 'Download'}</span>
                </>
              )}
            </button>

            {/* Share Button in Header */}
            <button
              onClick={handleShare}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#2D2319] bg-[#EFE6D8] hover:bg-[#E3D6C1] rounded-md border border-[#D5C2A5] transition-colors cursor-pointer"
              title={lang === 'hi' ? 'शेयर करें (Share)' : 'Share Product'}
            >
              <Share2 className="w-3.5 h-3.5 text-[#8E5327]" />
              <span>{lang === 'hi' ? 'शेयर करें' : 'Share'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-stone-500 hover:text-red-700 hover:bg-stone-100 rounded-md transition-colors cursor-pointer ml-1"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body content */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6 sm:p-8 max-h-[80vh] overflow-y-auto">
          {/* Left: Product Image & Download/Share strip */}
          <div className="space-y-4">
            <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-[#F2ECE1] border border-[#E0D5C3]">
              <img
                src={product.imageUrl}
                alt={lang === 'hi' ? product.titleHi : product.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Quick Action Strip under Image */}
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={handleDownloadImage}
                disabled={downloading}
                className="flex items-center justify-center gap-1.5 py-2 px-2 text-xs font-semibold text-[#2D2319] bg-[#FAF6F0] hover:bg-[#F2ECE1] border border-[#E0D5C3] rounded-lg transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-[#8E5327]" />
                <span>{downloadSuccess ? (lang === 'hi' ? 'हो गया!' : 'Saved!') : lang === 'hi' ? 'फोटो सेव' : 'Download'}</span>
              </button>

              <button
                onClick={handleShare}
                className="flex items-center justify-center gap-1.5 py-2 px-2 text-xs font-semibold text-[#2D2319] bg-[#FAF6F0] hover:bg-[#F2ECE1] border border-[#E0D5C3] rounded-lg transition-colors cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5 text-[#8E5327]" />
                <span>{lang === 'hi' ? 'शेयर' : 'Share'}</span>
              </button>

              <button
                onClick={handleCopyLink}
                className="flex items-center justify-center gap-1.5 py-2 px-2 text-xs font-semibold text-[#2D2319] bg-[#FAF6F0] hover:bg-[#F2ECE1] border border-[#E0D5C3] rounded-lg transition-colors cursor-pointer"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-700">{lang === 'hi' ? 'कॉपी हुआ' : 'Copied'}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-[#8E5327]" />
                    <span>{lang === 'hi' ? 'लिंक कॉपी' : 'Copy Link'}</span>
                  </>
                )}
              </button>
            </div>

            {/* Quality Seals */}
            <div className="p-3.5 rounded-lg bg-[#FAF6F0] border border-[#E8DEC8] space-y-2 text-xs text-[#5A4D40]">
              <div className="flex items-center gap-2 font-semibold text-[#2D2319]">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>
                  {product.warrantyYears}{' '}
                  {lang === 'hi' ? 'साल की दीमक व घुन रोधी गारंटी' : 'Years Termite & Borer Warranty'}
                </span>
              </div>
              <p className="text-[11px] text-[#6A5A4A] leading-relaxed">
                {lang === 'hi'
                  ? 'यह उत्पाद पूर्ण रूप से सीजन्ड लकड़ी (Kiln-Dried Timber) से निर्मित है। नमी और मौसम से मुड़ने की कोई संभावना नहीं।'
                  : 'Engineered from chemically treated, kiln-seasoned hardwood to eliminate moisture deformation and seasonal swelling.'}
              </p>
            </div>
          </div>

          {/* Right: Specifications & Direct Quotation Form */}
          <div className="space-y-5 flex flex-col justify-between">
            <div className="space-y-4">
              <div>
                <div className="text-xs font-semibold text-[#8E5327] uppercase tracking-wider">
                  {product.woodType}
                </div>
                <h2 className="font-display text-2xl font-bold text-[#2D2319] pt-1">
                  {lang === 'hi' ? product.titleHi : product.title}
                </h2>
              </div>

              {/* Dimensions */}
              <div className="flex items-center gap-2 text-sm text-[#4A3E33] bg-[#F7F2E9] p-2.5 rounded-lg border border-[#E8DEC8]">
                <Ruler className="w-4 h-4 text-[#8E5327] shrink-0" />
                <span className="font-semibold">{lang === 'hi' ? 'साइज / माप:' : 'Dimensions:'}</span>
                <span className="font-mono">{product.dimensions}</span>
              </div>

              {/* Description */}
              <p className="text-sm text-[#5A4D40] leading-relaxed">
                {lang === 'hi' ? product.descriptionHi : product.description}
              </p>

              {/* Polish Finish Options */}
              <div className="space-y-1.5">
                <span className="text-xs font-semibold text-[#2D2319] flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-[#8E5327]" />
                  <span>{lang === 'hi' ? 'उपलब्ध पॉलिश शेड्स:' : 'Available Polish Options:'}</span>
                </span>
                <div className="flex flex-wrap gap-2">
                  {product.finishOptions.map((finish, i) => (
                    <span
                      key={i}
                      className="text-xs font-medium px-2.5 py-1 bg-[#F1E9DC] text-[#4A3E33] rounded-md border border-[#DECDB7]"
                    >
                      {finish}
                    </span>
                  ))}
                </div>
              </div>

              {/* Key Features */}
              <div className="space-y-2">
                <span className="text-xs font-semibold text-[#2D2319]">
                  {lang === 'hi' ? 'मुख्य विशेषताएं:' : 'Key Highlights:'}
                </span>
                <ul className="grid grid-cols-1 gap-1.5 text-xs text-[#5A4D40]">
                  {(lang === 'hi' ? product.featuresHi : product.features).map((feat, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#8E5327] shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Price Transparency Banner */}
              <div className="p-3 bg-[#FFF9E6] border border-[#F2DE9C] rounded-lg text-xs text-[#6B5211] leading-relaxed">
                <strong>{lang === 'hi' ? 'सीधे दुकान का रेट:' : 'Shop Direct Pricing:'}</strong>{' '}
                {lang === 'hi'
                  ? 'हम फर्नीचर सीधे अपनी दुकान में बनाते हैं। अंतिम मूल्य लकड़ी के प्रकार, साइज और पॉलिश पर निर्भर करता है। सही दुकान रेट जानने के लिए लाइव चैट में पूछें या कॉल बैक का अनुरोध करें।'
                  : 'Since we manufacture bespoke solid wood furniture, prices vary based on chosen timber grade and custom sizing. Connect via Live Chat or request a callback for immediate shop price.'}
              </div>
            </div>

            {/* CTAs */}
            <div className="pt-4 border-t border-[#E8DEC8] flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => {
                  onClose();
                  onOpenLiveChat?.(product);
                }}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-lg shadow-sm transition-colors text-center cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-white shrink-0" />
                <span>{lang === 'hi' ? 'लाइव चैट में रेट पूछें' : 'Ask Price in Live Chat'}</span>
              </button>

              <button
                onClick={() => {
                  onClose();
                  onRequestQuote(product);
                }}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold text-[#2D2319] bg-[#EFE6D8] hover:bg-[#E3D6C1] border border-[#C5B396] rounded-lg transition-colors cursor-pointer text-center"
              >
                <PhoneCall className="w-4 h-4 text-[#8E5327] shrink-0" />
                <span>{lang === 'hi' ? 'कॉल बैक का अनुरोध' : 'Request Callback Quote'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
