import React from 'react';
import { FurnitureCategory } from '../types/furniture';
import {
  Search,
  Bed,
  Utensils,
  Armchair,
  DoorClosed,
  Sparkles,
  Tv,
  Briefcase,
  SlidersHorizontal,
  RotateCcw,
} from 'lucide-react';

interface CategoryNavProps {
  activeCategory: FurnitureCategory;
  onSelectCategory: (cat: FurnitureCategory) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedWood: string;
  onSelectWood: (wood: string) => void;
  sortBy?: 'featured' | 'price-asc' | 'price-desc' | 'warranty';
  onSortChange?: (sort: 'featured' | 'price-asc' | 'price-desc' | 'warranty') => void;
  priceFilter?: 'all' | 'under-35k' | 'above-35k' | 'in-stock';
  onPriceFilterChange?: (filter: 'all' | 'under-35k' | 'above-35k' | 'in-stock') => void;
  totalProductsCount: number;
  lang: 'hi' | 'en';
}

const CATEGORIES: {
  id: FurnitureCategory;
  label: string;
  labelHi: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  { id: 'all', label: 'All Collections', labelHi: 'सभी फर्नीचर', icon: SlidersHorizontal },
  { id: 'beds', label: 'Beds & Bedroom', labelHi: 'बेड्स (King/Queen)', icon: Bed },
  { id: 'dining', label: 'Dining Sets', labelHi: 'डाइनिंग टेबल', icon: Utensils },
  { id: 'sofas', label: 'Luxury Sofas', labelHi: 'शाही सोफा सेट', icon: Armchair },
  { id: 'wardrobes', label: 'Almirahs & Wardrobes', labelHi: 'अलमारी व वार्डरोब', icon: DoorClosed },
  { id: 'temples', label: 'Wooden Mandir', labelHi: 'पूजा मंदिर', icon: Sparkles },
  { id: 'living', label: 'TV Units & Tables', labelHi: 'टीवी यूनिट व टेबल', icon: Tv },
  { id: 'office', label: 'Office & Study', labelHi: 'ऑफिस टेबल', icon: Briefcase },
];

const QUICK_TAGS = [
  { q: 'King Bed', labelHi: '🛏️ सागवान किंग बेड', labelEn: '🛏️ Teak King Bed' },
  { q: 'Dining', labelHi: '🍽️ 6-सीटर डाइनिंग', labelEn: '🍽️ 6-Seater Dining' },
  { q: 'Sofa', labelHi: '🛋️ महाराजा सोफा', labelEn: '🛋️ Maharaja Sofa' },
  { q: 'Mandir', labelHi: '🛕 पूजा मंदिर', labelEn: '🛕 Puja Mandir' },
  { q: 'Wardrobe', labelHi: '🚪 4-डोर अलमारी', labelEn: '🚪 4-Door Wardrobe' },
];

export const CategoryNav: React.FC<CategoryNavProps> = ({
  activeCategory,
  onSelectCategory,
  searchQuery,
  onSearchChange,
  selectedWood,
  onSelectWood,
  sortBy = 'featured',
  onSortChange,
  priceFilter = 'all',
  onPriceFilterChange,
  totalProductsCount,
  lang,
}) => {
  const hasFilters =
    activeCategory !== 'all' ||
    Boolean(searchQuery.trim()) ||
    selectedWood !== 'all' ||
    priceFilter !== 'all' ||
    sortBy !== 'featured';

  return (
    <div className="bg-gradient-to-b from-[#F8F3E8] to-[#F4ECE0] border-b border-[#E8DEC8] py-7 no-print" id="collections">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[#8E5327] mb-1">
              <span>✨ स्मार्ट एक्सप्लोर व फ़िल्टर इंजन (Smart Explore & Search)</span>
            </div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#2D2319]">
              {lang === 'hi' ? 'फर्नीचर कैटलॉग एवं श्रेणियां' : 'Furniture Catalog & Categories'}
            </h2>
            <p className="text-xs text-[#6A5A4A]">
              {lang === 'hi'
                ? `कुल ${totalProductsCount} मास्टरपीस डिजाइन उपलब्ध · बिना किसी गुप्त शुल्क के`
                : `${totalProductsCount} master designs available · Factory direct transparent craftsmanship`}
            </p>
          </div>

          {/* Search + Wood + Budget + Sort Row */}
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="relative flex-1 min-w-[220px] sm:w-64">
              <Search className="w-4 h-4 text-[#8E5327] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder={
                  lang === 'hi'
                    ? 'फर्नीचर खोजें (बेड, सोफा, मंदिर, SKU)...'
                    : 'Search design, wood, SKU...'
                }
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full pl-9 pr-7 py-2 text-xs sm:text-sm bg-white border border-[#D5C2A5] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8E5327] text-[#2D2319] shadow-xs"
              />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-700 cursor-pointer"
                  aria-label="Clear search"
                >
                  ✕
                </button>
              )}
            </div>

            <select
              value={selectedWood}
              onChange={(e) => onSelectWood(e.target.value)}
              className="py-2 px-3 text-xs sm:text-sm bg-white border border-[#D5C2A5] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
            >
              <option value="all">{lang === 'hi' ? '🪵 सभी लकड़ी (All Wood)' : '🪵 All Wood Types'}</option>
              <option value="Solid Teak (सागवान)">{lang === 'hi' ? 'सागवान (Solid Teak)' : 'Solid Teak Wood'}</option>
              <option value="Pure Sheesham (शीशम)">{lang === 'hi' ? 'शीशम (Pure Sheesham)' : 'Pure Sheesham Wood'}</option>
              <option value="Rosewood (शीशम रोसवुड)">{lang === 'hi' ? 'शीशम रोसवुड (Rosewood)' : 'Rosewood (Sheesham)'}</option>
              <option value="Engineered Hardwood">{lang === 'hi' ? 'इंजीनियर्ड हार्डवुड' : 'Engineered Hardwood'}</option>
              <option value="Marine Grade Ply">{lang === 'hi' ? 'मरीन ग्रेड प्लाई' : 'Marine Grade Ply'}</option>
            </select>

            {onPriceFilterChange && (
              <select
                value={priceFilter}
                onChange={(e) => onPriceFilterChange(e.target.value as any)}
                className="py-2 px-3 text-xs sm:text-sm bg-white border border-[#D5C2A5] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
              >
                <option value="all">{lang === 'hi' ? '💰 सभी बजट' : '💰 All Budgets'}</option>
                <option value="under-35k">{lang === 'hi' ? '₹35,000 के अंदर' : 'Under ₹35,000'}</option>
                <option value="above-35k">{lang === 'hi' ? '₹35,000 से ऊपर' : 'Above ₹35,000'}</option>
                <option value="in-stock">{lang === 'hi' ? '✅ केवल इन-स्टॉक' : '✅ In Stock Only'}</option>
              </select>
            )}

            {onSortChange && (
              <select
                value={sortBy}
                onChange={(e) => onSortChange(e.target.value as any)}
                className="py-2 px-3 text-xs sm:text-sm bg-white border border-[#D5C2A5] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
              >
                <option value="featured">{lang === 'hi' ? '⭐ लोकप्रिय पहले' : '⭐ Featured First'}</option>
                <option value="price-asc">{lang === 'hi' ? '📉 कीमत: कम से ज्यादा' : '📉 Price: Low to High'}</option>
                <option value="price-desc">{lang === 'hi' ? '📈 कीमत: ज्यादा से कम' : '📈 Price: High to Low'}</option>
                <option value="warranty">{lang === 'hi' ? '🛡️ सर्वाधिक वारंटी' : '🛡️ Highest Warranty'}</option>
              </select>
            )}
          </div>
        </div>

        {/* Quick Search Chips */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] font-semibold text-[#6A5A4A]">
              {lang === 'hi' ? '🔥 त्वरित खोज:' : '🔥 Quick Search:'}
            </span>
            {QUICK_TAGS.map((tag) => {
              const active = searchQuery.toLowerCase() === tag.q.toLowerCase();
              return (
                <button
                  key={tag.q}
                  onClick={() => onSearchChange(active ? '' : tag.q)}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-medium transition-all cursor-pointer ${
                    active
                      ? 'bg-[#2D2319] text-[#FDE68A]'
                      : 'bg-white hover:bg-[#EFE6D8] text-[#5A4D40] border border-[#DFD2BD]'
                  }`}
                >
                  {lang === 'hi' ? tag.labelHi : tag.labelEn}
                </button>
              );
            })}
          </div>
          {hasFilters && (
            <button
              onClick={() => {
                onSelectCategory('all');
                onSearchChange('');
                onSelectWood('all');
                if (onPriceFilterChange) onPriceFilterChange('all');
                if (onSortChange) onSortChange('featured');
              }}
              className="inline-flex items-center gap-1 text-xs font-semibold text-red-700 hover:underline cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>{lang === 'hi' ? 'सभी फ़िल्टर रीसेट करें' : 'Reset Filters'}</span>
            </button>
          )}
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none pt-1">
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-[#8E5327] to-[#6E3D18] text-white shadow-sm'
                    : 'bg-white text-[#4A3E33] hover:bg-[#EFE6D8] border border-[#E0D3BE]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-[#8E5327]'}`} />
                <span>{lang === 'hi' ? cat.labelHi : cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
