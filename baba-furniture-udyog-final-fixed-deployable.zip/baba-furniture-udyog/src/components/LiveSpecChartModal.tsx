import React, { useState } from 'react';
import { ShowroomConfig } from '../types/furniture';
import { X, BarChart3, Printer } from 'lucide-react';

interface LiveSpecChartModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: ShowroomConfig;
  lang: 'hi' | 'en';
}

const WOOD_COMPARISON_CHART = [
  {
    wood: 'Solid UP/MP Teak (सागवान)',
    lifespan: '50+ Years (पीढ़ियों तक)',
    termiteRating: '100% Natural Oil Immunity',
    density: '650-750 kg/m³',
    grain: 'Rich Golden Brown with Natural Rings',
    bestFor: 'King Beds, Mandir, Heavy Carved Sofas',
    waterResistance: '⭐⭐⭐⭐⭐ (Extreme)',
  },
  {
    wood: 'Pure Sheesham (शीशम)',
    lifespan: '40+ Years (अत्यधिक मजबूत)',
    termiteRating: '100% Kiln-Seasoned & Treated',
    density: '750-850 kg/m³ (Heavy)',
    grain: 'Dramatic Dark Marbled Streaks',
    bestFor: 'Dining Sets, Almirahs, Bookshelves',
    waterResistance: '⭐⭐⭐⭐ (High)',
  },
  {
    wood: 'Rosewood (शीशम रोसवुड)',
    lifespan: '45+ Years',
    termiteRating: '100% Boron Treated',
    density: '800-900 kg/m³',
    grain: 'Deep Reddish Brown Texture',
    bestFor: 'Traditional Carved Mandirs & Tables',
    waterResistance: '⭐⭐⭐⭐ (High)',
  },
  {
    wood: 'Marine Grade Ply / Hardwood',
    lifespan: '15-20 Years',
    termiteRating: 'Chemical Treated Barrier',
    density: '600-680 kg/m³',
    grain: 'Uniform Veneer Sheet Finish',
    bestFor: 'Modular Kitchens & Sliding Wardrobes',
    waterResistance: '⭐⭐⭐⭐ (Waterproof)',
  },
];

const ROOM_DIMENSION_CHART = [
  {
    furniture: 'King Size Bed (किंग बेड)',
    furnitureSize: '78" x 72" (6.5 x 6 ft)',
    minRoomSize: '10 x 12 ft',
    idealRoomSize: '12 x 14 ft',
    perimeterClearance: '3.0 ft walkway on sides',
    suitableFor: 'Master Bedroom',
  },
  {
    furniture: 'Queen Size Bed (क्वीन बेड)',
    furnitureSize: '78" x 60" (6.5 x 5 ft)',
    minRoomSize: '10 x 10 ft',
    idealRoomSize: '11 x 12 ft',
    perimeterClearance: '2.5 ft walkway on sides',
    suitableFor: 'Guest / Standard Bedroom',
  },
  {
    furniture: '6-Seater Dining Table (6-सीटर डाइनिंग)',
    furnitureSize: '60" x 36" (5 x 3 ft) + Chairs',
    minRoomSize: '10 x 12 ft',
    idealRoomSize: '12 x 14 ft',
    perimeterClearance: '3.5 ft for chair pullout',
    suitableFor: 'Dining Hall',
  },
  {
    furniture: '8-Seater Grand Dining (8-सीटर डाइनिंग)',
    furnitureSize: '84" x 42" (7 x 3.5 ft) + Chairs',
    minRoomSize: '12 x 16 ft',
    idealRoomSize: '14 x 18 ft',
    perimeterClearance: '4.0 ft circulation space',
    suitableFor: 'Large Family Dining Room',
  },
  {
    furniture: '3+1+1 Heritage Wooden Sofa',
    furnitureSize: '84" x 34" (3-seater) + 2 single',
    minRoomSize: '12 x 14 ft',
    idealRoomSize: '14 x 18 ft',
    perimeterClearance: '3.0 ft between sofa & table',
    suitableFor: 'Living Room / Drawing Room',
  },
  {
    furniture: 'Grand Puja Mandir (भव्य मंदिर)',
    furnitureSize: '48" x 24" x 66" (4 x 2 ft)',
    minRoomSize: '6 x 8 ft (Corner / Room)',
    idealRoomSize: '8 x 10 ft Puja Room',
    perimeterClearance: '2.5 ft front space for aarti',
    suitableFor: 'Pooja Room / Sacred Corner',
  },
];

export const LiveSpecChartModal: React.FC<LiveSpecChartModalProps> = ({
  isOpen,
  onClose,
  config,
  lang,
}) => {
  const [activeTab, setActiveTab] = useState<'wood' | 'dimensions'>('wood');

  if (!isOpen) return null;

  return (
    <div className="printable-modal-wrapper fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <div className="printable-modal-box relative w-full max-w-4xl bg-white rounded-2xl border border-[#D5C2A5] shadow-2xl overflow-hidden my-6 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#E8DEC8] bg-[#FAF6F0] flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#8E5327] text-white">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-[#2D2319]">
                {lang === 'hi'
                  ? 'लाइव फर्नीचर तुलना चार्ट (Live Specs & Wood Chart)'
                  : 'Live Furniture Specs & Wood Comparison Chart'}
              </h3>
              <p className="text-xs text-[#6A5A4A]">
                {lang === 'hi'
                  ? 'लकड़ी की गुणवत्ता, दीमक सुरक्षा और कमरे के साइज का विस्तृत तुलनात्मक चार्ट'
                  : 'Authentic timber grade breakdown and room clearance guidelines'}
              </p>
            </div>
          </div>

          <div className="no-print flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#2D2319] bg-white border border-[#D5C2A5] rounded-lg hover:bg-[#EFE6D8] transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-[#8E5327]" />
              <span className="hidden sm:inline">{lang === 'hi' ? 'प्रिंट चार्ट' : 'Print'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-stone-500 hover:text-stone-900 rounded-md transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="no-print px-6 py-2.5 bg-white border-b border-[#E8DEC8] flex items-center gap-2 shrink-0">
          <button
            onClick={() => setActiveTab('wood')}
            className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'wood'
                ? 'bg-[#8E5327] text-white shadow-xs'
                : 'bg-[#FAF6F0] text-[#5A4D40] hover:bg-[#EFE6D8]'
            }`}
          >
            {lang === 'hi' ? '1. लकड़ी तुलना चार्ट (Wood Types)' : '1. Wood Types Comparison'}
          </button>
          <button
            onClick={() => setActiveTab('dimensions')}
            className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'dimensions'
                ? 'bg-[#8E5327] text-white shadow-xs'
                : 'bg-[#FAF6F0] text-[#5A4D40] hover:bg-[#EFE6D8]'
            }`}
          >
            {lang === 'hi' ? '2. कमरा व साइज चार्ट (Room Clearance)' : '2. Room Clearance Specs'}
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto print:overflow-visible flex-1 space-y-6">
          {activeTab === 'wood' ? (
            <div className="space-y-4">
              <div className="text-xs text-[#5A4D40] bg-[#FAF8F5] p-3 rounded-lg border border-[#E8DEC8]">
                <strong>💡 {config.businessName} गारंटी:</strong> हमारे सभी फर्नीचर 100% सीजन्ड (Kiln-Dried
                Hardwood) से बनाए जाते हैं। नमी 10% से नीचे रखी जाती है ताकि कोई भी फर्नीचर कभी मुड़े या
                चटके नहीं।
              </div>

              {/* Responsive Table */}
              <div className="overflow-x-auto rounded-xl border border-[#D5C2A5]">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#2D2319] text-white">
                      <th className="p-3 font-semibold">लकड़ी (Timber Grade)</th>
                      <th className="p-3 font-semibold">आयु / मजबूती</th>
                      <th className="p-3 font-semibold">दीमक सुरक्षा</th>
                      <th className="p-3 font-semibold">नसों की बनावट (Grains)</th>
                      <th className="p-3 font-semibold">सर्वश्रेष्ठ उपयोग</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E8DEC8]">
                    {WOOD_COMPARISON_CHART.map((row, idx) => (
                      <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-[#FAF8F5]'}>
                        <td className="p-3 font-bold text-[#2D2319] whitespace-nowrap">{row.wood}</td>
                        <td className="p-3 font-medium text-[#8E5327]">{row.lifespan}</td>
                        <td className="p-3 text-emerald-800 font-semibold">{row.termiteRating}</td>
                        <td className="p-3 text-[#5A4D40]">{row.grain}</td>
                        <td className="p-3 text-[#2D2319]">{row.bestFor}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="text-xs text-[#5A4D40] bg-[#FAF8F5] p-3 rounded-lg border border-[#E8DEC8]">
                <strong>📐 कमरा माप गाइड:</strong> फर्नीचर लेने से पहले दीवार और अलमारी खुलने की जगह अवश्य
                मापें। आदर्श रूप से चारों तरफ 2.5 से 3.5 फीट का रास्ता होना चाहिए।
              </div>

              <div className="overflow-x-auto rounded-xl border border-[#D5C2A5]">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#2D2319] text-white">
                      <th className="p-3 font-semibold">फर्नीचर का प्रकार</th>
                      <th className="p-3 font-semibold">फर्नीचर साइज (LxW)</th>
                      <th className="p-3 font-semibold">न्यूनतम कमरा साइज</th>
                      <th className="p-3 font-semibold">आदर्श कमरा साइज</th>
                      <th className="p-3 font-semibold">खाली जगह (Clearance)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E8DEC8]">
                    {ROOM_DIMENSION_CHART.map((row, idx) => (
                      <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-[#FAF8F5]'}>
                        <td className="p-3 font-bold text-[#2D2319] whitespace-nowrap">
                          {row.furniture}
                        </td>
                        <td className="p-3 font-mono font-medium text-[#8E5327]">
                          {row.furnitureSize}
                        </td>
                        <td className="p-3 font-mono">{row.minRoomSize}</td>
                        <td className="p-3 font-mono font-semibold text-emerald-800">
                          {row.idealRoomSize}
                        </td>
                        <td className="p-3 text-[#5A4D40]">{row.perimeterClearance}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Footer note in modal */}
          <div className="pt-4 border-t border-[#E8DEC8] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#6A5A4A]">
            <span>
              <strong>दुकान संपर्क:</strong> {config.phone} · {config.address}
            </span>
            <button
              onClick={onClose}
              className="no-print px-4 py-2 bg-[#8E5327] text-white rounded-lg font-semibold hover:bg-[#73411C] transition-colors cursor-pointer"
            >
              {lang === 'hi' ? 'चार्ट बंद करें' : 'Close Chart'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
