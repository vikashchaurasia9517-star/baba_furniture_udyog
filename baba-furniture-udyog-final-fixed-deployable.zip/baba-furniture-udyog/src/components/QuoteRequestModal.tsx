import React, { useState } from 'react';
import { CustomerInquiry, CustomerUser, Product, ShowroomConfig } from '../types/furniture';
import { validateInquiryForm, buildWhatsAppInquiryUrl } from '../utils/furnitureLogic';
import { X, CheckCircle2, Phone, MessageSquare, Send } from 'lucide-react';

interface QuoteRequestModalProps {
  product: Product | null;
  config: ShowroomConfig;
  lang: 'hi' | 'en';
  customerUser?: CustomerUser | null;
  onClose: () => void;
  onSubmitInquiry: (inquiry: Omit<CustomerInquiry, 'id' | 'timestamp' | 'formattedDate' | 'status'>) => void;
}

export const QuoteRequestModal: React.FC<QuoteRequestModalProps> = ({
  product,
  config,
  lang,
  customerUser,
  onClose,
  onSubmitInquiry,
}) => {
  const [customerName, setCustomerName] = useState(customerUser?.name || '');
  const [phone, setPhone] = useState(customerUser?.phone || '');
  const [city, setCity] = useState(customerUser?.city || '');
  const [preferredContact, setPreferredContact] = useState<'whatsapp' | 'call'>('whatsapp');
  const [woodPreference, setWoodPreference] = useState<string>(product ? product.woodType : 'Solid Teak (सागवान)');
  const [note, setNote] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateInquiryForm({ customerName, phone });
    if (!validation.isValid) {
      setErrorMessage(validation.error || 'Please fill required details.');
      return;
    }

    setErrorMessage('');
    onSubmitInquiry({
      customerName,
      phone,
      city,
      preferredContact,
      productId: product?.id,
      productTitle: product ? (lang === 'hi' ? product.titleHi : product.title) : 'General Inquiry',
      productSku: product?.sku,
      woodPreference,
      customDesignNote: note,
    });

    setIsSubmitted(true);
  };

  const directWhatsAppUrl = buildWhatsAppInquiryUrl({
    whatsappNumber: config.whatsappNumber,
    customerName,
    productTitle: product ? (lang === 'hi' ? product.titleHi : product.title) : undefined,
    sku: product?.sku,
    woodType: woodPreference,
    customMessage: note || undefined,
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-2xl border border-[#D5C2A5] shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E8DEC8] bg-[#FAF6F0]">
          <div>
            <h3 className="font-display text-lg font-bold text-[#2D2319]">
              {lang === 'hi' ? 'कोटेशन व कॉल बैक का अनुरोध' : 'Request Quotation & Callback'}
            </h3>
            <p className="text-xs text-[#6A5A4A]">
              {product
                ? `${lang === 'hi' ? product.titleHi : product.title} (${product.sku})`
                : lang === 'hi'
                ? 'बाबा फर्नीचर उद्योग, सीधा दुकान संपर्क'
                : 'Direct Workshop Inquiry'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-500 hover:text-stone-900 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {isSubmitted ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-700">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="font-display text-xl font-bold text-[#2D2319]">
                {lang === 'hi' ? 'धन्यवाद! आपकी पूछताछ दर्ज हो गई है' : 'Inquiry Received Successfully!'}
              </h4>
              <p className="text-sm text-[#5A4D40] leading-relaxed">
                {lang === 'hi'
                  ? `श्री ${customerName}, हमारे फर्नीचर विशेषज्ञ जल्द ही आपसे संपर्क करेंगे। तुरंत जवाब के लिए व्हाट्सएप भी कर सकते हैं:`
                  : `Dear ${customerName}, our showroom manager will get in touch shortly. You can also chat right away:`}
              </p>

              <div className="pt-3 flex flex-col sm:flex-row gap-3">
                <a
                  href={directWhatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-[#1E6B3E] hover:bg-[#165430] rounded-lg transition-colors"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>{lang === 'hi' ? 'व्हाट्सएप चैट खोलें' : 'Open WhatsApp'}</span>
                </a>
                <button
                  onClick={onClose}
                  className="flex-1 px-4 py-2.5 text-sm font-medium text-[#2D2319] bg-[#EFE6D8] hover:bg-[#E3D6C1] rounded-lg transition-colors cursor-pointer"
                >
                  {lang === 'hi' ? 'बंद करें' : 'Close'}
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {errorMessage && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-xs rounded-md">
                  {errorMessage}
                </div>
              )}

              {/* Name */}
              <div>
                <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                  {lang === 'hi' ? 'आपका नाम (Full Name) *' : 'Your Full Name *'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={lang === 'hi' ? 'जैसे: राजेश कुमार' : 'e.g. Ramesh Sharma'}
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
                />
              </div>

              {/* Phone */}
              <div>
                <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                  {lang === 'hi' ? 'मोबाइल नंबर (Phone / WhatsApp) *' : 'Mobile Number (10 digits) *'}
                </label>
                <input
                  type="tel"
                  required
                  placeholder="9876543210"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
                />
              </div>

              {/* City */}
              <div>
                <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                  {lang === 'hi' ? 'शहर / इलाका (City & Location)' : 'Your City / Town'}
                </label>
                <input
                  type="text"
                  placeholder={lang === 'hi' ? 'जैसे: गोरखपुर, कुशीनगर, देवरिया...' : 'e.g. Gorakhpur, Lucknow...'}
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
                />
              </div>

              {/* Preferred Contact Mode */}
              <div>
                <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                  {lang === 'hi' ? 'संपर्क का पसंदीदा माध्यम' : 'Preferred Contact Channel'}
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setPreferredContact('whatsapp')}
                    className={`flex items-center justify-center gap-2 p-2.5 rounded-lg border text-xs font-medium transition-all cursor-pointer ${
                      preferredContact === 'whatsapp'
                        ? 'border-[#1E6B3E] bg-[#E8F5EC] text-[#1E6B3E] font-semibold'
                        : 'border-[#DECDB7] bg-white text-[#5A4D40]'
                    }`}
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreferredContact('call')}
                    className={`flex items-center justify-center gap-2 p-2.5 rounded-lg border text-xs font-medium transition-all cursor-pointer ${
                      preferredContact === 'call'
                        ? 'border-[#8E5327] bg-[#F7F0E6] text-[#8E5327] font-semibold'
                        : 'border-[#DECDB7] bg-white text-[#5A4D40]'
                    }`}
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>{lang === 'hi' ? 'फोन कॉल (Direct Call)' : 'Phone Call'}</span>
                  </button>
                </div>
              </div>

              {/* Wood Preference */}
              <div>
                <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                  {lang === 'hi' ? 'लकड़ी की पसंद (Wood Preference)' : 'Preferred Wood'}
                </label>
                <select
                  value={woodPreference}
                  onChange={(e) => setWoodPreference(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
                >
                  <option value="Solid Teak (सागवान)">Solid Teak (सागवान) - Premium</option>
                  <option value="Pure Sheesham (शीशम)">Pure Sheesham (शीशम) - Heavy Grain</option>
                  <option value="Rosewood (शीशम रोसवुड)">Rosewood (शीशम रोसवुड) - Luxury Carved</option>
                  <option value="Engineered Hardwood">Engineered Hardwood / Ply - Budget Friendly</option>
                </select>
              </div>

              {/* Custom Note */}
              <div>
                <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                  {lang === 'hi' ? 'कोई विशेष माप या आवश्यकता (Special Requirements)' : 'Special Requirements or Dimensions'}
                </label>
                <textarea
                  rows={2}
                  placeholder={
                    lang === 'hi'
                      ? 'जैसे: मुझे 6x6.5 साइज चाहिए, या हेडबोर्ड में डार्क वॉलनट पॉलिश चाहिए...'
                      : 'e.g. Need 6x6.5 ft custom size, or specific bedroom space...'
                  }
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D5C2A5] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
                />
              </div>

              {/* Submit */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-lg shadow-sm transition-all cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>{lang === 'hi' ? 'कोटेशन अनुरोध भेजें' : 'Submit Quotation Request'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
