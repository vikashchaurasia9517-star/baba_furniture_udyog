import React, { useState } from 'react';
import { ShieldCheck, Flame, Droplets, Check, Compass, Layers } from 'lucide-react';

import { ShowroomConfig } from '../types/furniture';

interface WoodQualityShowcaseProps {
  lang: 'hi' | 'en';
  config?: ShowroomConfig;
}

const WOOD_TYPES = [
  {
    id: 'teak',
    name: 'Solid UP Teak (उत्तर प्रदेश के कारीगर)',
    nameEn: 'Grade-A Solid Teak (Sagwan)',
    durability: '50+ Years',
    termiteRating: '100% Natural Immunity',
    grainType: 'Golden Brown with Straight & Wavy Grain',
    bestFor: 'Luxury King Beds, Mandir, Heavy Carved Sofas, Exterior Doors',
    descriptionHi:
      'सागवान में कुदरती तेल (Natural Tectoquinoe) भरपूर होता है जिससे दीमक और पानी कभी नहीं लगते। यह लकड़ी सदियों तक बिना सिकुड़े या मुड़े जस की तस बनी रहती है।',
    descriptionEn:
      'Teak has exceptionally high natural silica and oil content, making it virtually impervious to termites, rot, and seasonal moisture variations.',
    bgTone: 'from-[#5C3B1E] to-[#3B2310]',
  },
  {
    id: 'sheesham',
    name: 'Pure Seasoned Sheesham (भारतीय शीशम)',
    nameEn: 'Pure Indian Sheesham (Rosewood)',
    durability: '40+ Years',
    termiteRating: 'Lifetime Treated Guarantee',
    grainType: 'Distinctive Deep Marbled Streaks',
    bestFor: 'Family Dining Tables, Hydraulic Beds, Heavy Almirahs, Bookshelves',
    descriptionHi:
      'शीशम की प्राकृतिक नसों और धारियों का टेक्सचर सबसे सुंदर होता है। इसकी घनत्व (Density) बहुत अधिक होती है, जो इसे भारी वजन सहने के लिए सर्वश्रेष्ठ बनाती है।',
    descriptionEn:
      'Sheesham is celebrated for its dramatic wood grains and exceptional tensile strength. Ideal for load-bearing furniture like dining tables and large bed frames.',
    bgTone: 'from-[#4A2B19] to-[#2B160C]',
  },
  {
    id: 'seasoning',
    name: 'Our 4-Step Kiln Curing Process (हमारी सीज़निंग प्रक्रिया)',
    nameEn: '4-Step Kiln-Drying & Seasoning',
    durability: 'Zero Warping Guarantee',
    termiteRating: 'Multi-layer Boron Treatment',
    grainType: 'Moisture Controlled to 8-12%',
    bestFor: 'Every piece leaving Baba Furniture Udyog',
    descriptionHi:
      'कच्ची लकड़ी में 30% तक नमी होती है। हम अपनी फैक्ट्री में वैक्यूम चैंबर और क्लिन-ड्राइंग के जरिए नमी को 10% से नीचे लाते हैं, जिससे जोड़ों में कभी दरार नहीं आती।',
    descriptionEn:
      'Green timber contains up to 35% moisture. We kiln-dry every plank to under 10% moisture content and pressure-treat it with eco-friendly anti-borer salts.',
    bgTone: 'from-[#2D2A26] to-[#1A1816]',
  },
];

export const WoodQualityShowcase: React.FC<WoodQualityShowcaseProps> = ({ lang, config }) => {
  const [selectedWood, setSelectedWood] = useState(0);
  const woodList = config?.woodTypes && config.woodTypes.length > 0 ? config.woodTypes : WOOD_TYPES;
  const active = woodList[selectedWood] || woodList[0];

  return (
    <section className="bg-[#FAF7F2] py-12 border-b border-[#E8DEC8]" id="wood-quality">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#8E5327] bg-[#F1E7D6] px-2.5 py-0.5 rounded">
            <Compass className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'असली लकड़ी की पहचान' : 'Timber Integrity & Science'}</span>
          </div>
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#2D2319]">
            {lang === 'hi'
              ? 'बाबा फर्नीचर उद्योग की असली लकड़ी और दीमक-प्रूफ गारंटी'
              : 'Our Wood Guarantee: Seasoned Teak & Sheesham Craftsmanship'}
          </h2>
          <p className="text-xs sm:text-sm text-[#6A5A4A] leading-relaxed">
            {lang === 'hi'
              ? 'बाजार में कई लोग सस्ते प्लाईवुड या केमिकल बोर्ड को लकड़ी कहकर बेचते हैं। हम आपको खुली चुनौती के साथ 100% सॉलिड असली लकड़ी की गारंटी देते हैं।'
              : 'Never settle for hollow particle boards. We build solely with solid kiln-dried timber sourced with verified provenance.'}
          </p>
        </div>

        {/* Tab Buttons */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {woodList.map((wood, idx) => (
            <button
              key={wood.id}
              onClick={() => setSelectedWood(idx)}
              className={`px-4 py-2.5 rounded-lg text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
                selectedWood === idx
                  ? 'bg-[#2D2319] text-white shadow-sm'
                  : 'bg-white text-[#5A4D40] hover:bg-[#EFE6D8] border border-[#D5C2A5]'
              }`}
            >
              {lang === 'hi' ? wood.name : wood.nameEn}
            </button>
          ))}
        </div>

        {/* Visual Showcase Card */}
        <div className="bg-white rounded-2xl border border-[#D5C2A5] overflow-hidden shadow-sm grid grid-cols-1 lg:grid-cols-12">
          {/* Left Wood Spec Details */}
          <div className="lg:col-span-7 p-6 sm:p-8 space-y-6">
            <div>
              <span className="text-xs font-mono text-[#8E5327] uppercase tracking-wider font-semibold">
                {lang === 'hi' ? 'मटेरियल विश्लेषण' : 'Material Inspection'}
              </span>
              <h3 className="font-display text-2xl font-bold text-[#2D2319] pt-1">
                {lang === 'hi' ? active.name : active.nameEn}
              </h3>
            </div>

            <p className="text-sm text-[#5A4D40] leading-relaxed">
              {lang === 'hi' ? active.descriptionHi : active.descriptionEn}
            </p>

            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="p-3.5 bg-[#FAF6F0] rounded-lg border border-[#E8DEC8]">
                <div className="flex items-center gap-2 text-xs text-[#6A5A4A] font-medium">
                  <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>{lang === 'hi' ? 'दीमक सुरक्षा' : 'Termite Proof'}</span>
                </div>
                <div className="text-sm font-bold text-[#2D2319] pt-1">{active.termiteRating}</div>
              </div>

              <div className="p-3.5 bg-[#FAF6F0] rounded-lg border border-[#E8DEC8]">
                <div className="flex items-center gap-2 text-xs text-[#6A5A4A] font-medium">
                  <Flame className="w-4 h-4 text-[#8E5327] shrink-0" />
                  <span>{lang === 'hi' ? 'आयु / मजबूती' : 'Expected Lifespan'}</span>
                </div>
                <div className="text-sm font-bold text-[#2D2319] pt-1">{active.durability}</div>
              </div>
            </div>

            <div className="space-y-2 text-xs text-[#5A4D40] pt-1">
              <div className="flex items-start gap-2">
                <Check className="w-4 h-4 text-[#8E5327] shrink-0 mt-0.5" />
                <span>
                  <strong>{lang === 'hi' ? 'नसों का प्रकार:' : 'Grain Texture:'}</strong> {active.grainType}
                </span>
              </div>
              <div className="flex items-start gap-2">
                <Check className="w-4 h-4 text-[#8E5327] shrink-0 mt-0.5" />
                <span>
                  <strong>{lang === 'hi' ? 'किस फर्नीचर के लिए श्रेष्ठ:' : 'Best Suited For:'}</strong>{' '}
                  {active.bestFor}
                </span>
              </div>
            </div>
          </div>

          {/* Right Visual Swatch & Guarantee Badge */}
          <div className="lg:col-span-5 bg-gradient-to-br from-[#2D2319] to-[#1A140E] p-6 sm:p-8 text-white flex flex-col justify-between">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-[#C89D66]/20 border border-[#C89D66]/40 text-[#E7D6C4] text-xs font-semibold">
                <Layers className="w-3.5 h-3.5 text-[#C89D66]" />
                <span>{lang === 'hi' ? '100% ऑथेंटिक लकड़ी' : 'Certified Hardwood'}</span>
              </div>

              <h4 className="font-display text-xl font-bold text-white leading-snug">
                {lang === 'hi'
                  ? 'हमारे दुकान में आकर अपनी आंखों से लकड़ी की जांच करें'
                  : 'Inspect Raw Planks Before Assembly at Our Factory'}
              </h4>

              <p className="text-xs text-[#D5C2A5] leading-relaxed">
                {lang === 'hi'
                  ? 'बाबा फर्नीचर उद्योग का वादा है: यदि कोई हमारे फर्नीचर में दीमक या मिलावटी लकड़ी साबित कर दे, तो हम पूरा फर्नीचर मुफ्त बदलने की लिखित गारंटी देते हैं।'
                  : 'We welcome you to inspect the raw wood planks in our workshop before cutting, carving, and polishing.'}
              </p>
            </div>

            <div className="pt-6 border-t border-white/10 flex items-center justify-between">
              <div className="text-xs text-[#C89D66]">
                <div>{lang === 'hi' ? 'फैक्ट्री परीक्षण रिपोर्ट' : 'Quality Checked'}</div>
                <div className="font-mono text-[10px] text-white/70">ISO-Graded Timber</div>
              </div>
              <span className="px-3 py-1 text-xs font-semibold bg-[#C89D66] text-[#241E19] rounded">
                10-Year Stamp
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
