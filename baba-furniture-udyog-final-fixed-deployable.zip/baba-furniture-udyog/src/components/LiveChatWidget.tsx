import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, CustomerUser, ShowroomConfig } from '../types/furniture';
import { fetchCustomerChatSessionApi, sendChatMessageApi } from '../services/api';
import {
  MessageCircle,
  Send,
  Phone,
  Sparkles,
  FileText,
  Clock,
  CheckCheck,
  Minimize2,
  User,
} from 'lucide-react';

interface LiveChatWidgetProps {
  config: ShowroomConfig;
  lang: 'hi' | 'en';
  customerUser?: CustomerUser | null;
  onOpenCustomOrder: () => void;
  onOpenCatalog: () => void;
  onOpenLiveChart: () => void;
  isOpenControlled?: boolean;
  onOpenControlled?: () => void;
  onCloseControlled?: () => void;
  prefillMessage?: string;
}

const QUICK_QUESTIONS_HI = [
  '🛏️ किंग साइज बेड के बारे में बताएं',
  '🪵 सागवान और शीशम में क्या अंतर है?',
  '📐 कस्टम साइज फर्नीचर कैसे बनवाएं?',
  '📍 दुकान का पता और खुलने का समय?',
  '📊 लाइव लकड़ी व साइज चार्ट दिखाएं',
];

const QUICK_QUESTIONS_EN = [
  '🛏️ Tell me about King Size Beds',
  '🪵 What is the difference between Teak & Sheesham?',
  '📐 How can I place a custom size order?',
  '📍 What is your showroom address & timing?',
  '📊 Show Live Wood & Specs Chart',
];

export const LiveChatWidget: React.FC<LiveChatWidgetProps> = ({
  config,
  lang,
  customerUser,
  onOpenCustomOrder,
  onOpenCatalog,
  onOpenLiveChart,
  isOpenControlled,
  onOpenControlled,
  onCloseControlled,
  prefillMessage,
}) => {
  const [internalIsOpen, setInternalIsOpen] = useState(false);
  const isOpen = isOpenControlled !== undefined ? isOpenControlled : internalIsOpen;

  const setIsOpen = (val: boolean) => {
    setInternalIsOpen(val);
    if (val && onOpenControlled) {
      onOpenControlled();
    }
    if (!val && onCloseControlled) {
      onCloseControlled();
    }
  };

  const [sessionId] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('bfu_live_chat_session_v2');
      if (saved) return saved;
      const created = `chat-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      localStorage.setItem('bfu_live_chat_session_v2', created);
      return created;
    } catch {
      return `chat-${Date.now()}`;
    }
  });

  const [guestName, setGuestName] = useState<string>(() => {
    try {
      return localStorage.getItem('bfu_live_chat_name_v2') || '';
    } catch {
      return '';
    }
  });
  const [guestPhone, setGuestPhone] = useState<string>(() => {
    try {
      return localStorage.getItem('bfu_live_chat_phone_v2') || '';
    } catch {
      return '';
    }
  });
  const [showIdentityBar, setShowIdentityBar] = useState(false);

  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [hasUnread, setHasUnread] = useState(true);
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'welcome-1',
      sender: 'shop',
      text:
        lang === 'hi'
          ? `नमस्ते! 🙏 बाबा फर्नीचर उद्योग में आपका स्वागत है। हम 100% असली सागवान (Teak) और शीशम (Sheesham) की लकड़ी से टिकाऊ फर्नीचर तैयार करते हैं।\n\nआप यहाँ सीधे हमारे शोरूम संचालक से बात कर सकते हैं:`
          : `Hello! 🙏 Welcome to Baba Furniture Udyog. We handcraft bespoke furniture in 100% seasoned Teak and Sheesham hardwood.\n\nChat directly with our showroom owner right here:`,
      timestamp: Date.now(),
      formattedTime: lang === 'hi' ? 'अभी' : 'Just now',
    },
  ]);

  // Update welcome message if language changes and only the welcome message is present
  useEffect(() => {
    setMessages((prev) => {
      if (prev.length === 1 && prev[0].id === 'welcome-1') {
        return [
          {
            ...prev[0],
            text:
              lang === 'hi'
                ? `नमस्ते! 🙏 बाबा फर्नीचर उद्योग में आपका स्वागत है। हम 100% असली सागवान (Teak) और शीशम (Sheesham) की लकड़ी से टिकाऊ फर्नीचर तैयार करते हैं।\n\nआप यहाँ सीधे हमारे शोरूम संचालक से बात कर सकते हैं:`
                : `Hello! 🙏 Welcome to Baba Furniture Udyog. We handcraft bespoke furniture in 100% seasoned Teak and Sheesham hardwood.\n\nChat directly with our showroom owner right here:`,
            formattedTime: lang === 'hi' ? 'अभी' : 'Just now',
          },
        ];
      }
      return prev;
    });
  }, [lang]);

  // Poll backend for real-time Shop Owner / Admin replies when chat is open
  useEffect(() => {
    if (!isOpen || !sessionId) return;
    let active = true;

    const syncSession = async () => {
      const remoteSession = await fetchCustomerChatSessionApi(sessionId);
      if (active && remoteSession && Array.isArray(remoteSession.messages) && remoteSession.messages.length > 0) {
        setMessages(remoteSession.messages);
      }
    };

    syncSession();
    const timer = setInterval(syncSession, 3500);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, [isOpen, sessionId]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      setHasUnread(false);
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isOpen, messages, isTyping]);

  const getLocalFallbackReply = (
    text: string
  ): { replyText: string; action?: ChatMessage['suggestedAction'] } => {
    const lower = text.toLowerCase();

    if (
      lower.includes('बेड') ||
      lower.includes('bed') ||
      lower.includes('king') ||
      lower.includes('किंग')
    ) {
      return {
        replyText:
          lang === 'hi'
            ? 'हमारे पास महाराजा रॉयल सागवान किंग बेड (78"x72") और शीशम बॉक्स बेड उपलब्ध हैं। इनमें हैवी-ड्यूटी हाइड्रोलिक स्टोरेज और 10 साल की दीमक गारंटी मिलती है। आप ऊपर कैटलॉग में सभी मॉडल्स देख सकते हैं।'
            : 'We craft Maharaja Solid Teak King Beds (78"x72") and Sheesham Box Beds equipped with heavy hydraulic lifts and a 10-year termite warranty.',
        action: { type: 'catalog', label: lang === 'hi' ? 'बेड्स कैटलॉग देखें' : 'View Beds Catalog' },
      };
    }
    if (
      lower.includes('सागवान') ||
      lower.includes('शीशम') ||
      lower.includes('teak') ||
      lower.includes('sheesham') ||
      lower.includes('wood') ||
      lower.includes('लकड़ी')
    ) {
      return {
        replyText:
          lang === 'hi'
            ? 'सागवान (Teak) में कुदरती तेल अधिक होने से यह 100% दीमक-रोधी और 50+ साल चलने वाला होता है। शीशम (Sheesham) अपनी सुंदर कुदरती नसों और भारी मजबूती के लिए डाइनिंग टेबल व अलमारी के लिए श्रेष्ठ माना जाता है। दोनों हमारे पास उपलब्ध हैं।'
            : 'Teak has natural oils offering 100% termite immunity (50+ yrs lifespan). Sheesham provides dense interlocking grain, ideal for dining tables and heavy almirahs.',
        action: { type: 'chart', label: lang === 'hi' ? '📊 लकड़ी तुलना चार्ट देखें' : '📊 View Wood Spec Chart' },
      };
    }
    if (
      lower.includes('कस्टम') ||
      lower.includes('custom') ||
      lower.includes('साइज') ||
      lower.includes('नाप')
    ) {
      return {
        replyText:
          lang === 'hi'
            ? 'हाँ जी! आप किसी भी फोटो या अपने कमरे के सटीक साइज के अनुसार फर्नीचर बनवा सकते हैं। "फोटो / डिज़ाइन अपलोड करें" पर क्लिक करें।'
            : 'Yes! You can upload reference photos or sketches, specify timber and dimensions, and our workshop will build it to your exact specifications.',
        action: {
          type: 'custom_order',
          label: lang === 'hi' ? 'फोटो / डिज़ाइन अपलोड करें' : 'Upload Design Blueprint',
        },
      };
    }
    if (
      lower.includes('दुकान') ||
      lower.includes('पता') ||
      lower.includes('address') ||
      lower.includes('timing') ||
      lower.includes('समय') ||
      lower.includes('कहाँ')
    ) {
      return {
        replyText:
          lang === 'hi'
            ? `हमारी दुकान का पता: ${config.address}, ${config.cityState}।\nखुलने का समय: ${config.timings}।\nफोन: ${config.phone}। आप कभी भी आ सकते हैं!`
            : `Showroom Address: ${config.address}, ${config.cityState}.\nTimings: ${config.timings}.\nPhone: ${config.phone}.`,
        action: { type: 'call', label: lang === 'hi' ? 'दुकान पर कॉल करें' : 'Call Showroom' },
      };
    }
    if (
      lower.includes('चार्ट') ||
      lower.includes('chart') ||
      lower.includes('टेबल') ||
      lower.includes('specs')
    ) {
      return {
        replyText:
          lang === 'hi'
            ? 'हमने लकड़ी की मजबूती, वारंटी और कमरे के साइज का एक संपूर्ण लाइव चार्ट तैयार किया है। आप इसे नीचे दिए बटन से तुरंत देख सकते हैं:'
            : 'We have an interactive Live Wood & Dimension Spec Chart. Tap below to inspect specifications:',
        action: { type: 'chart', label: lang === 'hi' ? '📊 लाइव चार्ट खोलें' : '📊 Open Live Chart' },
      };
    }

    return {
      replyText:
        lang === 'hi'
          ? `धन्यवाद! आपका संदेश शोरूम संचालक (${config.ownerName}) के लाइव चैट पैनल में भेज दिया गया है। वे इसी चैट बॉक्स में आपको सीधा जवाब देंगे।`
          : `Thank you! Your message has been sent directly to our showroom owner (${config.ownerName}) in the live chat panel. They will reply to you right here in this chat.`,
      action: { type: 'custom_order', label: lang === 'hi' ? '📐 कस्टम कोटेशन भेजें' : '📐 Request Custom Quote' },
    };
  };

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text) return;

    const activeName = customerUser?.name || guestName.trim() || (lang === 'hi' ? 'ग्राहक' : 'Customer');
    const activePhone = customerUser?.phone || guestPhone.trim() || '';

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: Date.now(),
      formattedTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputText('');
    setIsTyping(true);

    // Send to In-App Live Chat Backend Session (Owner can view and reply directly)
    const apiRes = await sendChatMessageApi(text, lang, {
      sessionId,
      customerName: activeName,
      customerPhone: activePhone,
      customerEmail: customerUser?.email || '',
    });
    setIsTyping(false);

    if (apiRes && apiRes.session && Array.isArray(apiRes.session.messages)) {
      setMessages(apiRes.session.messages);
      return;
    }

    let replyText = '';
    let action: ChatMessage['suggestedAction'] | undefined;

    if (apiRes && apiRes.reply) {
      replyText = apiRes.reply;
      action = apiRes.suggestedAction;
    } else {
      const fallback = getLocalFallbackReply(text);
      replyText = fallback.replyText;
      action = fallback.action;
    }

    const shopMsg: ChatMessage = {
      id: `shop-${Date.now()}`,
      sender: 'shop',
      text: replyText,
      timestamp: Date.now(),
      formattedTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestedAction: action,
    };

    setMessages((prev) => [...prev, shopMsg]);
  };

  useEffect(() => {
    if (prefillMessage && isOpen) {
      setInputText(prefillMessage);
    }
  }, [prefillMessage, isOpen]);

  const activeDisplayName = customerUser?.name || guestName;

  return (
    <div className="no-print">
      {/* Floating Trigger Button (Bottom Right) */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-40 flex items-center gap-2.5 px-4 py-3 bg-[#8E5327] hover:bg-[#73411C] text-white rounded-full shadow-2xl transition-all duration-300 hover:scale-105 cursor-pointer group border-2 border-white/20"
          title="Live Chat / लाइव चैट"
          aria-label="Open Live Chat"
        >
          <div className="relative">
            <MessageCircle className="w-5 h-5 fill-white" />
            {hasUnread && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping" />
            )}
          </div>
          <span className="font-semibold text-xs sm:text-sm tracking-wide">
            {lang === 'hi' ? 'दुकान लाइव चैट' : 'Live Chat'}
          </span>
          <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
        </button>
      )}

      {/* Floating Live Chat Window */}
      {isOpen && (
        <div className="fixed bottom-2 sm:bottom-6 right-2 sm:right-6 z-50 w-[95vw] sm:w-[385px] h-[535px] max-h-[85vh] bg-white rounded-2xl border border-[#D5C2A5] shadow-2xl flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-300">
          {/* Header */}
          <div className="px-4 py-3 bg-[#2D2319] text-white flex items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="relative w-9 h-9 rounded-full bg-[#8E5327] flex items-center justify-center font-display font-bold text-sm text-white border border-white/20">
                BF
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-400 rounded-full border border-[#2D2319]" />
              </div>
              <div>
                <h4 className="font-bold text-xs sm:text-sm leading-tight text-white">
                  {lang === 'hi' ? 'बाबा फर्नीचर लाइव चैट' : 'Baba Furniture Live Chat'}
                </h4>
                <p className="text-[10px] text-emerald-400 flex items-center gap-1 font-medium">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  <span>
                    {lang === 'hi'
                      ? 'ऑनलाइन · शोरूम संचालक से सीधी चैट'
                      : 'Online · Direct Owner Live Chat'}
                  </span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setShowIdentityBar((p) => !p)}
                className="p-1 text-[#E7D6C4] hover:text-white rounded hover:bg-white/10 text-[11px] font-medium cursor-pointer flex items-center gap-1"
                title={lang === 'hi' ? 'अपना नाम/नंबर जोड़ें' : 'Set your name/phone'}
              >
                <User className="w-3.5 h-3.5" />
                <span className="max-w-[65px] truncate">
                  {activeDisplayName || (lang === 'hi' ? 'परिचय' : 'Profile')}
                </span>
              </button>
              <button
                onClick={onOpenLiveChart}
                className="p-1 text-[#E7D6C4] hover:text-white rounded hover:bg-white/10 text-[11px] font-medium cursor-pointer"
                title="Open Live Specs Chart"
              >
                📊 {lang === 'hi' ? 'चार्ट' : 'Chart'}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 text-[#D5C2A5] hover:text-white rounded hover:bg-white/10 transition-colors cursor-pointer"
                title="Close chat"
              >
                <Minimize2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Optional Customer Identity Bar so Shop Owner knows who they are chatting with */}
          {showIdentityBar && !customerUser && (
            <div className="p-2.5 bg-[#FAF6F0] border-b border-[#E0D5C3] space-y-2 text-xs shrink-0">
              <div className="text-[11px] font-semibold text-[#2D2319]">
                {lang === 'hi'
                  ? 'शोरूम मालिक को अपना नाम व मोबाइल नंबर बताएं:'
                  : 'Share your name & mobile number with the showroom owner:'}
              </div>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  placeholder={lang === 'hi' ? 'आपका नाम' : 'Your Name'}
                  value={guestName}
                  onChange={(e) => {
                    setGuestName(e.target.value);
                    try {
                      localStorage.setItem('bfu_live_chat_name_v2', e.target.value);
                    } catch {}
                  }}
                  className="w-1/2 px-2.5 py-1.5 bg-white border border-[#D5C2A5] rounded text-xs"
                />
                <input
                  type="tel"
                  maxLength={10}
                  placeholder={lang === 'hi' ? 'मोबाइल नंबर' : 'Phone'}
                  value={guestPhone}
                  onChange={(e) => {
                    const clean = e.target.value.replace(/[^0-9]/g, '');
                    setGuestPhone(clean);
                    try {
                      localStorage.setItem('bfu_live_chat_phone_v2', clean);
                    } catch {}
                  }}
                  className="w-1/2 px-2.5 py-1.5 bg-white border border-[#D5C2A5] rounded text-xs"
                />
                <button
                  type="button"
                  onClick={() => setShowIdentityBar(false)}
                  className="px-2.5 py-1.5 bg-[#8E5327] text-white font-bold rounded text-xs cursor-pointer"
                >
                  ✓
                </button>
              </div>
            </div>
          )}

          {/* Quick Info Bar */}
          <div className="px-3 py-1.5 bg-[#FAF6F0] border-b border-[#E8DEC8] flex items-center justify-between text-[11px] text-[#6A5A4A] shrink-0">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-[#8E5327]" />
              <span>{config.timings.split('(')[0]}</span>
            </span>
            <a
              href={`tel:${config.phone.replace(/[^0-9+]/g, '')}`}
              className="text-[#8E5327] hover:underline font-semibold flex items-center gap-1"
            >
              <Phone className="w-3 h-3" />
              <span>{config.phone}</span>
            </a>
          </div>

          {/* Message Stream */}
          <div className="flex-1 p-3.5 overflow-y-auto space-y-3 bg-[#FAF8F5]">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed whitespace-pre-wrap shadow-xs ${
                    msg.sender === 'user'
                      ? 'bg-[#8E5327] text-white rounded-br-xs'
                      : 'bg-white text-[#2D2319] border border-[#E0D5C3] rounded-bl-xs'
                  }`}
                >
                  {msg.text}
                </div>

                {/* Suggested Action Button inside Shop Message (In-App Actions Only, No WhatsApp Redirect) */}
                {msg.suggestedAction && (
                  <div className="mt-1.5">
                    {msg.suggestedAction.type === 'chart' && (
                      <button
                        onClick={() => {
                          setIsOpen(false);
                          onOpenLiveChart();
                        }}
                        className="inline-flex items-center gap-1.5 px-3 py-1 text-[11px] font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-full shadow-xs cursor-pointer"
                      >
                        <span>{msg.suggestedAction.label}</span>
                      </button>
                    )}
                    {msg.suggestedAction.type === 'custom_order' && (
                      <button
                        onClick={() => {
                          setIsOpen(false);
                          onOpenCustomOrder();
                        }}
                        className="inline-flex items-center gap-1 px-3 py-1 text-[11px] font-semibold text-[#2D2319] bg-[#EFE6D8] hover:bg-[#E3D6C1] border border-[#D5C2A5] rounded-full cursor-pointer"
                      >
                        <Sparkles className="w-3 h-3 text-[#8E5327]" />
                        <span>{msg.suggestedAction.label}</span>
                      </button>
                    )}
                    {msg.suggestedAction.type === 'catalog' && (
                      <button
                        onClick={() => {
                          setIsOpen(false);
                          onOpenCatalog();
                        }}
                        className="inline-flex items-center gap-1 px-3 py-1 text-[11px] font-semibold text-[#2D2319] bg-[#EFE6D8] hover:bg-[#E3D6C1] border border-[#D5C2A5] rounded-full cursor-pointer"
                      >
                        <FileText className="w-3 h-3 text-[#8E5327]" />
                        <span>{msg.suggestedAction.label}</span>
                      </button>
                    )}
                    {msg.suggestedAction.type === 'call' && (
                      <a
                        href={`tel:${config.phone.replace(/[^0-9+]/g, '')}`}
                        className="inline-flex items-center gap-1 px-3 py-1 text-[11px] font-semibold text-[#2D2319] bg-[#EFE6D8] border border-[#D5C2A5] rounded-full"
                      >
                        <Phone className="w-3 h-3 text-[#8E5327]" />
                        <span>{msg.suggestedAction.label}</span>
                      </a>
                    )}
                  </div>
                )}

                <span className="text-[10px] text-stone-400 mt-0.5 px-1 flex items-center gap-1">
                  <span>{msg.formattedTime}</span>
                  {msg.sender === 'user' && <CheckCheck className="w-3 h-3 text-[#8E5327]" />}
                </span>
              </div>
            ))}

            {isTyping && (
              <div className="flex items-start">
                <div className="bg-white border border-[#E0D5C3] text-[#6A5A4A] rounded-2xl rounded-bl-xs px-3.5 py-2 text-xs">
                  {lang === 'hi' ? 'शोरूम से जुड़ रहे हैं...' : 'Sending to showroom...'}
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Suggested Quick Question Chips */}
          <div className="p-2 bg-white border-t border-[#E8DEC8] flex items-center gap-1.5 overflow-x-auto scrollbar-none shrink-0">
            {(lang === 'hi' ? QUICK_QUESTIONS_HI : QUICK_QUESTIONS_EN).map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(q)}
                className="px-2.5 py-1 text-[11px] bg-[#FAF6F0] hover:bg-[#F2ECE1] text-[#4A3E33] border border-[#E0D5C3] rounded-full whitespace-nowrap shrink-0 transition-colors cursor-pointer"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Text Input Area */}
          <div className="p-2.5 bg-white border-t border-[#E8DEC8] flex items-center gap-2 shrink-0">
            <input
              type="text"
              placeholder={
                lang === 'hi'
                  ? 'शोरूम मालिक को सीधा संदेश लिखें...'
                  : 'Message the showroom owner directly...'
              }
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSend();
              }}
              className="flex-1 px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C2A5] rounded-full focus:outline-none focus:ring-1 focus:ring-[#8E5327] text-[#2D2319]"
            />
            <button
              onClick={() => handleSend()}
              className="p-2 bg-[#8E5327] hover:bg-[#73411C] text-white rounded-full transition-colors cursor-pointer shrink-0"
              title="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>

          {/* Bottom Direct Contact */}
          <div className="px-3 py-1.5 bg-[#F2ECE1] flex items-center justify-between text-[10px] text-[#5A4D40] shrink-0 border-t border-[#E8DEC8]">
            <span>
              {lang === 'hi'
                ? 'इन-ऐप लाइव चैट · सीधे शोरूम पैनल से जुड़ा'
                : 'In-App Live Chat · Connected to Showroom Panel'}
            </span>
            <a
              href={`tel:${config.phone.replace(/[^0-9+]/g, '')}`}
              className="font-bold text-[#8E5327] hover:underline flex items-center gap-1"
            >
              <Phone className="w-2.5 h-2.5" />
              <span>{config.phone}</span>
            </a>
          </div>
        </div>
      )}
    </div>
  );
};
