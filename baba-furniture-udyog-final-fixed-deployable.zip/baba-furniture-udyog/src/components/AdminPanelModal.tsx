import React, { useState, useEffect } from 'react';
import {
  AdminInvitation,
  AdminProfile,
  AdminRole,
  AuthMethodsConfig,
  CustomerInquiry,
  FurnitureCategory,
  LiveChatSession,
  Product,
  ShowroomConfig,
  WoodType,
} from '../types/furniture';
import { DEFAULT_OWNER_ADMIN_PROFILE } from '../data/initialFurniture';
import { exportInquiriesToCsv, normalizeWhatsAppNumber } from '../utils/furnitureLogic';
import {
  clearSavedAdminSession,
  createAdminTeamMemberApi,
  fetchAdminChatsApi,
  fetchAdminTeamApi,
  replyAdminChatApi,
  fetchAuthMethodsConfigApi,
  getSavedAdminProfile,
  getSavedAdminToken,
  inviteAdminApi,
  loginOwnerAdminApi,
  revokeAdminApi,
  revokeInvitationApi,
  SupabaseStatusInfo,
  toggleAdminMfaApi,
  updateAuthMethodsConfigApi,
  updateOwnerAdminProfileApi,
  verifyAdminMfaApi,
} from '../services/api';
import { getStoredSupabaseConfig } from '../lib/supabase';
import {
  X,
  Lock,
  Plus,
  Trash2,
  Edit,
  Download,
  MessageSquare,
  Phone,
  Save,
  RotateCcw,
  Upload,
  Package,
  Users,
  Settings,
  AlertTriangle,
  ShieldCheck,
  Database,
  LogOut,
  Eye,
  EyeOff,
  UserCheck,
  KeyRound,
  Shield,
  UserPlus,
  Mail,
  ToggleLeft,
  ToggleRight,
  CheckCircle2,
  Clock,
  ExternalLink,
} from 'lucide-react';

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: ShowroomConfig;
  onUpdateConfig: (newConfig: ShowroomConfig) => void;
  products: Product[];
  onAddProduct: (prod: Product) => void;
  onUpdateProduct: (prod: Product) => void;
  onDeleteProduct: (id: string) => void;
  inquiries: CustomerInquiry[];
  onUpdateInquiryStatus: (id: string, status: CustomerInquiry['status']) => void;
  onDeleteInquiry?: (id: string) => void;
  onResetDemoData: () => void;
  supabaseStatus?: SupabaseStatusInfo;
  lang: 'hi' | 'en';
}

type AdminTab = 'products' | 'inquiries' | 'chats' | 'settings' | 'team' | 'auth_methods' | 'security';

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  config,
  onUpdateConfig,
  products,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  inquiries,
  onUpdateInquiryStatus,
  onDeleteInquiry,
  onResetDemoData,
  supabaseStatus,
  lang,
}) => {
  // Authentication & Role State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() =>
    Boolean(getSavedAdminToken())
  );
  const [adminProfile, setAdminProfile] = useState<AdminProfile>(() =>
    getSavedAdminProfile(DEFAULT_OWNER_ADMIN_PROFILE)
  );

  // Login form state
  const [selectedLoginRole, setSelectedLoginRole] = useState<AdminRole>('app_admin');
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Live Customer Chats state (In-App Chat Reply)
  const [chatSessions, setChatSessions] = useState<LiveChatSession[]>([]);
  const [activeChatSessionId, setActiveChatSessionId] = useState<string>('');
  const [adminReplyInput, setAdminReplyInput] = useState('');
  const [isSendingReply, setIsSendingReply] = useState(false);

  // Direct Team Account Creation state (App Admin only)
  const [inviteFullName, setInviteFullName] = useState('');
  const [invitePassword, setInvitePassword] = useState('');

  // MFA 2-Step Challenge State
  const [mfaRequired, setMfaRequired] = useState(false);
  const [mfaChallengeId, setMfaChallengeId] = useState('');
  const [mfaCode, setMfaCode] = useState('');
  const [mfaError, setMfaError] = useState('');
  const [isVerifyingMfa, setIsVerifyingMfa] = useState(false);

  // Active sub-tab
  const [activeTab, setActiveTab] = useState<AdminTab>('products');

  // Admin Team & Invitations state (Application Admin only)
  const [adminTeam, setAdminTeam] = useState<AdminProfile[]>([]);
  const [invitations, setInvitations] = useState<AdminInvitation[]>([]);
  const [isLoadingTeam, setIsLoadingTeam] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<AdminRole>('shop_owner');
  const [isInviting, setIsInviting] = useState(false);
  const [inviteSuccessMsg, setInviteSuccessMsg] = useState('');
  const [inviteErrorMsg, setInviteErrorMsg] = useState('');

  // Customer Auth Methods Configuration (Application Admin only)
  const [authConfig, setAuthConfig] = useState<AuthMethodsConfig>({
    emailPasswordEnabled: true,
    emailOtpEnabled: true,
    googleAuthEnabled: true,
    phoneOtpEnabled: false,
    whatsappOtpEnabled: false,
  });
  const [isSavingAuthConfig, setIsSavingAuthConfig] = useState(false);
  const [authConfigMsg, setAuthConfigMsg] = useState('');

  // Security & Password change state
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
  const [passMsg, setPassMsg] = useState('');
  const [passError, setPassError] = useState('');
  const [isTogglingMfa, setIsTogglingMfa] = useState(false);

  // In-UI Confirmation states
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [confirmDeleteInqId, setConfirmDeleteInqId] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  // Product form state
  const [isEditingProduct, setIsEditingProduct] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formTitle, setFormTitle] = useState('');
  const [formTitleHi, setFormTitleHi] = useState('');
  const [formCategory, setFormCategory] = useState<FurnitureCategory>('beds');
  const [formWoodType, setFormWoodType] = useState<WoodType>('Solid Teak (सागवान)');
  const [formDimensions, setFormDimensions] = useState('78"L x 72"W x 48"H (King)');
  const [formFinish, setFormFinish] = useState('Natural Teak Gloss, Dark Walnut');
  const [formPrice, setFormPrice] = useState(35000);
  const [formMrp, setFormMrp] = useState(42000);
  const [formHidePrice, setFormHidePrice] = useState(false);
  const [formWarranty, setFormWarranty] = useState(10);
  const [formInStock, setFormInStock] = useState(true);
  const [formIsFeatured, setFormIsFeatured] = useState(false);
  const [formImageUrl, setFormImageUrl] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formDescriptionHi, setFormDescriptionHi] = useState('');
  const [formFeaturesHi, setFormFeaturesHi] = useState('');
  const [productFilter, setProductFilter] = useState<string>('all');

  // Showroom settings form state
  const [settingsForm, setSettingsForm] = useState<ShowroomConfig>(config);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    setSettingsForm(config);
  }, [config]);

  // Load team, auth methods & poll live customer chats when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      fetchAuthMethodsConfigApi().then((cfg) => setAuthConfig(cfg));
      if (adminProfile.role === 'app_admin') {
        loadTeamData();
      }
      const loadChats = async () => {
        const list = await fetchAdminChatsApi();
        setChatSessions(list);
        if (!activeChatSessionId && list.length > 0) {
          setActiveChatSessionId(list[0].id);
        }
      };
      loadChats();
      const timer = setInterval(loadChats, 3500);
      return () => clearInterval(timer);
    }
  }, [isAuthenticated, adminProfile.role, activeChatSessionId]);

  const loadTeamData = async () => {
    setIsLoadingTeam(true);
    const data = await fetchAdminTeamApi();
    if (data.admins) setAdminTeam(data.admins);
    if (data.invitations) setInvitations(data.invitations);
    setIsLoadingTeam(false);
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  if (!isOpen) return null;

  // Handle Admin Login Submission
  const handleAdminLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setIsLoggingIn(true);

    try {
      const result = await loginOwnerAdminApi(
        loginIdentifier,
        loginPassword,
        adminProfile,
        selectedLoginRole
      );

      if (result.mfaRequired && result.challengeId) {
        setMfaRequired(true);
        setMfaChallengeId(result.challengeId);
        setIsLoggingIn(false);
        return;
      }

      if (result.authenticated && result.admin) {
        setIsAuthenticated(true);
        setAdminProfile(result.admin);
        setLoginPassword('');
        setLoginIdentifier('');
        setMfaRequired(false);
        showToast(
          lang === 'hi'
            ? `स्वागत है, ${result.admin.ownerName}! (${result.admin.role === 'app_admin' ? 'Application Admin' : 'Shop Owner'})`
            : `Welcome, ${result.admin.ownerName}! (${result.admin.role === 'app_admin' ? 'Application Admin' : 'Shop Owner'})`
        );
      } else {
        setLoginError(
          result.error ||
            (lang === 'hi'
              ? 'अमान्य एडमिन ईमेल या पासवर्ड।'
              : 'Invalid Owner Email or Password.')
        );
      }
    } catch {
      setLoginError(
        lang === 'hi'
          ? 'सर्वर से संपर्क करने में असमर्थ। कृपया बाद में प्रयास करें।'
          : 'Unable to contact authentication server.'
      );
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Handle MFA 2-Step Verification Code Submission
  const handleMfaSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMfaError('');
    setIsVerifyingMfa(true);

    try {
      const res = await verifyAdminMfaApi(mfaChallengeId, mfaCode);
      if (res.authenticated && res.admin) {
        setIsAuthenticated(true);
        setAdminProfile(res.admin);
        setMfaRequired(false);
        setMfaCode('');
        setMfaChallengeId('');
        showToast(
          lang === 'hi'
            ? `2-स्टेप सत्यापन सफल! स्वागत है, ${res.admin.ownerName}`
            : `2-Step verification successful! Welcome, ${res.admin.ownerName}`
        );
      } else {
        setMfaError(res.error || (lang === 'hi' ? 'अमान्य 2-स्टेप कोड।' : 'Invalid 2-step verification code.'));
      }
    } catch {
      setMfaError(lang === 'hi' ? 'सत्यापन अनुरोध विफल रहा।' : 'Verification request failed.');
    } finally {
      setIsVerifyingMfa(false);
    }
  };

  // Handle Logout
  const handleAdminLogout = () => {
    clearSavedAdminSession();
    setIsAuthenticated(false);
    setMfaRequired(false);
    setMfaCode('');
    setLoginPassword('');
    setActiveTab('products');
    showToast(lang === 'hi' ? 'सफलतापूर्वक लॉगआउट किया गया।' : 'Successfully logged out.');
  };

  // Handle Invite New Admin (App Admin only)
  const handleInviteAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setInviteErrorMsg('');
    setInviteSuccessMsg('');
    if (!inviteEmail || !inviteEmail.includes('@')) {
      setInviteErrorMsg(lang === 'hi' ? 'कृपया वैध ईमेल पता भरें।' : 'Please enter a valid email.');
      return;
    }
    setIsInviting(true);

    if (invitePassword.trim().length >= 6) {
      const createRes = await createAdminTeamMemberApi({
        email: inviteEmail,
        fullName: inviteFullName || (inviteRole === 'app_admin' ? 'Application Admin' : 'Shop Owner'),
        password: invitePassword.trim(),
        role: inviteRole,
      });
      setIsInviting(false);
      if (createRes.success) {
        setInviteSuccessMsg(
          createRes.message ||
            (lang === 'hi'
              ? `खाता सफलतापूर्वक बनाया गया! (${inviteRole === 'app_admin' ? 'Application Admin' : 'Shop Owner'})`
              : `Account created for ${inviteEmail}!`)
        );
        setInviteEmail('');
        setInviteFullName('');
        setInvitePassword('');
        loadTeamData();
      } else {
        setInviteErrorMsg(createRes.error || 'खाता बनाने में त्रुटि हुई।');
      }
      return;
    }

    const res = await inviteAdminApi(inviteEmail, inviteRole);
    setIsInviting(false);
    if (res.success) {
      setInviteSuccessMsg(
        lang === 'hi'
          ? `आमंत्रण सफलतापूर्वक भेजा गया! (${inviteRole === 'app_admin' ? 'Application Admin' : 'Shop Owner'})`
          : `Invitation sent successfully to ${inviteEmail}!`
      );
      setInviteEmail('');
      loadTeamData();
    } else {
      setInviteErrorMsg(res.error || (lang === 'hi' ? 'आमंत्रण भेजने में विफल।' : 'Failed to send invitation.'));
    }
  };

  // Handle Revoke Invitation
  const handleRevokeInvitation = async (id: string) => {
    const res = await revokeInvitationApi(id);
    if (res.success) {
      showToast(lang === 'hi' ? 'आमंत्रण रद्द किया गया।' : 'Invitation revoked.');
      loadTeamData();
    }
  };

  // Handle Revoke Admin User
  const handleRevokeAdmin = async (id: string, name: string) => {
    const res = await revokeAdminApi(id);
    if (res.success) {
      showToast(lang === 'hi' ? `${name} का एडमिन अधिकार हटा दिया गया।` : `Admin revoked for ${name}.`);
      loadTeamData();
    } else {
      showToast(res.error || 'त्रुटि हुई।');
    }
  };

  // Handle Toggle MFA
  const handleToggleMfa = async () => {
    setIsTogglingMfa(true);
    const nextState = !adminProfile.mfaEnabled;
    const res = await toggleAdminMfaApi(nextState);
    setIsTogglingMfa(false);
    if (res.success) {
      setAdminProfile({ ...adminProfile, mfaEnabled: nextState });
      showToast(
        nextState
          ? (lang === 'hi' ? '2-स्टेप सत्यापन (MFA) सक्रिय किया गया।' : '2-Step Verification (MFA) enabled.')
          : (lang === 'hi' ? '2-स्टेप सत्यापन (MFA) निष्क्रिय किया गया।' : '2-Step Verification (MFA) disabled.')
      );
    } else {
      showToast(res.error || 'MFA सेटिंग अपडेट नहीं हो सकी।');
    }
  };

  // Handle Password Change
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassError('');
    setPassMsg('');

    if (newPasswordInput.length < 8) {
      setPassError(lang === 'hi' ? 'नया पासवर्ड कम से कम 8 अक्षरों का होना चाहिए।' : 'New password must be at least 8 characters.');
      return;
    }
    if (newPasswordInput !== confirmPasswordInput) {
      setPassError(lang === 'hi' ? 'दोनों पासवर्ड मेल नहीं खाते।' : 'Passwords do not match.');
      return;
    }

    const res = await updateOwnerAdminProfileApi({
      email: adminProfile.email,
      phone: adminProfile.phone || '',
      username: adminProfile.username || '',
      ownerName: adminProfile.ownerName,
      role: adminProfile.role,
      newPassword: newPasswordInput,
    });

    if (res.error) {
      setPassError(res.error);
    } else {
      setPassMsg(lang === 'hi' ? 'पासवर्ड सफलतापूर्वक बदल दिया गया!' : 'Password updated successfully!');
      setNewPasswordInput('');
      setConfirmPasswordInput('');
    }
  };

  // Handle Auth Methods Config Save
  const handleSaveAuthConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingAuthConfig(true);
    setAuthConfigMsg('');

    const res = await updateAuthMethodsConfigApi(authConfig);
    setIsSavingAuthConfig(false);
    if (res.success && res.authMethodsConfig) {
      setAuthConfig(res.authMethodsConfig);
      setAuthConfigMsg(lang === 'hi' ? 'लॉगिन विधियां सफलतापूर्वक अपडेट की गईं!' : 'Auth methods updated successfully!');
      showToast(lang === 'hi' ? 'ग्राहक लॉगिन सेटिंग्स सहेजी गईं।' : 'Customer auth settings saved.');
    } else {
      setAuthConfigMsg(res.error || 'अपडेट विफल रहा।');
    }
  };

  // Product CRUD
  const handleResetProductForm = () => {
    setIsEditingProduct(false);
    setEditingId(null);
    setFormTitle('');
    setFormTitleHi('');
    setFormCategory('beds');
    setFormWoodType('Solid Teak (सागवान)');
    setFormDimensions('78"L x 72"W x 48"H (King)');
    setFormFinish('Natural Teak Gloss, Dark Walnut');
    setFormPrice(35000);
    setFormMrp(42000);
    setFormHidePrice(false);
    setFormWarranty(10);
    setFormInStock(true);
    setFormIsFeatured(false);
    setFormImageUrl('');
    setFormDescription('');
    setFormDescriptionHi('');
    setFormFeaturesHi('');
  };

  const handleEditProductClick = (prod: Product) => {
    setIsEditingProduct(true);
    setEditingId(prod.id);
    setFormTitle(prod.title);
    setFormTitleHi(prod.titleHi || prod.title);
    setFormCategory(prod.category);
    setFormWoodType(prod.woodType as WoodType);
    setFormDimensions(prod.dimensions);
    setFormFinish((prod.finishOptions || []).join(', '));
    setFormPrice(prod.price || 35000);
    setFormMrp(prod.mrp || 42000);
    setFormHidePrice(Boolean(prod.hidePrice));
    setFormWarranty(prod.warrantyYears);
    setFormInStock(prod.inStock);
    setFormIsFeatured(prod.isFeatured);
    setFormImageUrl(prod.imageUrl);
    setFormDescription(prod.description);
    setFormDescriptionHi(prod.descriptionHi || prod.description);
    setFormFeaturesHi((prod.featuresHi || prod.features || []).join(', '));
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const finishArray = formFinish.split(',').map((s) => s.trim()).filter(Boolean);
    const featuresArray = formFeaturesHi.split(',').map((s) => s.trim()).filter(Boolean);

    const productPayload: Product = {
      id: editingId || `prod-${Date.now()}`,
      sku: editingId ? (products.find((p) => p.id === editingId)?.sku || `BFU-${Date.now().toString().slice(-4)}`) : `BFU-${Date.now().toString().slice(-4)}`,
      title: formTitle.trim(),
      titleHi: formTitleHi.trim() || formTitle.trim(),
      category: formCategory,
      categoryLabel: formCategory.toUpperCase(),
      categoryLabelHi: formCategory,
      woodType: formWoodType,
      dimensions: formDimensions.trim(),
      price: Number(formPrice) || 35000,
      mrp: Number(formMrp) || 42000,
      hidePrice: Boolean(formHidePrice),
      finishOptions: finishArray.length > 0 ? finishArray : ['Natural Teak Gloss'],
      features: featuresArray.length > 0 ? featuresArray : ['100% Solid Seasoned Timber'],
      featuresHi: featuresArray.length > 0 ? featuresArray : ['100% शुद्ध दीमक-प्रूफ लकड़ी'],
      imageUrl: formImageUrl.trim() || '/src/assets/images/hero_luxury_furniture_1792942317776.jpg',
      description: formDescription.trim(),
      descriptionHi: formDescriptionHi.trim() || formDescription.trim(),
      warrantyYears: Number(formWarranty) || 10,
      isFeatured: formIsFeatured,
      inStock: formInStock,
    };

    if (editingId) {
      onUpdateProduct(productPayload);
      showToast(lang === 'hi' ? 'उत्पाद सफलतापूर्वक अपडेट हुआ!' : 'Product updated successfully!');
    } else {
      onAddProduct(productPayload);
      showToast(lang === 'hi' ? 'नया उत्पाद जोड़ा गया!' : 'New product added!');
    }
    handleResetProductForm();
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateConfig(settingsForm);
    showToast(lang === 'hi' ? 'शोरूम सेटिंग्स सहेज ली गईं!' : 'Showroom settings saved!');
  };

  const filteredProducts = products.filter((p) => {
    if (productFilter === 'all') return true;
    return p.category === productFilter;
  });

  const isAppAdmin = adminProfile.role === 'app_admin';
  const sbConfig = getStoredSupabaseConfig();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-5xl h-[92vh] max-h-[900px] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-[#D5C2A5]">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#2D2319] text-[#FAF8F5] border-b border-[#3D3023]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#8E5327] text-white">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display text-lg font-bold">
                  {lang === 'hi' ? 'बाबा फर्नीचर — अधिकृत एडमिन कंट्रोल' : 'Baba Furniture — Admin Portal'}
                </h2>
                {isAuthenticated && (
                  <span
                    className={`px-2.5 py-0.5 text-[11px] font-bold rounded-full ${
                      isAppAdmin
                        ? 'bg-purple-900/80 text-purple-200 border border-purple-500'
                        : 'bg-amber-900/80 text-amber-200 border border-amber-500'
                    }`}
                  >
                    {isAppAdmin ? '🛡️ Application Admin' : '👑 Shop Owner'}
                  </span>
                )}
                {isAuthenticated && (
                  <span
                    className={`px-2 py-0.5 text-[10px] font-semibold rounded ${
                      adminProfile.mfaEnabled
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                        : 'bg-stone-800 text-stone-400'
                    }`}
                  >
                    {adminProfile.mfaEnabled ? '🟢 2FA Active' : '⚪ 2FA Off'}
                  </span>
                )}
              </div>
              <p className="text-xs text-[#D5C2A5]/80">
                {isAuthenticated
                  ? `${adminProfile.ownerName} (${adminProfile.email})`
                  : lang === 'hi'
                  ? 'सुरक्षित Supabase RBAC प्रमाणीकरण'
                  : 'Secure Supabase RBAC Authentication'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAuthenticated && (
              <button
                type="button"
                onClick={handleAdminLogout}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-200 hover:text-white bg-rose-950/60 hover:bg-rose-900 border border-rose-800 rounded-lg transition-colors cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{lang === 'hi' ? 'लॉगआउट' : 'Sign Out'}</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-[#D5C2A5] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Toast Notification */}
        {toastMessage && (
          <div className="absolute top-16 right-6 z-50 bg-[#2D2319] text-[#FAF8F5] px-4 py-2.5 rounded-lg shadow-xl text-xs font-medium border border-[#8E5327] flex items-center gap-2 animate-bounce">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* NOT AUTHENTICATED: SECURE LOGIN FORM */}
        {!isAuthenticated ? (
          <div className="flex-1 flex items-center justify-center p-6 bg-[#FAF8F5] overflow-y-auto">
            <div className="w-full max-w-md bg-white p-8 rounded-2xl shadow-lg border border-[#E8DEC8] space-y-6">
              
              {!mfaRequired ? (
                // Step 1: Username/Email & Password Login
                <>
                  <div className="text-center space-y-2">
                    <div className="w-12 h-12 mx-auto rounded-full bg-[#FAF6F0] border border-[#D5C2A5] flex items-center justify-center text-[#8E5327]">
                      <Lock className="w-6 h-6" />
                    </div>
                    <h3 className="font-display text-xl font-bold text-[#2D2319]">
                      {lang === 'hi' ? 'व्यवस्थापक लॉगिन' : 'Administrator Sign In'}
                    </h3>
                    <p className="text-xs text-[#6A5A4A]">
                      {lang === 'hi'
                        ? 'दुकान संचालक (Shop Owner) या सिस्टम एडमिनिस्ट्रेटर (App Admin) क्रेडेंशियल से लॉगिन करें।'
                        : 'Sign in with your authorized Shop Owner or Application Admin account.'}
                    </p>
                  </div>

                  {loginError && (
                    <div className="p-3 text-xs font-medium text-rose-800 bg-rose-50 border border-rose-200 rounded-lg flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      <span>{loginError}</span>
                    </div>
                  )}

                  {/* Role Selector: Application Admin vs Shop Owner */}
                  <div className="grid grid-cols-2 gap-2 p-1 bg-[#FAF6F0] border border-[#D5C2A5] rounded-xl">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedLoginRole('app_admin');
                        setLoginError('');
                      }}
                      className={`py-2 px-3 rounded-lg text-xs font-bold transition cursor-pointer ${
                        selectedLoginRole === 'app_admin'
                          ? 'bg-[#2D2319] text-[#FDE68A] shadow-xs'
                          : 'text-[#6A5A4A] hover:text-[#2D2319]'
                      }`}
                    >
                      🛡️ {lang === 'hi' ? 'मुख्य एडमिन (App Admin)' : 'Application Admin'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedLoginRole('shop_owner');
                        setLoginError('');
                      }}
                      className={`py-2 px-3 rounded-lg text-xs font-bold transition cursor-pointer ${
                        selectedLoginRole === 'shop_owner'
                          ? 'bg-[#8E5327] text-white shadow-xs'
                          : 'text-[#6A5A4A] hover:text-[#2D2319]'
                      }`}
                    >
                      👑 {lang === 'hi' ? 'दुकान मालिक (Shop Owner)' : 'Shop Owner'}
                    </button>
                  </div>

                  <form onSubmit={handleAdminLoginSubmit} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                        {selectedLoginRole === 'app_admin'
                          ? lang === 'hi'
                            ? 'मुख्य प्रशासक ईमेल (App Admin Email) *'
                            : 'App Admin Email *'
                          : lang === 'hi'
                          ? 'दुकान संचालक ईमेल (Shop Owner Email) *'
                          : 'Shop Owner Email *'}
                      </label>
                      <input
                        type="email"
                        required
                        placeholder={
                          selectedLoginRole === 'app_admin'
                            ? 'vikashchaurasia9517@gmail.com'
                            : 'owner@babafurnitureudyog.com'
                        }
                        value={loginIdentifier}
                        onChange={(e) => setLoginIdentifier(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D5C2A5] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8E5327]"
                        autoFocus
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                        {lang === 'hi' ? 'पासवर्ड (Password) *' : 'Password *'}
                      </label>
                      <div className="relative">
                        <input
                          type={showPassword ? 'text' : 'password'}
                          required
                          placeholder="••••••••••••"
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          className="w-full px-3.5 py-2.5 pr-10 text-sm bg-[#FAF8F5] border border-[#D5C2A5] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8E5327]"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-500 hover:text-stone-800 cursor-pointer"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isLoggingIn}
                      className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-lg shadow-md transition-colors cursor-pointer disabled:opacity-50"
                    >
                      {isLoggingIn
                        ? (lang === 'hi' ? 'सत्यापित किया जा रहा है...' : 'Authenticating...')
                        : (lang === 'hi' ? 'सुरक्षित लॉगिन करें (Sign In)' : 'Sign In')}
                    </button>
                  </form>

                  <div className="pt-3 border-t border-[#E8DEC8] text-center">
                    <p className="text-[11px] text-[#6A5A4A] leading-relaxed">
                      🔒 <strong>सुरक्षित Supabase RBAC</strong>: पहला व्यवस्थापक खाता सर्वर CLI (<code className="bg-stone-100 px-1 py-0.5 rounded font-mono">npm run provision:admin</code>) या Supabase Auth द्वारा सुरक्षित रूप से बनाया जाता है।
                    </p>
                  </div>
                </>
              ) : (
                // Step 2: MFA 2-Step Verification Code
                <>
                  <div className="text-center space-y-2">
                    <div className="w-12 h-12 mx-auto rounded-full bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <h3 className="font-display text-xl font-bold text-[#2D2319]">
                      {lang === 'hi' ? '2-स्टेप सत्यापन (MFA)' : '2-Step Verification (MFA)'}
                    </h3>
                    <p className="text-xs text-[#6A5A4A]">
                      {lang === 'hi'
                        ? 'आपके व्यवस्थापक खाते पर 2FA सक्रिय है। कृपया 6-अंकों का सत्यापन कोड दर्ज करें।'
                        : '2-Step verification is required. Enter the 6-digit challenge code.'}
                    </p>
                  </div>

                  {mfaError && (
                    <div className="p-3 text-xs font-medium text-rose-800 bg-rose-50 border border-rose-200 rounded-lg">
                      {mfaError}
                    </div>
                  )}

                  <form onSubmit={handleMfaSubmit} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#2D2319] mb-1 text-center">
                        {lang === 'hi' ? '6-अंकों का सत्यापन कोड' : '6-Digit Verification Code'}
                      </label>
                      <input
                        type="text"
                        maxLength={6}
                        required
                        placeholder="123456"
                        value={mfaCode}
                        onChange={(e) => setMfaCode(e.target.value.replace(/[^0-9]/g, ''))}
                        className="w-full px-4 py-3 text-center text-xl font-mono tracking-widest bg-[#FAF8F5] border border-[#D5C2A5] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8E5327]"
                        autoFocus
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setMfaRequired(false);
                          setMfaCode('');
                        }}
                        className="w-1/3 py-2.5 px-3 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg cursor-pointer"
                      >
                        {lang === 'hi' ? 'रद्द करें' : 'Back'}
                      </button>
                      <button
                        type="submit"
                        disabled={isVerifyingMfa || mfaCode.length !== 6}
                        className="w-2/3 py-2.5 px-4 text-xs font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-lg shadow-md transition-colors cursor-pointer disabled:opacity-50"
                      >
                        {isVerifyingMfa
                          ? (lang === 'hi' ? 'जाँच हो रही है...' : 'Verifying...')
                          : (lang === 'hi' ? 'कोड सत्यापित करें' : 'Verify & Sign In')}
                      </button>
                    </div>
                  </form>
                </>
              )}

            </div>
          </div>
        ) : (
          // AUTHENTICATED: ROLE-BASED ADMIN TABS & MANAGEMENT
          <div className="flex-1 flex flex-col overflow-hidden bg-white">
            
            {/* Sub-Tabs Bar */}
            <div className="flex items-center gap-1 px-6 bg-[#FAF6F0] border-b border-[#E8DEC8] overflow-x-auto shrink-0">
              <button
                type="button"
                onClick={() => setActiveTab('products')}
                className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'products'
                    ? 'border-[#8E5327] text-[#8E5327] bg-white'
                    : 'border-transparent text-[#6A5A4A] hover:text-[#2D2319]'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>{lang === 'hi' ? 'उत्पाद सूची (Products)' : 'Products & Catalog'}</span>
                <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-[#E8DEC8] text-[#2D2319]">
                  {products.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('inquiries')}
                className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'inquiries'
                    ? 'border-[#8E5327] text-[#8E5327] bg-white'
                    : 'border-transparent text-[#6A5A4A] hover:text-[#2D2319]'
                }`}
              >
                <MessageSquare className="w-4 h-4" />
                <span>{lang === 'hi' ? 'ग्राहक पूछताछ (Inquiries)' : 'Customer Inquiries'}</span>
                {inquiries.filter((i) => i.status === 'new').length > 0 && (
                  <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-red-600 text-white font-bold">
                    {inquiries.filter((i) => i.status === 'new').length}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('chats')}
                className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'chats'
                    ? 'border-[#8E5327] text-[#8E5327] bg-white'
                    : 'border-transparent text-[#6A5A4A] hover:text-[#2D2319]'
                }`}
              >
                <MessageSquare className="w-4 h-4 text-emerald-700" />
                <span>{lang === 'hi' ? 'ग्राहक लाइव चैट (Live Chats)' : 'Live Customer Chats'}</span>
                {chatSessions.reduce((acc, s) => acc + (s.unreadForAdmin || 0), 0) > 0 && (
                  <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-600 text-white font-bold">
                    {chatSessions.reduce((acc, s) => acc + (s.unreadForAdmin || 0), 0)}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('settings')}
                className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'settings'
                    ? 'border-[#8E5327] text-[#8E5327] bg-white'
                    : 'border-transparent text-[#6A5A4A] hover:text-[#2D2319]'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>{lang === 'hi' ? 'शोरूम प्रोफ़ाइल (Showroom)' : 'Showroom Profile'}</span>
              </button>

              {/* APPLICATION ADMIN ONLY TABS */}
              {isAppAdmin && (
                <>
                  <button
                    type="button"
                    onClick={() => setActiveTab('team')}
                    className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                      activeTab === 'team'
                        ? 'border-purple-600 text-purple-700 bg-white'
                        : 'border-transparent text-purple-900/70 hover:text-purple-900'
                    }`}
                  >
                    <Users className="w-4 h-4 text-purple-600" />
                    <span>{lang === 'hi' ? 'एडमिन टीम व आमंत्रण' : 'Admin Team & Invites'}</span>
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-purple-100 text-purple-700">
                      Admin Only
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('auth_methods')}
                    className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                      activeTab === 'auth_methods'
                        ? 'border-purple-600 text-purple-700 bg-white'
                        : 'border-transparent text-purple-900/70 hover:text-purple-900'
                    }`}
                  >
                    <KeyRound className="w-4 h-4 text-purple-600" />
                    <span>{lang === 'hi' ? 'लॉगिन विधियां सेटिंग्स' : 'Customer Auth Methods'}</span>
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-purple-100 text-purple-700">
                      Admin Only
                    </span>
                  </button>
                </>
              )}

              <button
                type="button"
                onClick={() => setActiveTab('security')}
                className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'security'
                    ? 'border-[#8E5327] text-[#8E5327] bg-white'
                    : 'border-transparent text-[#6A5A4A] hover:text-[#2D2319]'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{lang === 'hi' ? 'सुरक्षा व 2-स्टेप सत्यापन' : 'Security & MFA'}</span>
              </button>
            </div>

            {/* TAB 1: PRODUCTS & CATALOG */}
            {activeTab === 'products' && (
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#E8DEC8]">
                  <div>
                    <h3 className="font-display text-lg font-bold text-[#2D2319]">
                      {lang === 'hi' ? 'फर्नीचर उत्पाद एवं मूल्य प्रबंधन' : 'Furniture Products & Pricing'}
                    </h3>
                    <p className="text-xs text-[#6A5A4A]">
                      {lang === 'hi'
                        ? 'नए मॉडल जोड़ें, कीमतें व स्टॉक स्थिति बदलें'
                        : 'Manage solid wood catalog, prices, and showroom stock availability'}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <select
                      value={productFilter}
                      onChange={(e) => setProductFilter(e.target.value)}
                      className="px-3 py-1.5 text-xs bg-white border border-[#D5C2A5] rounded-lg"
                    >
                      <option value="all">{lang === 'hi' ? 'सभी श्रेणियां (All)' : 'All Categories'}</option>
                      <option value="beds">{lang === 'hi' ? 'पलंग / बेड (Beds)' : 'Beds'}</option>
                      <option value="sofas">{lang === 'hi' ? 'सोफा सेट (Sofas)' : 'Sofas'}</option>
                      <option value="dining">{lang === 'hi' ? 'डाइनिंग सेट (Dining)' : 'Dining'}</option>
                      <option value="mandir">{lang === 'hi' ? 'मंदिर (Mandir)' : 'Mandir'}</option>
                      <option value="wardrobes">{lang === 'hi' ? 'अलमारी (Wardrobes)' : 'Wardrobes'}</option>
                      <option value="dressing">{lang === 'hi' ? 'ड्रेसिंग (Dressing)' : 'Dressing'}</option>
                    </select>

                    <button
                      type="button"
                      onClick={() => {
                        handleResetProductForm();
                        setIsEditingProduct(true);
                      }}
                      className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-lg shadow-sm cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{lang === 'hi' ? 'नया उत्पाद जोड़ें' : 'Add New Product'}</span>
                    </button>
                  </div>
                </div>

                {/* Inline Product Add/Edit Form */}
                {isEditingProduct && (
                  <form onSubmit={handleSaveProduct} className="p-5 bg-[#FAF6F0] rounded-xl border border-[#D5C2A5] space-y-4">
                    <div className="flex items-center justify-between pb-2 border-b border-[#E0D5C3]">
                      <h4 className="font-bold text-sm text-[#2D2319]">
                        {editingId
                          ? (lang === 'hi' ? 'उत्पाद विवरण संपादित करें' : 'Edit Product Details')
                          : (lang === 'hi' ? 'नया फर्नीचर उत्पाद जोड़ें' : 'Add New Furniture Product')}
                      </h4>
                      <button
                        type="button"
                        onClick={handleResetProductForm}
                        className="text-stone-500 hover:text-stone-800 text-xs font-semibold"
                      >
                        {lang === 'hi' ? 'रद्द करें' : 'Cancel'}
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                          Product Title (English) *
                        </label>
                        <input
                          type="text"
                          required
                          value={formTitle}
                          onChange={(e) => setFormTitle(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-white border border-[#D5C2A5] rounded-md"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                          उत्पाद का नाम (हिंदी) *
                        </label>
                        <input
                          type="text"
                          required
                          value={formTitleHi}
                          onChange={(e) => setFormTitleHi(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-white border border-[#D5C2A5] rounded-md"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-[#2D2319] mb-1">Category</label>
                        <select
                          value={formCategory}
                          onChange={(e) => setFormCategory(e.target.value as FurnitureCategory)}
                          className="w-full px-3 py-2 text-xs bg-white border border-[#D5C2A5] rounded-md"
                        >
                          <option value="beds">Beds (पलंग)</option>
                          <option value="sofas">Sofas (सोफा सेट)</option>
                          <option value="dining">Dining (डाइनिंग टेबल)</option>
                          <option value="mandir">Mandir (पूजा मंदिर)</option>
                          <option value="wardrobes">Wardrobes (अलमारी)</option>
                          <option value="dressing">Dressing (ड्रेसिंग टेबल)</option>
                          <option value="chairs">Chairs & Tables</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-[#2D2319] mb-1">Wood Type</label>
                        <select
                          value={formWoodType}
                          onChange={(e) => setFormWoodType(e.target.value as WoodType)}
                          className="w-full px-3 py-2 text-xs bg-white border border-[#D5C2A5] rounded-md"
                        >
                          <option value="Solid Teak (सागवान)">Solid Teak (सागवान)</option>
                          <option value="Sheesham (शीशम)">Sheesham (शीशम)</option>
                          <option value="Sal Wood (सखुआ)">Sal Wood (सखुआ)</option>
                          <option value="Mango Wood (आम लकड़ी)">Mango Wood (आम लकड़ी)</option>
                          <option value="Engineered Wood">Engineered Wood</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                          Price (₹ विक्रय मूल्य) *
                        </label>
                        <input
                          type="number"
                          required
                          value={formPrice}
                          onChange={(e) => setFormPrice(Number(e.target.value))}
                          className="w-full px-3 py-2 text-xs bg-white border border-[#D5C2A5] rounded-md font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-[#2D2319] mb-1">MRP (₹)</label>
                        <input
                          type="number"
                          value={formMrp}
                          onChange={(e) => setFormMrp(Number(e.target.value))}
                          className="w-full px-3 py-2 text-xs bg-white border border-[#D5C2A5] rounded-md font-mono"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-[#2D2319] mb-1">Dimensions</label>
                        <input
                          type="text"
                          value={formDimensions}
                          onChange={(e) => setFormDimensions(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-white border border-[#D5C2A5] rounded-md"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-[#2D2319] mb-1">Image URL</label>
                        <input
                          type="text"
                          value={formImageUrl}
                          onChange={(e) => setFormImageUrl(e.target.value)}
                          placeholder="/src/assets/images/... or https://..."
                          className="w-full px-3 py-2 text-xs bg-white border border-[#D5C2A5] rounded-md font-mono"
                        />
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-6 pt-1">
                      <label className="flex items-center gap-2 text-xs text-[#2D2319] cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formInStock}
                          onChange={(e) => setFormInStock(e.target.checked)}
                          className="w-4 h-4 text-[#8E5327] rounded"
                        />
                        <span>{lang === 'hi' ? 'स्टॉक में उपलब्ध (In Stock)' : 'In Stock'}</span>
                      </label>

                      <label className="flex items-center gap-2 text-xs text-[#2D2319] cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formIsFeatured}
                          onChange={(e) => setFormIsFeatured(e.target.checked)}
                          className="w-4 h-4 text-[#8E5327] rounded"
                        />
                        <span>{lang === 'hi' ? 'विशेष फ़ीचर्ड उत्पाद (Featured)' : 'Featured on Home'}</span>
                      </label>

                      <label className="flex items-center gap-2 text-xs text-[#2D2319] cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formHidePrice}
                          onChange={(e) => setFormHidePrice(e.target.checked)}
                          className="w-4 h-4 text-[#8E5327] rounded"
                        />
                        <span>{lang === 'hi' ? 'कीमत छुपाएं (केवल पूछताछ हेतु)' : 'Hide Price (Quote Only)'}</span>
                      </label>
                    </div>

                    <div className="flex justify-end gap-2 pt-2 border-t border-[#E0D5C3]">
                      <button
                        type="button"
                        onClick={handleResetProductForm}
                        className="px-4 py-2 text-xs font-semibold text-stone-700 bg-white border border-stone-300 rounded-md cursor-pointer"
                      >
                        {lang === 'hi' ? 'रद्द करें' : 'Cancel'}
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 text-xs font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-md shadow-sm cursor-pointer"
                      >
                        {lang === 'hi' ? 'उत्पाद सहेजें' : 'Save Product'}
                      </button>
                    </div>
                  </form>
                )}

                {/* Product Grid / Table */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredProducts.map((p) => (
                    <div
                      key={p.id}
                      className="bg-[#FAF8F5] border border-[#E8DEC8] rounded-xl p-4 flex flex-col justify-between space-y-3"
                    >
                      <div className="flex items-start gap-3">
                        <img
                          src={p.imageUrl}
                          alt={p.title}
                          className="w-16 h-16 rounded-lg object-cover border border-[#D5C2A5] shrink-0"
                          onError={(e) => {
                            (e.target as any).src = '/src/assets/images/hero_luxury_furniture_1792942317776.jpg';
                          }}
                        />
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-xs text-[#2D2319] truncate">{p.title}</h4>
                          <p className="text-[11px] text-[#6A5A4A] truncate">{p.titleHi}</p>
                          <div className="flex items-center gap-1.5 mt-1">
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white border border-[#D5C2A5] text-[#8E5327]">
                              {p.sku}
                            </span>
                            <span className="text-[10px] font-semibold text-emerald-800">
                              ₹{p.price?.toLocaleString('en-IN')}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-[#E8DEC8]">
                        <span
                          className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                            p.inStock ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {p.inStock ? 'In Stock' : 'Out of Stock'}
                        </span>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleEditProductClick(p)}
                            className="p-1 text-stone-600 hover:text-[#8E5327] cursor-pointer"
                            title="Edit Product"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          {confirmDeleteId === p.id ? (
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => {
                                  onDeleteProduct(p.id);
                                  setConfirmDeleteId(null);
                                  showToast(lang === 'hi' ? 'उत्पाद हटाया गया।' : 'Product deleted.');
                                }}
                                className="px-1.5 py-0.5 text-[10px] font-bold text-white bg-rose-600 rounded"
                              >
                                {lang === 'hi' ? 'हाँ' : 'Yes'}
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteId(null)}
                                className="px-1.5 py-0.5 text-[10px] text-stone-600 bg-white border border-stone-300 rounded"
                              >
                                {lang === 'hi' ? 'ना' : 'No'}
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(p.id)}
                              className="p-1 text-stone-600 hover:text-rose-600 cursor-pointer"
                              title="Delete Product"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 2: INQUIRIES & QUOTES */}
            {activeTab === 'inquiries' && (
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-[#E8DEC8]">
                  <div>
                    <h3 className="font-display text-lg font-bold text-[#2D2319]">
                      {lang === 'hi' ? 'ग्राहक पूछताछ व कोटेशन अनुरोध' : 'Customer Inquiries & Quotes'}
                    </h3>
                    <p className="text-xs text-[#6A5A4A]">
                      {lang === 'hi'
                        ? 'ग्राहकों की मांगों का स्टेटस बदलें व सीधे व्हाट्सएप पर उत्तर दें'
                        : 'Review customer inquiries, update order statuses, and reply via WhatsApp'}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => exportInquiriesToCsv(inquiries)}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#8E5327] bg-[#FAF6F0] hover:bg-[#E8DEC8] border border-[#D5C2A5] rounded-lg cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>{lang === 'hi' ? 'CSV एक्सपोर्ट' : 'Export CSV'}</span>
                  </button>
                </div>

                <div className="space-y-3">
                  {inquiries.length === 0 ? (
                    <div className="text-center py-12 text-[#6A5A4A] text-xs">
                      {lang === 'hi' ? 'कोई पूछताछ उपलब्ध नहीं है।' : 'No customer inquiries yet.'}
                    </div>
                  ) : (
                    inquiries.map((inq) => (
                      <div
                        key={inq.id}
                        className="p-4 bg-[#FAF8F5] border border-[#E8DEC8] rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs text-[#2D2319]">{inq.customerName}</span>
                            <span className="text-[10px] text-[#6A5A4A]">({inq.formattedDate})</span>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                inq.status === 'new'
                                  ? 'bg-red-100 text-red-800'
                                  : inq.status === 'in_progress'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {inq.status.toUpperCase()}
                            </span>
                          </div>

                          <div className="text-xs text-[#5A4D40] flex flex-wrap items-center gap-3">
                            <span>📞 {inq.phone}</span>
                            {inq.city && <span>📍 {inq.city}</span>}
                            {inq.productTitle && (
                              <span className="font-semibold text-[#8E5327]">🛋️ {inq.productTitle}</span>
                            )}
                            {inq.woodPreference && (
                              <span>🪵 {inq.woodPreference}</span>
                            )}
                          </div>

                          {inq.customDesignNote && (
                            <p className="text-[11px] text-[#6A5A4A] bg-white p-2 rounded border border-[#E8DEC8] italic">
                              "{inq.customDesignNote}"
                            </p>
                          )}
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <select
                            value={inq.status}
                            onChange={(e) =>
                              onUpdateInquiryStatus(inq.id, e.target.value as CustomerInquiry['status'])
                            }
                            className="px-2.5 py-1.5 text-xs bg-white border border-[#D5C2A5] rounded-lg"
                          >
                            <option value="new">NEW (नई)</option>
                            <option value="in_progress">IN PROGRESS (प्रक्रियाधीन)</option>
                            <option value="completed">COMPLETED (सम्पन्न)</option>
                            <option value="closed">CLOSED (बंद)</option>
                          </select>

                          <a
                            href={`https://wa.me/${normalizeWhatsAppNumber(inq.phone)}?text=${encodeURIComponent(
                              `नमस्ते ${inq.customerName} जी, बाबा फर्नीचर उद्योग गोरखपुर से आपकी पूछताछ (${inq.productTitle || 'कस्टम फर्नीचर'}) के संबंध में संपर्क कर रहे हैं।`
                            )}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg"
                            title="Reply on WhatsApp"
                          >
                            <MessageSquare className="w-4 h-4" />
                          </a>

                          {onDeleteInquiry && (
                            confirmDeleteInqId === inq.id ? (
                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => {
                                    onDeleteInquiry(inq.id);
                                    setConfirmDeleteInqId(null);
                                  }}
                                  className="px-1.5 py-0.5 text-[10px] font-bold text-white bg-rose-600 rounded"
                                >
                                  हाँ
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setConfirmDeleteInqId(null)}
                                  className="px-1.5 py-0.5 text-[10px] text-stone-600 bg-white border border-stone-300 rounded"
                                >
                                  ना
                                </button>
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteInqId(inq.id)}
                                className="p-1.5 text-stone-400 hover:text-rose-600"
                                title="Delete Inquiry"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* TAB 2.5: IN-APP CUSTOMER LIVE CHATS (Owner & Admin Real-time Reply) */}
            {activeTab === 'chats' && (
              <div className="flex-1 overflow-hidden p-6 flex flex-col space-y-4">
                <div className="pb-3 border-b border-[#E8DEC8] flex items-center justify-between">
                  <div>
                    <h3 className="font-display text-lg font-bold text-[#2D2319]">
                      {lang === 'hi'
                        ? 'इन-ऐप ग्राहक लाइव चैट (Direct Customer <-> Owner Chat)'
                        : 'In-App Customer Live Chat Conversations'}
                    </h3>
                    <p className="text-xs text-[#6A5A4A]">
                      {lang === 'hi'
                        ? 'वेबसाइट चैट बॉक्स से ग्राहकों द्वारा भेजे गए संदेशों का यहीं से सीधा उत्तर दें (बिना WhatsApp रिडायरेक्ट के)'
                        : 'Reply directly to customers chatting on the website in real time'}
                    </p>
                  </div>
                </div>

                <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4 overflow-hidden border border-[#D5C2A5] rounded-xl bg-[#FAF8F5]">
                  {/* Left: Customer Sessions List */}
                  <div className="border-r border-[#E8DEC8] overflow-y-auto p-3 space-y-2 bg-white">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-[#8E5327] px-1">
                      {lang === 'hi'
                        ? `सक्रिय चैट सत्र (${chatSessions.length})`
                        : `Active Sessions (${chatSessions.length})`}
                    </div>
                    {chatSessions.length === 0 ? (
                      <div className="text-xs text-[#6A5A4A] p-4 text-center">
                        {lang === 'hi'
                          ? 'अभी कोई ग्राहक चैट सत्र नहीं है।'
                          : 'No customer chat sessions yet.'}
                      </div>
                    ) : (
                      chatSessions.map((sess) => (
                        <button
                          key={sess.id}
                          type="button"
                          onClick={() => setActiveChatSessionId(sess.id)}
                          className={`w-full text-left p-3 rounded-xl border transition cursor-pointer ${
                            activeChatSessionId === sess.id
                              ? 'bg-[#2D2319] text-white border-[#2D2319]'
                              : 'bg-[#FAF8F5] hover:bg-[#EFE6D8] text-[#2D2319] border-[#E0D5C3]'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-bold text-xs truncate">
                              {sess.customerName || 'ग्राहक (Guest)'}
                            </span>
                            {sess.unreadForAdmin > 0 && (
                              <span className="px-1.5 py-0.5 text-[10px] font-bold bg-emerald-600 text-white rounded-full">
                                {sess.unreadForAdmin} New
                              </span>
                            )}
                          </div>
                          {sess.customerPhone && (
                            <div className="text-[11px] opacity-80 mt-0.5">📞 {sess.customerPhone}</div>
                          )}
                          <div className="text-[11px] opacity-75 truncate mt-1">
                            {sess.messages[sess.messages.length - 1]?.text || ''}
                          </div>
                        </button>
                      ))
                    )}
                  </div>

                  {/* Right: Active Chat Stream & Owner Reply Box */}
                  <div className="md:col-span-2 flex flex-col overflow-hidden bg-[#FAF8F5]">
                    {(() => {
                      const activeSess = chatSessions.find((s) => s.id === activeChatSessionId);
                      if (!activeSess) {
                        return (
                          <div className="flex-1 flex items-center justify-center text-xs text-[#6A5A4A] p-6">
                            {lang === 'hi'
                              ? 'चैट देखने और उत्तर देने के लिए बाईं ओर से किसी ग्राहक सत्र को चुनें।'
                              : 'Select a customer session on the left to view messages and reply.'}
                          </div>
                        );
                      }
                      return (
                        <>
                          <div className="px-4 py-2.5 bg-white border-b border-[#E8DEC8] flex items-center justify-between">
                            <div>
                              <div className="font-bold text-xs text-[#2D2319]">
                                {activeSess.customerName || 'ग्राहक (Guest)'}
                              </div>
                              <div className="text-[11px] text-[#6A5A4A]">
                                {activeSess.customerPhone
                                  ? `📞 ${activeSess.customerPhone}`
                                  : lang === 'hi'
                                  ? 'वेबसाइट लाइव चैट'
                                  : 'Website Live Chat'}
                              </div>
                            </div>
                          </div>

                          <div className="flex-1 p-4 overflow-y-auto space-y-2.5">
                            {activeSess.messages.map((m) => (
                              <div
                                key={m.id}
                                className={`flex flex-col ${
                                  m.sender === 'shop' ? 'items-end' : 'items-start'
                                }`}
                              >
                                <div
                                  className={`max-w-[80%] px-3.5 py-2 rounded-2xl text-xs leading-relaxed ${
                                    m.sender === 'shop'
                                      ? 'bg-[#8E5327] text-white rounded-br-xs'
                                      : 'bg-white text-[#2D2319] border border-[#D5C2A5] rounded-bl-xs'
                                  }`}
                                >
                                  {m.text}
                                </div>
                                <span className="text-[10px] text-stone-400 mt-0.5 px-1">
                                  {m.senderName || (m.sender === 'shop' ? 'शोरूम' : 'ग्राहक')} ·{' '}
                                  {m.formattedTime}
                                </span>
                              </div>
                            ))}
                          </div>

                          <form
                            onSubmit={async (e) => {
                              e.preventDefault();
                              if (!adminReplyInput.trim() || isSendingReply) return;
                              setIsSendingReply(true);
                              const res = await replyAdminChatApi(
                                activeSess.id,
                                adminReplyInput.trim()
                              );
                              setIsSendingReply(false);
                              if (res.success && res.session) {
                                setAdminReplyInput('');
                                setChatSessions((prev) =>
                                  prev.map((s) => (s.id === activeSess.id ? res.session! : s))
                                );
                              }
                            }}
                            className="p-3 bg-white border-t border-[#E8DEC8] flex items-center gap-2"
                          >
                            <input
                              type="text"
                              placeholder={
                                lang === 'hi'
                                  ? 'ग्राहक को सीधा उत्तर लिखें...'
                                  : 'Type your direct reply to customer...'
                              }
                              value={adminReplyInput}
                              onChange={(e) => setAdminReplyInput(e.target.value)}
                              className="flex-1 px-3.5 py-2 text-xs bg-[#FAF8F5] border border-[#D5C2A5] rounded-full focus:outline-none focus:ring-1 focus:ring-[#8E5327]"
                            />
                            <button
                              type="submit"
                              disabled={isSendingReply}
                              className="px-4 py-2 text-xs font-bold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-full cursor-pointer disabled:opacity-50"
                            >
                              {lang === 'hi' ? 'उत्तर भेजें' : 'Send Reply'}
                            </button>
                          </form>
                        </>
                      );
                    })()}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: SHOWROOM SETTINGS */}
            {activeTab === 'settings' && (
              <form onSubmit={handleSaveSettings} className="flex-1 overflow-y-auto p-6 space-y-5 max-w-2xl mx-auto">
                <div className="pb-3 border-b border-[#E8DEC8]">
                  <h3 className="font-display text-lg font-bold text-[#2D2319]">
                    {lang === 'hi' ? 'शोरूम प्रोफ़ाइल एवं संपर्क विवरण' : 'Showroom Details & Contact'}
                  </h3>
                  <p className="text-xs text-[#6A5A4A]">
                    {lang === 'hi'
                      ? 'शोरूम का पता, फोन, व्हाट्सएप नंबर, समय और घोषणा बार अपडेट करें'
                      : 'Update contact information, timings, and banner announcement'}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                      Business Name (English)
                    </label>
                    <input
                      type="text"
                      value={settingsForm.businessName}
                      onChange={(e) => setSettingsForm({ ...settingsForm, businessName: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C2A5] rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                      दुकान का नाम (हिंदी)
                    </label>
                    <input
                      type="text"
                      value={settingsForm.businessNameHi}
                      onChange={(e) => setSettingsForm({ ...settingsForm, businessNameHi: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C2A5] rounded-md"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                      Phone Number (फ़ोन)
                    </label>
                    <input
                      type="text"
                      value={settingsForm.phone}
                      onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C2A5] rounded-md font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                      WhatsApp Number (व्हाट्सएप)
                    </label>
                    <input
                      type="text"
                      value={settingsForm.whatsappNumber}
                      onChange={(e) => setSettingsForm({ ...settingsForm, whatsappNumber: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C2A5] rounded-md font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                      GST Number
                    </label>
                    <input
                      type="text"
                      value={settingsForm.gstNumber || ''}
                      onChange={(e) => setSettingsForm({ ...settingsForm, gstNumber: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C2A5] rounded-md font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                    Showroom Address (शोरूम का पता)
                  </label>
                  <input
                    type="text"
                    value={settingsForm.address}
                    onChange={(e) => setSettingsForm({ ...settingsForm, address: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C2A5] rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D2319] mb-1">
                    Top Announcement Bar (मुख्य घोषणा बैनर)
                  </label>
                  <textarea
                    rows={2}
                    value={settingsForm.announcement}
                    onChange={(e) => setSettingsForm({ ...settingsForm, announcement: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C2A5] rounded-md"
                  />
                </div>

                <div className="pt-3 flex items-center justify-between border-t border-[#E8DEC8]">
                  <button
                    type="button"
                    onClick={() => {
                      if (confirmReset) {
                        onResetDemoData();
                        setConfirmReset(false);
                      } else {
                        setConfirmReset(true);
                      }
                    }}
                    className="text-xs text-rose-700 hover:underline cursor-pointer flex items-center gap-1"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>{confirmReset ? 'पुष्टि करें: रीसेट' : 'डेटा रीसेट'}</span>
                  </button>

                  <button
                    type="submit"
                    className="px-6 py-2.5 text-xs font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-md shadow-sm cursor-pointer flex items-center gap-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>{lang === 'hi' ? 'सेटिंग्स सहेजें' : 'Save Showroom Settings'}</span>
                  </button>
                </div>
              </form>
            )}

            {/* TAB 4: ADMIN TEAM & SECURE INVITATIONS (APPLICATION ADMIN ONLY) */}
            {activeTab === 'team' && isAppAdmin && (
              <div className="flex-1 overflow-y-auto p-6 space-y-6 max-w-4xl mx-auto">
                <div className="pb-3 border-b border-[#E8DEC8] flex items-center justify-between">
                  <div>
                    <h3 className="font-display text-lg font-bold text-[#2D2319] flex items-center gap-2">
                      <Shield className="w-5 h-5 text-purple-700" />
                      <span>{lang === 'hi' ? 'व्यवस्थापक टीम एवं आमंत्रण (Admin Team Management)' : 'Admin Team & Invitations'}</span>
                    </h3>
                    <p className="text-xs text-[#6A5A4A]">
                      {lang === 'hi'
                        ? 'नए शॉप ओनर या एप्लिकेशन एडमिन को ईमेल आमंत्रण भेजें एवं सक्रिय अनुमतियों का प्रबंधन करें'
                        : 'Invite additional shop owners or application admins and manage team roles'}
                    </p>
                  </div>
                </div>

                {/* Invite Form Card */}
                <div className="p-5 bg-purple-50/50 rounded-xl border border-purple-200 space-y-3">
                  <h4 className="font-bold text-xs text-purple-950 flex items-center gap-1.5">
                    <UserPlus className="w-4 h-4 text-purple-700" />
                    <span>{lang === 'hi' ? 'नया व्यवस्थापक आमंत्रित करें (Invite New Admin)' : 'Invite New Team Member'}</span>
                  </h4>

                  {inviteSuccessMsg && (
                    <div className="p-2.5 text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg">
                      {inviteSuccessMsg}
                    </div>
                  )}
                  {inviteErrorMsg && (
                    <div className="p-2.5 text-xs text-rose-800 bg-rose-50 border border-rose-200 rounded-lg">
                      {inviteErrorMsg}
                    </div>
                  )}

                  <form onSubmit={handleInviteAdmin} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
                    <div className="sm:col-span-1">
                      <label className="block text-[11px] font-semibold text-purple-900 mb-1">
                        {lang === 'hi' ? 'नाम (Full Name)' : 'Full Name'}
                      </label>
                      <input
                        type="text"
                        placeholder={lang === 'hi' ? 'शोरूम संचालक का नाम' : 'Owner / Admin Name'}
                        value={inviteFullName}
                        onChange={(e) => setInviteFullName(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white border border-purple-300 rounded-lg"
                      />
                    </div>

                    <div className="sm:col-span-1">
                      <label className="block text-[11px] font-semibold text-purple-900 mb-1">
                        {lang === 'hi' ? 'ईमेल पता *' : 'Email Address *'}
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="owner@babafurnitureudyog.com"
                        value={inviteEmail}
                        onChange={(e) => setInviteEmail(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white border border-purple-300 rounded-lg"
                      />
                    </div>

                    <div className="sm:col-span-1">
                      <label className="block text-[11px] font-semibold text-purple-900 mb-1">
                        {lang === 'hi' ? 'सीधा पासवर्ड (वैकल्पिक)' : 'Direct Password (Optional)'}
                      </label>
                      <input
                        type="password"
                        placeholder="Min 6 chars"
                        value={invitePassword}
                        onChange={(e) => setInvitePassword(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white border border-purple-300 rounded-lg"
                      />
                    </div>

                    <div className="sm:col-span-1">
                      <label className="block text-[11px] font-semibold text-purple-900 mb-1">
                        {lang === 'hi' ? 'भूमिका (Role) *' : 'Assigned Role *'}
                      </label>
                      <select
                        value={inviteRole}
                        onChange={(e) => setInviteRole(e.target.value as AdminRole)}
                        className="w-full px-3 py-2 text-xs bg-white border border-purple-300 rounded-lg"
                      >
                        <option value="shop_owner">👑 Shop Owner (दुकान संचालक — उत्पाद व पूछताछ)</option>
                        <option value="app_admin">🛡️ Application Admin (सिस्टम प्रशासक — पूर्ण अधिकार)</option>
                      </select>
                    </div>

                    <div className="sm:col-span-1">
                      <button
                        type="submit"
                        disabled={isInviting}
                        className="w-full py-2 px-4 text-xs font-semibold text-white bg-purple-700 hover:bg-purple-800 rounded-lg shadow-sm cursor-pointer disabled:opacity-50 flex items-center justify-center gap-1.5"
                      >
                        <Mail className="w-3.5 h-3.5" />
                        <span>{isInviting ? 'आमंत्रण भेजा जा रहा...' : 'आमंत्रण भेजें (Send Invite)'}</span>
                      </button>
                    </div>
                  </form>
                </div>

                {/* Active Admin Members */}
                <div className="space-y-3">
                  <h4 className="font-bold text-xs text-[#2D2319] flex items-center justify-between">
                    <span>{lang === 'hi' ? 'सक्रिय व्यवस्थापक सदस्य' : 'Active Admin Members'}</span>
                    <span className="text-[11px] font-normal text-[#6A5A4A]">
                      {adminTeam.length} Members
                    </span>
                  </h4>

                  <div className="border border-[#E8DEC8] rounded-xl overflow-hidden divide-y divide-[#E8DEC8]">
                    {adminTeam.length === 0 ? (
                      <div className="p-4 text-center text-xs text-[#6A5A4A]">
                        {lang === 'hi' ? 'कोई अतिरिक्त सदस्य नहीं है।' : 'No other team members found.'}
                      </div>
                    ) : (
                      adminTeam.map((member) => (
                        <div key={member.id} className="p-4 bg-white flex items-center justify-between gap-4">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-xs text-[#2D2319]">{member.ownerName || member.email}</span>
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  member.role === 'app_admin'
                                    ? 'bg-purple-100 text-purple-800 border border-purple-300'
                                    : 'bg-amber-100 text-amber-800 border border-amber-300'
                                }`}
                              >
                                {member.role === 'app_admin' ? '🛡️ Application Admin' : '👑 Shop Owner'}
                              </span>
                              {member.mfaEnabled && (
                                <span className="px-1.5 py-0.5 rounded text-[9px] bg-emerald-100 text-emerald-800 font-semibold">
                                  2FA Active
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-[#6A5A4A]">{member.email}</p>
                          </div>

                          {member.id !== adminProfile.id && (
                            <button
                              type="button"
                              onClick={() => handleRevokeAdmin(member.id || '', member.ownerName || member.email)}
                              className="px-2.5 py-1 text-xs text-rose-700 hover:bg-rose-50 border border-rose-300 rounded cursor-pointer"
                            >
                              हटाएं (Revoke)
                            </button>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Pending Invitations */}
                <div className="space-y-3">
                  <h4 className="font-bold text-xs text-[#2D2319] flex items-center justify-between">
                    <span>{lang === 'hi' ? 'लंबित आमंत्रण (Pending Invitations)' : 'Pending Invitations'}</span>
                    <span className="text-[11px] font-normal text-[#6A5A4A]">
                      {invitations.length} Pending
                    </span>
                  </h4>

                  <div className="border border-[#E8DEC8] rounded-xl overflow-hidden divide-y divide-[#E8DEC8]">
                    {invitations.length === 0 ? (
                      <div className="p-4 text-center text-xs text-[#6A5A4A]">
                        {lang === 'hi' ? 'कोई लंबित आमंत्रण नहीं है।' : 'No pending invitations.'}
                      </div>
                    ) : (
                      invitations.map((inv) => (
                        <div key={inv.id} className="p-3.5 bg-[#FAF8F5] flex items-center justify-between gap-4">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-xs text-[#2D2319]">{inv.email}</span>
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-stone-200 text-stone-800">
                                {inv.role === 'app_admin' ? 'App Admin' : 'Shop Owner'}
                              </span>
                              <span className="text-[10px] text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                                Pending
                              </span>
                            </div>
                            <p className="text-[10px] text-[#6A5A4A]">
                              समाप्ति (Expires): {new Date(inv.expiresAt).toLocaleDateString()}
                            </p>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleRevokeInvitation(inv.id)}
                            className="px-2 py-1 text-[11px] text-rose-700 hover:bg-rose-100 rounded cursor-pointer"
                          >
                            रद्द करें
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>

              </div>
            )}

            {/* TAB 5: CUSTOMER SIGN-IN METHODS CONFIGURATION (APPLICATION ADMIN ONLY) */}
            {activeTab === 'auth_methods' && isAppAdmin && (
              <form onSubmit={handleSaveAuthConfig} className="flex-1 overflow-y-auto p-6 space-y-6 max-w-2xl mx-auto">
                <div className="pb-3 border-b border-[#E8DEC8]">
                  <h3 className="font-display text-lg font-bold text-[#2D2319] flex items-center gap-2">
                    <KeyRound className="w-5 h-5 text-purple-700" />
                    <span>{lang === 'hi' ? 'ग्राहक लॉगिन विधियां कॉन्फ़िगरेशन' : 'Customer Sign-In Methods Configuration'}</span>
                  </h3>
                  <p className="text-xs text-[#6A5A4A]">
                    {lang === 'hi'
                      ? 'अवांछित या अनकॉन्फ़िगर लॉगिन विधियों को ग्राहक स्टोरफ़्रंट से छुपाएं। केवल वास्तविक रूप से सक्रिय तरीकों को ही दिखाएं।'
                      : 'Enable or hide authentication methods for customers in the storefront modal.'}
                  </p>
                </div>

                {authConfigMsg && (
                  <div className="p-3 text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg">
                    {authConfigMsg}
                  </div>
                )}

                <div className="space-y-4">
                  
                  {/* Email & Password */}
                  <div className="p-4 rounded-xl border border-[#D5C2A5] bg-[#FAF8F5] flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-[#2D2319]">
                        {lang === 'hi' ? '1. ईमेल एवं पासवर्ड लॉगिन (Email & Password)' : 'Email & Password Authentication'}
                      </h4>
                      <p className="text-[11px] text-[#6A5A4A]">
                        {lang === 'hi'
                          ? 'ग्राहक ईमेल और पासवर्ड से साइनअप, लॉगिन और पासवर्ड रीसेट कर सकते हैं।'
                          : 'Full registration with email, password policy, confirm password, and reset.'}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        setAuthConfig({ ...authConfig, emailPasswordEnabled: !authConfig.emailPasswordEnabled })
                      }
                      className="text-[#8E5327] cursor-pointer"
                    >
                      {authConfig.emailPasswordEnabled ? (
                        <ToggleRight className="w-8 h-8 text-emerald-600" />
                      ) : (
                        <ToggleLeft className="w-8 h-8 text-stone-400" />
                      )}
                    </button>
                  </div>

                  {/* Email OTP */}
                  <div className="p-4 rounded-xl border border-[#D5C2A5] bg-[#FAF8F5] flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-[#2D2319]">
                        {lang === 'hi' ? '2. ईमेल ओटीपी लॉगिन (Email OTP Sign-In)' : 'Email OTP Sign-In'}
                      </h4>
                      <p className="text-[11px] text-[#6A5A4A]">
                        {lang === 'hi'
                          ? 'Supabase Auth के माध्यम से वास्तविक ईमेल ओटीपी कोड भेजा जाता है।'
                          : 'Real 6-digit OTP code requested and verified via Supabase Auth.'}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        setAuthConfig({ ...authConfig, emailOtpEnabled: !authConfig.emailOtpEnabled })
                      }
                      className="text-[#8E5327] cursor-pointer"
                    >
                      {authConfig.emailOtpEnabled ? (
                        <ToggleRight className="w-8 h-8 text-emerald-600" />
                      ) : (
                        <ToggleLeft className="w-8 h-8 text-stone-400" />
                      )}
                    </button>
                  </div>

                  {/* Google OAuth */}
                  <div className="p-4 rounded-xl border border-[#D5C2A5] bg-[#FAF8F5] flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-[#2D2319]">
                          {lang === 'hi' ? '3. गूगल लॉगिन (Google 1-Click OAuth)' : 'Google 1-Click OAuth'}
                        </h4>
                        <span className="text-[10px] px-1.5 py-0.2 bg-blue-100 text-blue-800 font-semibold rounded">
                          OAuth Provider
                        </span>
                      </div>
                      <p className="text-[11px] text-[#6A5A4A]">
                        {lang === 'hi'
                          ? 'Supabase Dashboard में Google OAuth Client ID व Secret कॉन्फ़िगर होने पर ही चालू करें।'
                          : 'Requires Google OAuth Client ID & Secret in Supabase Auth Providers.'}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        setAuthConfig({ ...authConfig, googleAuthEnabled: !authConfig.googleAuthEnabled })
                      }
                      className="text-[#8E5327] cursor-pointer"
                    >
                      {authConfig.googleAuthEnabled ? (
                        <ToggleRight className="w-8 h-8 text-emerald-600" />
                      ) : (
                        <ToggleLeft className="w-8 h-8 text-stone-400" />
                      )}
                    </button>
                  </div>

                  {/* SMS Phone OTP */}
                  <div className="p-4 rounded-xl border border-stone-300 bg-stone-50 flex items-center justify-between opacity-90">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-stone-700">
                          {lang === 'hi' ? '4. मोबाइल एसएमएस ओटीपी (SMS Phone OTP)' : 'SMS Phone OTP'}
                        </h4>
                        <span className="text-[10px] px-1.5 py-0.2 bg-amber-100 text-amber-800 font-semibold rounded">
                          Requires Paid Provider
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500">
                        {lang === 'hi'
                          ? 'Twilio/MessageBird/AWS SNS क्रेडेंशियल के बिना यह निष्क्रिय रहता है।'
                          : 'Disabled by default. Only enable after connecting a paid SMS provider.'}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        setAuthConfig({ ...authConfig, phoneOtpEnabled: !authConfig.phoneOtpEnabled })
                      }
                      className="text-stone-500 cursor-pointer"
                    >
                      {authConfig.phoneOtpEnabled ? (
                        <ToggleRight className="w-8 h-8 text-emerald-600" />
                      ) : (
                        <ToggleLeft className="w-8 h-8 text-stone-400" />
                      )}
                    </button>
                  </div>

                  {/* WhatsApp OTP */}
                  <div className="p-4 rounded-xl border border-stone-300 bg-stone-50 flex items-center justify-between opacity-90">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-stone-700">
                          {lang === 'hi' ? '5. व्हाट्सएप ओटीपी (WhatsApp OTP)' : 'WhatsApp OTP Authentication'}
                        </h4>
                        <span className="text-[10px] px-1.5 py-0.2 bg-amber-100 text-amber-800 font-semibold rounded">
                          Requires Meta Cloud API
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500">
                        {lang === 'hi'
                          ? 'Meta WhatsApp Business API क्रेडेंशियल के बिना यह सुरक्षित रूप से छुपाया गया है।'
                          : 'Hidden by default to prevent hardcoded mock authentication.'}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        setAuthConfig({ ...authConfig, whatsappOtpEnabled: !authConfig.whatsappOtpEnabled })
                      }
                      className="text-stone-500 cursor-pointer"
                    >
                      {authConfig.whatsappOtpEnabled ? (
                        <ToggleRight className="w-8 h-8 text-emerald-600" />
                      ) : (
                        <ToggleLeft className="w-8 h-8 text-stone-400" />
                      )}
                    </button>
                  </div>

                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="submit"
                    disabled={isSavingAuthConfig}
                    className="px-6 py-2.5 text-xs font-semibold text-white bg-purple-700 hover:bg-purple-800 rounded-lg shadow-sm cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>{isSavingAuthConfig ? 'सहेजा जा रहा है...' : 'लॉगिन विधियां सुरक्षित करें (Save Auth Settings)'}</span>
                  </button>
                </div>
              </form>
            )}

            {/* TAB 6: SECURITY & MFA */}
            {activeTab === 'security' && (
              <div className="flex-1 overflow-y-auto p-6 space-y-6 max-w-2xl mx-auto">
                <div className="pb-3 border-b border-[#E8DEC8]">
                  <h3 className="font-display text-lg font-bold text-[#2D2319] flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-600" />
                    <span>{lang === 'hi' ? 'सुरक्षा, 2-स्टेप सत्यापन व डेटाबेस' : 'Security, 2-Step Verification & Database'}</span>
                  </h3>
                  <p className="text-xs text-[#6A5A4A]">
                    {lang === 'hi'
                      ? 'व्यवस्थापक पासवर्ड बदलें, 2-स्टेप लॉगिन सक्षम करें और Supabase स्थिति जांचें'
                      : 'Change admin password, toggle MFA, and verify database connection'}
                  </p>
                </div>

                {/* 2-Step Verification (MFA) Toggle Card */}
                <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-xs text-emerald-950 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-700" />
                      <span>{lang === 'hi' ? '2-स्टेप सत्यापन (MFA 2-Factor Authentication)' : '2-Step Verification (MFA)'}</span>
                    </h4>
                    <p className="text-[11px] text-emerald-800/80">
                      {lang === 'hi'
                        ? 'सक्रिय करने पर, एडमिन लॉगिन के समय 6-अंकों का सत्यापन कोड अनिवार्य होगा।'
                        : 'When enabled, a 6-digit challenge code is required upon every admin login.'}
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={isTogglingMfa}
                    onClick={handleToggleMfa}
                    className="text-emerald-700 cursor-pointer disabled:opacity-50"
                  >
                    {adminProfile.mfaEnabled ? (
                      <ToggleRight className="w-8 h-8 text-emerald-600" />
                    ) : (
                      <ToggleLeft className="w-8 h-8 text-stone-400" />
                    )}
                  </button>
                </div>

                {/* Change Admin Password */}
                <form onSubmit={handleChangePassword} className="p-5 rounded-xl border border-[#D5C2A5] bg-[#FAF8F5] space-y-4">
                  <h4 className="font-bold text-xs text-[#2D2319]">
                    {lang === 'hi' ? 'व्यवस्थापक पासवर्ड बदलें (Change Admin Password)' : 'Change Administrator Password'}
                  </h4>

                  {passMsg && (
                    <div className="p-2.5 text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg">
                      {passMsg}
                    </div>
                  )}
                  {passError && (
                    <div className="p-2.5 text-xs text-rose-800 bg-rose-50 border border-rose-200 rounded-lg">
                      {passError}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] font-semibold text-[#5A4D40] mb-1">
                        {lang === 'hi' ? 'नया मजबूत पासवर्ड (New Password) *' : 'New Password (min 8 chars) *'}
                      </label>
                      <input
                        type="password"
                        required
                        placeholder="Min 8 characters"
                        value={newPasswordInput}
                        onChange={(e) => setNewPasswordInput(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white border border-[#D5C2A5] rounded-md"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-[#5A4D40] mb-1">
                        {lang === 'hi' ? 'पासवर्ड की पुष्टि (Confirm Password) *' : 'Confirm Password *'}
                      </label>
                      <input
                        type="password"
                        required
                        placeholder="Re-enter new password"
                        value={confirmPasswordInput}
                        onChange={(e) => setConfirmPasswordInput(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white border border-[#D5C2A5] rounded-md"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="px-5 py-2 text-xs font-semibold text-white bg-[#8E5327] hover:bg-[#73411C] rounded-md cursor-pointer"
                    >
                      {lang === 'hi' ? 'पासवर्ड अपडेट करें' : 'Update Password'}
                    </button>
                  </div>
                </form>

                {/* Database & Infrastructure Status (Read-Only) */}
                <div className="p-4 rounded-xl border border-stone-300 bg-stone-50 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                      <Database className="w-4 h-4 text-stone-600" />
                      <span>{lang === 'hi' ? 'क्लाउड डेटाबेस कनेक्शन (Database Info)' : 'Cloud Database Connection'}</span>
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold">
                      {supabaseStatus?.mode || 'Active'}
                    </span>
                  </div>

                  <div className="text-[11px] text-stone-600 space-y-1 font-mono">
                    <p>
                      <strong>Supabase URL:</strong>{' '}
                      {sbConfig.url ? sbConfig.url : 'Configured via server environment variables (.env.local)'}
                    </p>
                    <p className="text-stone-500 font-sans text-[11px]">
                      🔒 <strong>सुरक्षा मानक (Zero Secrets in Frontend)</strong>: सर्विस-रोल की (Service Role Secret Key) और डेटाबेस पासवर्ड कभी भी क्लाइंट-साइड फ़ॉर्म में दर्ज नहीं किए जाते। वे सुरक्षित सर्वर बैकएंड (.env.local) में रखे जाते हैं।
                    </p>
                  </div>
                </div>

              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
};
