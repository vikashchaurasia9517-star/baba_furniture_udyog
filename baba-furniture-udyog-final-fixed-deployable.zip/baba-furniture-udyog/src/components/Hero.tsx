import React, { useState, useEffect } from 'react';
import { ShowroomConfig } from '../types/furniture';
import {
  ChevronLeft,
  ChevronRight,
  Pause,
  Play,
  MapPin,
  Camera,
  ArrowRight,
} from 'lucide-react';

interface HeroProps {
  config: ShowroomConfig;
  lang: 'hi' | 'en';
  onExploreClick: () => void;
  onCustomOrderClick: () => void;
  onOpenCatalog: () => void;
}

const HERO_SLIDES = [
  {
    id: 'slide-1',
    image: '/images/hero_luxury_furniture_1792942317776.jpg',
    badgeHi: '✨ 100% असली सागवान व शीशम शोरूम',
    badgeEn: '✨ 100% Genuine Teak & Sheesham Showroom',
    titleHi: 'शाही सागवान फर्नीचर कलेक्शन',
    titleEn: 'Royal Handcrafted Teak Masterpieces',
    subtitleHi: 'सीधे गोरखपुर कारखाने से थोक व खुदरा रेट पर — 10 साल की लिखित दीमक गारंटी।',
    subtitleEn: 'Factory-direct showroom pricing from Gorakhpur artisans with 10-year written termite warranty.',
    priceTagHi: 'शुरुआती रेंज ₹16,500 से',
    priceTagEn: 'Starting ₹16,500',
    accentColor: '#C89D66',
  },
  {
    id: 'slide-2',
    image: '/images/furniture_king_bed_1792942318703.jpg',
    badgeHi: '🛏️ महाराजा रॉयल बेडरूम कलेक्शन',
    badgeEn: '🛏️ Maharaja Royal Bedroom Suite',
    titleHi: 'महाराजा सागवान किंग साइज हाइड्रोलिक बेड',
    titleEn: 'Maharaja Solid Teak Hydraulic King Bed',
    subtitleHi: 'हैवी ड्यूटी हाइड्रोलिक स्टोरेज, शाही टफ्टेड कुशन हेडबोर्ड और 3-इंच सागवान बॉर्डर।',
    subtitleEn: 'Heavy-duty hydraulic box storage, royal tufted headboard, and 3-inch solid seasoned teak border.',
    priceTagHi: 'शोरूम रेट: ₹48,500 · 10 साल वारंटी',
    priceTagEn: 'Showroom Price: ₹48,500 · 10 Yr Warranty',
    accentColor: '#D97706',
  },
  {
    id: 'slide-3',
    image: '/images/furniture_luxury_sofa_1792942319362.jpg',
    badgeHi: '🛋️ शाही बैठक व सोफा कलेक्शन',
    badgeEn: '🛋️ Imperial Carved Living Room Sofas',
    titleHi: 'इंपीरियल हैंड-कार्व्ड सागवान सोफा सेट',
    titleEn: 'Imperial Hand-Carved Solid Teak Sofa',
    subtitleHi: '40-डेंसिटी स्लीपवेल फोम, प्रीमियम मखमली वेलवेट फैब्रिक और बारीक नक्काशी।',
    subtitleEn: '40-density Sleepwell cushion comfort paired with hand-carved solid teak frame.',
    priceTagHi: 'शोरूम रेट: ₹54,000 · कस्टम फैब्रिक कलर',
    priceTagEn: 'Showroom Price: ₹54,000 · Custom Velvet Colors',
    accentColor: '#10B981',
  },
  {
    id: 'slide-4',
    image: '/images/furniture_dining_set_1792942319223.jpg',
    badgeHi: '🍽️ परिवार डाइनिंग व मास्टर टेबल',
    badgeEn: '🍽️ Family Dining & Executive Suites',
    titleHi: 'हेरिटेज प्योर शीशम 6-सीटर डाइनिंग सेट',
    titleEn: 'Heritage Pure Sheesham 6-Seater Dining',
    subtitleHi: 'स्क्रैच व हीट प्रूफ पॉलिश, हाथ की जालीदार नक्काशी वाली 6 आरामदायक कुर्सियां।',
    subtitleEn: 'Heat-resistant finish with 6 ergonomic lattice-carved solid Sheesham wood chairs.',
    priceTagHi: 'शोरूम रेट: ₹42,000 · 6 व 8 सीटर उपलब्ध',
    priceTagEn: 'Showroom Price: ₹42,000 · 6 & 8 Seater Options',
    accentColor: '#F59E0B',
  },
  {
    id: 'slide-5',
    image: '/images/furniture_wooden_mandir_1792942319736.jpg',
    badgeHi: '🛕 पवित्र पूजा मंदिर व वास्तु निर्माण',
    badgeEn: '🛕 Sacred Handcrafted Teak Mandirs',
    titleHi: 'गोपुरम शिखर व पीतल घंटी सागवान पूजा मंदिर',
    titleEn: 'Grand Gopuram Carved Teak Puja Mandir',
    subtitleHi: 'दीया-धूप की गर्मी से सुरक्षित पॉलिश, स्लाइडिंग भोग ट्रे और 3 बड़ी पूजा सामग्री दराजें।',
    subtitleEn: 'Heat-sealed teak finish, brass hanging bells, pull-out bhog tray, and spacious drawers.',
    priceTagHi: 'शोरूम रेट: ₹24,500 · 15 साल वारंटी',
    priceTagEn: 'Showroom Price: ₹24,500 · 15 Yr Warranty',
    accentColor: '#EC4899',
  },
];

export const Hero: React.FC<HeroProps> = ({
  config,
  lang,
  onExploreClick,
  onCustomOrderClick,
}) => {
  const [slideIndex, setSlideIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  useEffect(() => {
    if (!isPlaying) return;
    const timer = setInterval(() => {
      setSlideIndex((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 4200);
    return () => clearInterval(timer);
  }, [isPlaying]);

  const activeSlide = HERO_SLIDES[slideIndex] || HERO_SLIDES[0];

  const handlePrev = () => {
    setSlideIndex((prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);
  };

  const handleNext = () => {
    setSlideIndex((prev) => (prev + 1) % HERO_SLIDES.length);
  };

  return (
    <section className="relative bg-[#1E1610] border-b border-[#E8DEC8] overflow-hidden no-print" id="top">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
        <div className="relative rounded-2xl overflow-hidden border-2 border-[#C89D66] shadow-2xl bg-[#2D2319]">
          <img
            src={activeSlide.image}
            alt={lang === 'hi' ? activeSlide.titleHi : activeSlide.titleEn}
            className="w-full h-[320px] sm:h-[400px] lg:h-[440px] object-cover transition-all duration-700"
            loading="eager"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/35 to-black/25 pointer-events-none" />

          {/* Top Bar on Slide: Badge + Price Tag + Pause/Play */}
          <div className="absolute top-3.5 left-3.5 right-3.5 flex flex-wrap items-center justify-between gap-2 z-10">
            <div className="flex flex-wrap items-center gap-2">
              <span
                className="px-3 py-1 rounded-full text-xs font-bold text-white shadow-md backdrop-blur-md"
                style={{ backgroundColor: `${activeSlide.accentColor}DD` }}
              >
                {lang === 'hi' ? activeSlide.badgeHi : activeSlide.badgeEn}
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-black/65 text-[#FDE68A] border border-[#C89D66]/40 backdrop-blur-md">
                {config.showPricesOnWebsite !== false
                  ? lang === 'hi'
                    ? activeSlide.priceTagHi
                    : activeSlide.priceTagEn
                  : lang === 'hi'
                  ? '📞 कीमत के लिए संपर्क करें'
                  : '📞 Contact for Price'}
              </span>
            </div>

            <button
              onClick={() => setIsPlaying((p) => !p)}
              className="inline-flex items-center gap-1.5 bg-black/65 hover:bg-black/80 backdrop-blur-md px-3 py-1 rounded-full border border-white/20 text-white text-xs font-semibold cursor-pointer"
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>
                {isPlaying
                  ? lang === 'hi'
                    ? 'रोकें (Pause)'
                    : 'Pause'
                  : lang === 'hi'
                  ? 'ऑटो-प्ले (Play)'
                  : 'Auto Play'}
              </span>
            </button>
          </div>

          {/* Left / Right Prev & Next Navigation Arrows */}
          <button
            onClick={handlePrev}
            className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/60 hover:bg-[#8E5327] text-white border border-white/25 flex items-center justify-center shadow-lg transition-all cursor-pointer z-10"
            aria-label="Previous Slide"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={handleNext}
            className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/60 hover:bg-[#8E5327] text-white border border-white/25 flex items-center justify-center shadow-lg transition-all cursor-pointer z-10"
            aria-label="Next Slide"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          {/* Bottom Slide Text Overlay + Controls */}
          <div className="absolute bottom-3.5 left-3.5 right-3.5 p-4 sm:p-5 rounded-xl bg-[#1E1610]/90 backdrop-blur-md border border-[#C89D66]/40 text-white z-10 space-y-3">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="text-[11px] text-[#FBBF24] uppercase tracking-wider font-bold">
                  {config.businessName} · {config.cityState.split(',')[0]} (Slide {slideIndex + 1}/{HERO_SLIDES.length})
                </div>
                <h1 className="font-display text-lg sm:text-2xl font-bold text-white">
                  {lang === 'hi' ? activeSlide.titleHi : activeSlide.titleEn}
                </h1>
                <p className="text-xs sm:text-sm text-[#E7D6C4] max-w-2xl">
                  {lang === 'hi' ? activeSlide.subtitleHi : activeSlide.subtitleEn}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  onClick={onExploreClick}
                  className="px-3.5 py-2 text-xs font-bold bg-[#C89D66] hover:bg-[#B38750] text-[#241E19] rounded-lg transition-colors inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <span>{lang === 'hi' ? 'सभी प्रोडक्ट्स देखें' : 'Browse Products'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={onCustomOrderClick}
                  className="px-3.5 py-2 text-xs font-semibold bg-white/15 hover:bg-white/25 text-white rounded-lg transition-colors inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Camera className="w-3.5 h-3.5 text-[#FBBF24]" />
                  <span>{lang === 'hi' ? 'अपना डिज़ाइन आइकॉन' : 'Custom Design'}</span>
                </button>
                <a
                  href={config.mapUrl || 'https://maps.google.com/?q=Gorakhpur,Uttar+Pradesh'}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-2 text-xs font-semibold bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors inline-flex items-center gap-1"
                >
                  <MapPin className="w-3.5 h-3.5 text-[#FBBF24]" />
                  <span>{lang === 'hi' ? 'लाइव मैप' : 'Live Map'}</span>
                </a>
              </div>
            </div>

            {/* Slide Indicator Dots + Prev / Pause / Next Bar */}
            <div className="flex items-center justify-between pt-2 border-t border-white/15">
              <div className="flex items-center gap-1.5">
                {HERO_SLIDES.map((s, idx) => (
                  <button
                    key={s.id}
                    onClick={() => setSlideIndex(idx)}
                    className={`h-2 rounded-full transition-all cursor-pointer ${
                      idx === slideIndex
                        ? 'w-7 bg-[#FBBF24]'
                        : 'w-2 bg-white/40 hover:bg-white/70'
                    }`}
                    aria-label={`Slide ${idx + 1}`}
                  />
                ))}
              </div>
              <div className="flex items-center gap-1.5 text-[11px]">
                <button
                  onClick={handlePrev}
                  className="px-2.5 py-0.5 rounded bg-white/10 hover:bg-white/20 text-white cursor-pointer"
                >
                  ◀ {lang === 'hi' ? 'पिछला' : 'Back'}
                </button>
                <button
                  onClick={() => setIsPlaying((p) => !p)}
                  className="px-2.5 py-0.5 rounded bg-[#C89D66]/30 hover:bg-[#C89D66]/50 text-[#FDE68A] font-semibold cursor-pointer"
                >
                  {isPlaying ? '⏸ Pause' : '▶ Play'}
                </button>
                <button
                  onClick={handleNext}
                  className="px-2.5 py-0.5 rounded bg-white/10 hover:bg-white/20 text-white cursor-pointer"
                >
                  {lang === 'hi' ? 'अगला' : 'Next'} ▶
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
