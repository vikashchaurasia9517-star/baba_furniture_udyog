-- ============================================================================
-- BABA FURNITURE UDYOG (बाबा फर्नीचर उद्योग) — SUPABASE POSTGRESQL SCHEMA v4.0
-- Complete Secure Authentication, Two Roles (Shop Owner vs Application Admin),
-- Admin MFA, Team Invitations, Auth Methods Configuration, and Hardened RLS
-- ============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ----------------------------------------------------------------------------
-- 1. ADMIN USERS TABLE (Role-Based Access Control)
-- Linked directly to Supabase Auth auth.users(id)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.admin_users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('shop_owner', 'app_admin')),
  mfa_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  phone TEXT DEFAULT '',
  invited_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for fast lookup
CREATE INDEX IF NOT EXISTS idx_admin_users_email ON public.admin_users(email);
CREATE INDEX IF NOT EXISTS idx_admin_users_role ON public.admin_users(role);

-- ----------------------------------------------------------------------------
-- 2. ADMIN INVITATIONS TABLE (Secure Admin Onboarding)
-- Only 'app_admin' can issue invitations for additional shop owners or admins
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.admin_invitations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('shop_owner', 'app_admin')),
  token TEXT NOT NULL UNIQUE,
  invited_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'revoked')),
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '7 days'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_admin_invitations_email ON public.admin_invitations(email);
CREATE INDEX IF NOT EXISTS idx_admin_invitations_token ON public.admin_invitations(token);

-- ----------------------------------------------------------------------------
-- 3. AUTH METHODS CONFIGURATION TABLE
-- Controls which customer login methods are active in the storefront
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.auth_methods_config (
  id TEXT PRIMARY KEY DEFAULT 'current',
  email_password_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  email_otp_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  google_auth_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  phone_otp_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  whatsapp_otp_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID REFERENCES auth.users(id) ON DELETE SET NULL
);

-- Seed default configuration (Phone/WhatsApp are disabled until SMS/WhatsApp provider is configured)
INSERT INTO public.auth_methods_config (
  id,
  email_password_enabled,
  email_otp_enabled,
  google_auth_enabled,
  phone_otp_enabled,
  whatsapp_otp_enabled
) VALUES (
  'current',
  TRUE,
  TRUE,
  TRUE,
  FALSE,
  FALSE
) ON CONFLICT (id) DO NOTHING;

-- ----------------------------------------------------------------------------
-- 4. CUSTOMER PROFILES TABLE
-- Linked to Supabase Auth auth.users(id) for customer accounts
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.customer_users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT DEFAULT '',
  email TEXT DEFAULT '',
  city TEXT NOT NULL DEFAULT 'Gorakhpur',
  full_address TEXT NOT NULL DEFAULT '',
  pincode TEXT NOT NULL DEFAULT '273001',
  landmark TEXT DEFAULT '',
  alternate_phone TEXT DEFAULT '',
  gst_number TEXT DEFAULT '',
  floor_lift_info TEXT DEFAULT '',
  mobile_verified BOOLEAN NOT NULL DEFAULT FALSE,
  email_verified BOOLEAN NOT NULL DEFAULT FALSE,
  whatsapp_verified BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_customer_users_email ON public.customer_users(email);
CREATE INDEX IF NOT EXISTS idx_customer_users_phone ON public.customer_users(phone);

-- ----------------------------------------------------------------------------
-- 5. SHOWROOM CONFIGURATION TABLE (Single-Row Pattern)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.showroom_config (
  id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  business_name TEXT NOT NULL,
  business_name_hi TEXT NOT NULL,
  tagline TEXT NOT NULL,
  tagline_hi TEXT NOT NULL,
  owner_name TEXT NOT NULL,
  admin_email TEXT NOT NULL DEFAULT 'admin@babafurnitureudyog.com',
  admin_role TEXT NOT NULL DEFAULT 'Founder & Managing Proprietor (संस्थापक एवं संचालक)',
  phone TEXT NOT NULL,
  alternate_phone TEXT DEFAULT '+91 94150 87654',
  whatsapp_number TEXT NOT NULL,
  address TEXT NOT NULL,
  city_state TEXT NOT NULL,
  pincode TEXT DEFAULT '273001',
  landmark TEXT DEFAULT 'रेलवे स्टेशन रोड, रिलायंस स्मार्ट पॉइंट के सामने (Opp. Reliance Smart Point)',
  gst_number TEXT DEFAULT '09AABCB2026F1Z5',
  google_maps_url TEXT DEFAULT 'https://maps.google.com/?q=26.7606,83.3732',
  latitude DOUBLE PRECISION DEFAULT 26.7606,
  longitude DOUBLE PRECISION DEFAULT 83.3732,
  show_prices_on_website BOOLEAN NOT NULL DEFAULT TRUE,
  welcome_offer_text TEXT DEFAULT '🎁 शोरूम स्वागत ऑफ़र: आज बुकिंग या पूछताछ करने पर मुफ़्त होम डिलीवरी और 10 साल की लिखित सागवान वारंटी!',
  timings TEXT NOT NULL,
  announcement TEXT NOT NULL,
  hero_stats JSONB DEFAULT '{"stat1Value":"100%","stat1LabelHi":"सॉलिड असली लकड़ी","stat1LabelEn":"Solid Seasoned Timber","stat2Value":"10+ Yrs","stat2LabelHi":"दीमक-प्रूफ गारंटी","stat2LabelEn":"Termite-Proof Warranty","stat3Value":"4,500+","stat3LabelHi":"संतुष्ट ग्राहक परिवार","stat3LabelEn":"Happy Families Furnished"}'::jsonb,
  wood_types JSONB DEFAULT '[]'::jsonb,
  room_presets JSONB DEFAULT '[]'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 6. PRODUCTS CATALOG TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.products (
  id TEXT PRIMARY KEY,
  sku TEXT NOT NULL,
  title TEXT NOT NULL,
  title_hi TEXT NOT NULL,
  category TEXT NOT NULL,
  category_label TEXT NOT NULL,
  category_label_hi TEXT NOT NULL,
  wood_type TEXT NOT NULL,
  dimensions TEXT NOT NULL,
  price NUMERIC NOT NULL DEFAULT 35000,
  mrp NUMERIC NOT NULL DEFAULT 42000,
  hide_price BOOLEAN NOT NULL DEFAULT FALSE,
  finish_options JSONB NOT NULL DEFAULT '[]'::jsonb,
  features JSONB NOT NULL DEFAULT '[]'::jsonb,
  features_hi JSONB NOT NULL DEFAULT '[]'::jsonb,
  image_url TEXT NOT NULL,
  description TEXT NOT NULL,
  description_hi TEXT NOT NULL,
  warranty_years INTEGER NOT NULL DEFAULT 10,
  is_featured BOOLEAN NOT NULL DEFAULT FALSE,
  in_stock BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_products_category ON public.products(category);
CREATE INDEX IF NOT EXISTS idx_products_featured ON public.products(is_featured);

-- ----------------------------------------------------------------------------
-- 7. CUSTOMER INQUIRIES & QUOTE REQUESTS TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.inquiries (
  id TEXT PRIMARY KEY,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  alternate_phone TEXT DEFAULT '',
  city TEXT DEFAULT '',
  full_address TEXT DEFAULT '',
  pincode TEXT DEFAULT '',
  landmark TEXT DEFAULT '',
  preferred_contact TEXT NOT NULL DEFAULT 'whatsapp',
  product_id TEXT,
  product_title TEXT,
  product_sku TEXT,
  wood_preference TEXT,
  custom_design_note TEXT,
  custom_design_image TEXT,
  status TEXT NOT NULL DEFAULT 'new',
  timestamp BIGINT NOT NULL,
  formatted_date TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_inquiries_status ON public.inquiries(status);
CREATE INDEX IF NOT EXISTS idx_inquiries_phone ON public.inquiries(phone);

-- ============================================================================
-- 8. HELPER SECURITY FUNCTIONS FOR ROW LEVEL SECURITY (RLS)
-- ============================================================================

-- Function: Check if the current authenticated user is an admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admin_users
    WHERE id = auth.uid()
  );
$$;

-- Function: Check if the current authenticated user is an Application Admin
CREATE OR REPLACE FUNCTION public.is_app_admin()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admin_users
    WHERE id = auth.uid() AND role = 'app_admin'
  );
$$;

-- Function: Check if the current authenticated user is a Shop Owner
CREATE OR REPLACE FUNCTION public.is_shop_owner()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admin_users
    WHERE id = auth.uid() AND role IN ('shop_owner', 'app_admin')
  );
$$;

-- ============================================================================
-- 9. ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================

-- Enable RLS across all tables
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_invitations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.auth_methods_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.showroom_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inquiries ENABLE ROW LEVEL SECURITY;

-- ----------------------------------------------------------------------------
-- RLS: admin_users table
-- Non-admins cannot read or write to admin_users.
-- Admins can view other admins; only app_admin can insert, update roles, or delete.
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Admins can view admin users" ON public.admin_users;
CREATE POLICY "Admins can view admin users"
  ON public.admin_users
  FOR SELECT
  USING (auth.uid() = id OR public.is_admin());

DROP POLICY IF EXISTS "App admins can insert admin users" ON public.admin_users;
CREATE POLICY "App admins can insert admin users"
  ON public.admin_users
  FOR INSERT
  WITH CHECK (public.is_app_admin());

DROP POLICY IF EXISTS "App admins or self can update admin users" ON public.admin_users;
CREATE POLICY "App admins or self can update admin users"
  ON public.admin_users
  FOR UPDATE
  USING (auth.uid() = id OR public.is_app_admin())
  WITH CHECK (auth.uid() = id OR public.is_app_admin());

DROP POLICY IF EXISTS "Only app admins can delete admin users" ON public.admin_users;
CREATE POLICY "Only app admins can delete admin users"
  ON public.admin_users
  FOR DELETE
  USING (public.is_app_admin());

-- ----------------------------------------------------------------------------
-- RLS: admin_invitations table
-- Only app_admin can view, create, or revoke admin invitations
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "App admins manage invitations" ON public.admin_invitations;
CREATE POLICY "App admins manage invitations"
  ON public.admin_invitations
  FOR ALL
  USING (public.is_app_admin())
  WITH CHECK (public.is_app_admin());

-- ----------------------------------------------------------------------------
-- RLS: auth_methods_config table
-- Public can read which sign-in methods are active. Only app_admin can update.
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Public can view auth methods config" ON public.auth_methods_config;
CREATE POLICY "Public can view auth methods config"
  ON public.auth_methods_config
  FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "App admins can update auth methods config" ON public.auth_methods_config;
CREATE POLICY "App admins can update auth methods config"
  ON public.auth_methods_config
  FOR UPDATE
  USING (public.is_app_admin())
  WITH CHECK (public.is_app_admin());

-- ----------------------------------------------------------------------------
-- RLS: products table
-- Public can view active products. Only admins can create/update/delete.
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Public can view products" ON public.products;
CREATE POLICY "Public can view products"
  ON public.products
  FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Admins can manage products" ON public.products;
CREATE POLICY "Admins can manage products"
  ON public.products
  FOR ALL
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- ----------------------------------------------------------------------------
-- RLS: showroom_config table
-- Public can view showroom configuration. Only admins can update.
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Public can view showroom config" ON public.showroom_config;
CREATE POLICY "Public can view showroom config"
  ON public.showroom_config
  FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Admins can update showroom config" ON public.showroom_config;
CREATE POLICY "Admins can update showroom config"
  ON public.showroom_config
  FOR ALL
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- ----------------------------------------------------------------------------
-- RLS: inquiries table
-- Anyone (customers) can submit quote requests. Only admins can read/update.
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Customers can submit inquiries" ON public.inquiries;
CREATE POLICY "Customers can submit inquiries"
  ON public.inquiries
  FOR INSERT
  WITH CHECK (true);

DROP POLICY IF EXISTS "Admins can manage inquiries" ON public.inquiries;
CREATE POLICY "Admins can manage inquiries"
  ON public.inquiries
  FOR ALL
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- ----------------------------------------------------------------------------
-- RLS: customer_users table
-- Customers can view and update only their own profile. Admins can view profiles.
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Customers view own profile" ON public.customer_users;
CREATE POLICY "Customers view own profile"
  ON public.customer_users
  FOR SELECT
  USING (auth.uid()::text = id OR public.is_admin());

DROP POLICY IF EXISTS "Customers update own profile" ON public.customer_users;
CREATE POLICY "Customers update own profile"
  ON public.customer_users
  FOR ALL
  USING (auth.uid()::text = id)
  WITH CHECK (auth.uid()::text = id);

-- ============================================================================
-- 10. SECURE FIRST ADMIN PROVISIONING INSTRUCTIONS
-- ============================================================================
-- To provision your initial Application Admin safely:
--
-- METHOD 1 (Recommended Backend CLI):
-- Run the provisioning script from your server terminal:
--   npx tsx scripts/provision-first-admin.ts --email="admin@babafurnitureudyog.com" --name="Vikash Chaurasia" --role="app_admin"
--
-- METHOD 2 (Supabase Dashboard SQL Editor):
-- 1. Create the user in Supabase Dashboard -> Authentication -> Users -> Add User.
-- 2. Note their User UID, then run in the SQL Editor:
--   INSERT INTO public.admin_users (id, email, full_name, role, mfa_enabled)
--   VALUES ('<PASTE-USER-UID-HERE>', 'admin@babafurnitureudyog.com', 'Vikash Chaurasia', 'app_admin', FALSE)
--   ON CONFLICT (id) DO UPDATE SET role = 'app_admin';
-- ============================================================================
