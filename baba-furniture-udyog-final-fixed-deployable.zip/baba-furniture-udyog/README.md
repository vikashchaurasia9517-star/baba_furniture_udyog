# बाबा फर्नीचर उद्योग (Baba Furniture Udyog) — Full-Stack Deployment & Supabase Auth Guide

इस संपूर्ण गाइड में आपके फुल-स्टैक प्रोजेक्ट को **VS Code, GitHub, Vercel/Render** और **Supabase** पर लाइव करने, **100% वास्तविक ग्राहक प्रमाणीकरण (Genuine Supabase Auth)** तथा **सुरक्षित व्यवस्थापक प्रणाली (Admin RBAC, Roles, MFA, Team Invites & Provisioning)** को कॉन्फ़िगर करने की विस्तृत जानकारी दी गई है।

---

## 🛡️ 1. सुरक्षा आर्किटेक्चर एवं एनवायरनमेंट नीतियां (Security Architecture)

### कड़े सुरक्षा नियम (Strict Security Standards):
1. **फ्रंटएंड `.env` में केवल सार्वजनिक कुंजियाँ**:
   * फ्रंटएंड (Vite) के पास केवल `VITE_SUPABASE_URL` और `VITE_SUPABASE_ANON_KEY` की पहुंच होती है।
   * `SUPABASE_SERVICE_ROLE_KEY`, डेटाबेस पासवर्ड, या एडमिन क्रेडेंशियल्स कभी भी फ्रंटएंड कोड, localStorage या क्लाइंट बंडल में शामिल नहीं किए जाते।
2. **शून्य डिफ़ॉल्ट या हार्डकोडेड क्रेडेंशियल्स**:
   * पुराना पिन `1234` और डेमो पासवर्ड पूरी तरह हटा दिए गए हैं। कोई भी अनधिकृत व्यक्ति सीधे एडमिन पैनल में नहीं जा सकता।
3. **सख्त Row Level Security (RLS)**:
   * डेटाबेस में RLS नीतियां सक्रिय हैं ताकि आम ग्राहक एडमिन तालिकाओं (`admin_users`, `admin_invitations`) को न पढ़ सकें और न ही उत्पाद या शोरूम सेटिंग्स में फेरबदल कर सकें।

---

## 👥 2. दो अलग-अलग व्यवस्थापक भूमिकाएं (Shop Owner vs Application Admin)

सिस्टम में व्यवस्थापकों के लिए दो पृथक भूमिकाएं (Roles) निर्धारित की गई हैं:

| सुविधा / अधिकार | 👑 Shop Owner (दुकान संचालक) | 🛡️ Application Admin (सिस्टम प्रशासक) |
| :--- | :---: | :---: |
| **फर्नीचर उत्पाद सूची** (जोड़ना, संपादन, हटाना, कीमतें, स्टॉक) | ✅ पूर्ण अधिकार | ✅ पूर्ण अधिकार |
| **ग्राहक पूछताछ व कोटेशन** (स्टेटस बदलना, WhatsApp उत्तर, CSV) | ✅ पूर्ण अधिकार | ✅ पूर्ण अधिकार |
| **शोरूम प्रोफ़ाइल व संपर्क** (पता, फोन, घोषणा बैनर, लकड़ी प्रकार) | ✅ पूर्ण अधिकार | ✅ पूर्ण अधिकार |
| **व्यक्तिगत पासवर्ड व 2-स्टेप सत्यापन (MFA)** | ✅ अपना खाता | ✅ अपना खाता |
| **एडमिन टीम व आमंत्रण प्रबंधन** (नए एडमिन जोड़ना/हटाना) | ❌ अधिकार नहीं | ✅ पूर्ण अधिकार (`app_admin`) |
| **ग्राहक लॉगिन विधियां कॉन्फ़िगरेशन** (OTP/OAuth टॉगल) | ❌ अधिकार नहीं | ✅ पूर्ण अधिकार (`app_admin`) |

---

## ⚡ 3. पहले व्यवस्थापक का सुरक्षित प्रावधान (Initial Admin Provisioning)

किसी भी सार्वजनिक पंजीकरण (Public Signup) के बिना पहले एडमिन को सुरक्षित रूप से बनाने के दो आधिकारिक तरीके हैं:

### तरीका 1: बैकएंड CLI स्क्रिप्ट (सर्वाधिक अनुशंसित)
अपने सर्वर टर्मिनल या VS Code टर्मिनल में निम्नलिखित कमांड चलाएं:

```bash
# Application Admin बनाना
npx tsx scripts/provision-first-admin.ts --email="admin@babafurnitureudyog.com" --password="YourSuperSecurePassword123!" --name="प्रो. विकास चौरसिया" --role="app_admin"

# या npm स्क्रिप्ट द्वारा
npm run provision:admin -- --email="admin@babafurnitureudyog.com" --password="YourSuperSecurePassword123!" --role="app_admin"
```
यह स्क्रिप्ट सीधे Supabase Auth में ईमेल-कन्फर्म्ड यूजर तैयार करती है और `public.admin_users` में उन्हें `app_admin` रोल असाइन करती है।

### तरीका 2: Supabase Dashboard + SQL Editor
1. Supabase Dashboard में जाएं: **Authentication > Users > Add user > Create user**।
2. ईमेल और पासवर्ड दर्ज करें (उदा. `admin@babafurnitureudyog.com`) और **Auto Confirm User?** को चेक करें।
3. बनाए गए उपयोगकर्ता का **User UID** कॉपी करें।
4. Supabase **SQL Editor** में जाकर निम्नलिखित क्वेरी चलाएं:
```sql
INSERT INTO public.admin_users (id, email, full_name, role, mfa_enabled)
VALUES ('<PASTE-USER-UID-HERE>', 'admin@babafurnitureudyog.com', 'प्रो. विकास चौरसिया (Vikash Chaurasia)', 'app_admin', FALSE)
ON CONFLICT (id) DO UPDATE SET role = 'app_admin';
```

---

## 🔐 4. एडमिन 2-स्टेप सत्यापन (MFA / Two-Factor Authentication)

1. व्यवस्थापक अपने एडमिन पैनल के **"सुरक्षा व 2-स्टेप सत्यापन (Security & MFA)"** टैब में जाकर 2FA चालू कर सकते हैं।
2. MFA सक्रिय होने पर, जब भी एडमिन लॉगिन करेगा, पासवर्ड सत्यापन के बाद स्क्रीन पर 6-अंकों का 2-स्टेप सत्यापन कोड दर्ज करने का प्रॉम्प्ट आएगा।
3. सही कोड डालने के बाद ही सुरक्षित एडमिन सत्र सक्रिय होता है।

---

## ✉️ 5. अतिरिक्त एडमिन को सुरक्षित आमंत्रण (Team Invitations)

1. **Application Admin** अपने पैनल में **"एडमिन टीम व आमंत्रण (Admin Team & Invites)"** टैब पर जाते हैं।
2. नए साथी का ईमेल और उनकी भूमिका (`Shop Owner` या `Application Admin`) चुनकर **"आमंत्रण भेजें"** पर क्लिक करते हैं।
3. आमंत्रित सदस्य को सुरक्षित टोकन के साथ आमंत्रण ईमेल भेजा जाता है और वे अपना खाता सक्रिय कर सकते हैं।
4. किसी भी पूर्व व्यवस्थापक का अधिकार किसी भी समय एक क्लिक में वापस (Revoke) लिया जा सकता है।

---

## ⚙️ 6. ग्राहक लॉगिन विधियां प्रबंधन (Auth Methods Configuration)

**Application Admin** स्टोरफ़्रंट पर ग्राहकों के लिए उपलब्ध लॉगिन विधियों को नियंत्रित कर सकते हैं:
* **Email & Password**: सामान्य पंजीकरण, पासवर्ड नीति, और पासवर्ड रीसेट। (डिफ़ॉल्ट: ON)
* **Email OTP**: बिना पासवर्ड 6-अंकों का वास्तविक Supabase ईमेल कोड। (डिफ़ॉल्ट: ON)
* **Google 1-Click OAuth**: Google क्रेडेंशियल्स द्वारा लॉगिन। (Google Cloud Console में Client ID सेटअप आवश्यक)
* **SMS Phone OTP & WhatsApp OTP**: पेड प्रोवाइडर (Twilio, Meta Business API) कॉन्फ़िगर न होने तक इन्हें सुरक्षित रूप से बंद रखा गया है ताकि ग्राहकों को कोई भ्रम या फ़र्ज़ी अनुभव न हो।

---

## 🔐 7. वास्तविक ग्राहक प्रमाणीकरण प्रवाह (Customer Auth Features)

1. **ग्राहक पंजीकरण (Sign Up)**: पूरा नाम, ईमेल, पासवर्ड, कन्फर्म पासवर्ड, और सेवा शर्तों का चेकबॉक्स।
2. **पासवर्ड लॉगिन**: ईमेल व पासवर्ड, पासवर्ड दिखाने/छुपाने (Show/Hide) की सुविधा।
3. **पासवर्ड भूल गए (Forgot Password)**: `supabase.auth.resetPasswordForEmail` द्वारा तटस्थ पुष्टि संदेश (No account enumeration)।
4. **पासवर्ड रीसेट स्क्रीन (Dedicated Reset Password)**: रिकवरी टोकन द्वारा नया पासवर्ड और पुष्टि।
5. **पासवर्ड बदलना व सेट करना**: ग्राहक खाता सेटिंग्स में पासवर्ड अपडेट। OTP/OAuth उपयोगकर्ताओं के लिए "पासवर्ड सेट करें" का विकल्प।
6. **पुनः सत्यापन ईमेल (Resend Verification)**: 60 सेकंड कूलडाउन के साथ वास्तविक Supabase रीसेंड।
7. **ईमेल OTP लॉगिन**: वास्तविक 6-अंकों का Supabase OTP, खाली इनपुट बॉक्स, कोई हार्डकोडेड कोड नहीं।
8. **वास्तविक Google लॉगिन**: Supabase OAuth 2.0 रीडायरेक्शन।
9. **खाता सेटिंग्स व प्रोफाइल**: डिलीवरी पता, पिनकोड, शहर, लैंडमार्क, संपर्क नंबर, और सत्यापन स्थिति।
10. **स्थायी व सुरक्षित खाता विलोपन (Right to Erasure)**:
    * ग्राहक को स्पष्ट चेतावनी और "DELETE" टाइप करने की पुष्टि।
    * बैकएंड सर्वर `POST /api/auth/delete-account` द्वारा Supabase Auth यूजर को हटाता है।
    * वित्तीय और टैक्स ऑडिट नियमों का पालन करते हुए पुराने ऑर्डर/पूछताछ रिकॉर्ड से व्यक्तिगत पहचान जानकारी पूरी तरह मिटा (anonymize) दी जाती है।

---

## 📁 8. Supabase डेटाबेस स्कीमा (Database Schema & RLS Setup)

प्रोजेक्ट में `supabase/schema.sql` फ़ाइल उपलब्ध है। इसे Supabase Dashboard के **SQL Editor** में खोलें और **RUN** दबाएं।

इसमें सम्मिलित हैं:
* `admin_users`: व्यवस्थापक भूमिकाएं (`shop_owner`, `app_admin`), MFA फ्लैग।
* `admin_invitations`: टीम आमंत्रण टोकन व समय सीमा।
* `auth_methods_config`: स्टोरफ़्रंट लॉगिन टॉगल।
* `products`: फर्नीचर उत्पाद सूची।
* `showroom_config`: शोरूम सेटिंग्स व संपर्क।
* `inquiries`: ग्राहक पूछताछ व कोटेशन।
* `customer_users`: ग्राहक प्रोफाइल व पता।
* RLS सुरक्षा नीतियां एवं सुरक्षा फ़ंक्शन (`is_admin()`, `is_app_admin()`)।

---

## 💻 9. VS Code में प्रोजेक्ट चलाने के चरण (Local Development)

### Step 1: एनवायरनमेंट फ़ाइल कॉन्फ़िगर करें (`.env.local`)
रूट डायरेक्टरी में `.env.local` बनाएं (या `.env.example` कॉपी करें):

```env
# 1. Frontend Keys (Vite Bundle - Public Anon Key Only)
VITE_SUPABASE_URL="https://your-project.supabase.co"
VITE_SUPABASE_ANON_KEY="your-anon-public-key"

# 2. Backend Server Secrets (Node.js Server Only - Never in Frontend!)
PORT=3000
SUPABASE_URL="https://your-project.supabase.co"
SUPABASE_ANON_KEY="your-anon-public-key"
SUPABASE_SERVICE_ROLE_KEY="your-service-role-secret-key"
ADMIN_TOKEN_SECRET="generate-a-random-64-character-string"

# 3. Initial Admin Provisioning Details
ADMIN_INITIAL_EMAIL="admin@babafurnitureudyog.com"
ADMIN_INITIAL_NAME="प्रो. विकास चौरसिया (Vikash Chaurasia)"
ADMIN_INITIAL_ROLE="app_admin"
```

### Step 2: डिपेंडेंसी इंस्टॉल करें
```bash
npm install
```
*(यदि peer dependencies से संबंधित कोई चेतावनी आए, तो `npm install --legacy-peer-deps` का उपयोग करें।)*

### Step 3: पहला एडमिन बनाएं
```bash
npm run provision:admin -- --email="admin@babafurnitureudyog.com" --password="YourSecurePassword123!" --role="app_admin"
```

### Step 4: डेवलपमेंट सर्वर शुरू करें
```bash
# Vite Frontend शुरू करें (Port 3000)
npm run dev

# अलग टर्मिनल में बैकएंड सर्वर शुरू करें
npm run server
```

ब्राउज़र में खोलें: `http://localhost:3000`

---

## 🚀 10. प्रोडक्शन डिप्लॉयमेंट (Vercel & Render)

1. **GitHub पर कोड पुश करें**:
   ```bash
   git init
   git add .
   git commit -m "feat: hardened supabase rbac, admin mfa, team invites, and customer auth"
   git branch -M main
   git remote add origin https://github.com/your-username/baba-furniture-udyog.git
   git push -u origin main
   ```

2. **Vercel (Frontend)**:
   * Vercel डैशबोर्ड में प्रोजेक्ट इम्पोर्ट करें।
   * **Environment Variables** में केवल जोड़ें:
     * `VITE_SUPABASE_URL`
     * `VITE_SUPABASE_ANON_KEY`
   * डिप्लॉय करें।

3. **Render / Railway (Backend API & Admin Server)**:
   * Web Service बनाएं।
   * Environment Variables में जोड़ें:
     * `SUPABASE_URL`
     * `SUPABASE_ANON_KEY`
     * `SUPABASE_SERVICE_ROLE_KEY`
     * `ADMIN_TOKEN_SECRET`
   * Build Command: `npm install`
   * Start Command: `npm run start`

---

## ✅ सुरक्षा ऑडिट चेकलिस्ट (Security Verification)

- [x] फ्रंटएंड `.env` में केवल Supabase URL और Anon Key है; कोई सीक्रेट की नहीं।
- [x] सर्विस रोल की, डेटाबेस पासवर्ड, और एडमिन पासवर्ड फ्रंटएंड फॉर्म से पूरी तरह हटा दिए गए हैं।
- [x] एडमिनिस्ट्रेटर के लिए वास्तविक Supabase Auth एवं दो पृथक रोल्स (`shop_owner` व `app_admin`) लागू हैं।
- [x] एडमिन 2-स्टेप सत्यापन (MFA) कोड सुरक्षा सहित लागू है।
- [x] नए एडमिन के लिए सुरक्षित आमंत्रण प्रणाली तैयार है।
- [x] ग्राहक प्रमाणीकरण के 13 प्रवाह वास्तविक Supabase Auth द्वारा संचालित हैं।
- [x] अनकॉन्फ़िगर या पेड लॉगिन विधियां (SMS, WhatsApp) सुरक्षित रूप से छिपाई गई हैं।
- [x] मौजूदा सभी उत्पाद, ऑर्डर, पूछताछ, और शोरूम विवरण 100% सुरक्षित और कार्यशील हैं।